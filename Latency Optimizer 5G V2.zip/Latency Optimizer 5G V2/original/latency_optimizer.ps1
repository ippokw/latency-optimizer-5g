# latency_optimizer.ps1 — Latency Optimizer 5G V1.3 (High Priority)
# ---------------------------------------------------------------

# bump this PowerShell process to High priority
$me = Get-Process -Id $PID
$me.PriorityClass = 'High'

# banner
Write-Host "==============================================="
Write-Host "   Latency Optimizer 5G V1.3"
Write-Host "   (Powered by Othmanq8ty on Instagram)"
Write-Host "==============================================="

function Visit-Speedtest {
    $url = 'https://www.speedtest.net/'
    while ($true) {
        try {
            $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10
            $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            if ($resp.StatusCode -eq 200) {
                Write-Host "[$ts] ✅ Visited Speedtest successfully."
            } else {
                Write-Host "[$ts] ⚠️ Status code: $($resp.StatusCode)"
            }
            break
        } catch {
            $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            Write-Host "[$ts] ❌ $($_.Exception.Message) Retrying…"
        }
        Start-Sleep -Seconds 1
    }
}

while ($true) {
    Visit-Speedtest
    Start-Sleep -Seconds 5
}