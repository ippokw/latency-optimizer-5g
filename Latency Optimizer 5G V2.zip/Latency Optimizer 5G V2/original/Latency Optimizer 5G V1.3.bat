@echo off
REM — Launch Latency Optimizer 5G V1.3 —
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0latency_optimizer.ps1"
pause