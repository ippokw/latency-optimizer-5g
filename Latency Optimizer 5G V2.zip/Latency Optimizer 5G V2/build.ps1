# Builds Latency Optimizer 5G into a single .exe.
# Needs nothing installed: falls back to the C# compiler that ships with Windows (.NET Framework 4.x).
#   .\build.ps1            plain build
#   .\build.ps1 -Protect   build, then obfuscate (renames symbols + encrypts strings) via protect.ps1
param([switch]$Protect)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src  = Join-Path $root 'src'
$obj  = Join-Path $root 'obj'
$dist = Join-Path $root 'Latency Optimizer 5G V2.0'
$fw   = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319'

$csc = Get-ChildItem 'C:\Program Files*\Microsoft Visual Studio\*\*\MSBuild\Current\Bin\Roslyn\csc.exe' -ErrorAction SilentlyContinue |
       Select-Object -First 1 -ExpandProperty FullName
if (-not $csc) { $csc = Join-Path $fw 'csc.exe' }
if (-not (Test-Path $csc)) { throw 'No C# compiler found.' }

New-Item -ItemType Directory -Force $obj, $dist | Out-Null
$sources = Get-ChildItem (Join-Path $src '*.cs') | ForEach-Object { $_.FullName }
$common = @(
    '/nologo', '/noconfig', '/target:winexe', '/platform:anycpu', '/optimize+', '/codepage:65001', '/utf8output',
    "/lib:$fw", '/r:mscorlib.dll', '/r:System.dll', '/r:System.Core.dll', '/r:System.Drawing.dll', '/r:System.Windows.Forms.dll'
)

# Pass 1: a bootstrap build whose only job is to draw the app icon (the logo is generated in code).
$boot = Join-Path $obj 'bootstrap.exe'
$ico  = Join-Path $obj 'app.ico'
& $csc @common "/out:$boot" @sources
if ($LASTEXITCODE -ne 0) { throw "Compile failed (pass 1)." }
$p = Start-Process -FilePath $boot -ArgumentList '--makeicon', "`"$ico`"" -Wait -PassThru
if ($p.ExitCode -ne 0 -or -not (Test-Path $ico)) { throw 'Icon generation failed.' }

# Pass 2: the real exe, with icon and manifest embedded.
$exe = Join-Path $dist 'LatencyOptimizer5G.exe'
& $csc @common "/out:$exe" "/win32icon:$ico" "/win32manifest:$(Join-Path $src 'app.manifest')" @sources
if ($LASTEXITCODE -ne 0) { throw "Compile failed (pass 2)." }

"Built: $exe  ($([math]::Round((Get-Item $exe).Length / 1KB)) KB)  with $csc"

if ($Protect) {
    & (Join-Path $root 'protect.ps1')
    if ($LASTEXITCODE -ne 0) { throw 'Protection step failed.' }
}
