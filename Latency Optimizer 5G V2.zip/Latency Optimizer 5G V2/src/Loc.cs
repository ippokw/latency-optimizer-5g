using System.Collections.Generic;
using System.Globalization;

namespace LO5G
{
    /// <summary>English / Arabic strings. Index 0 = English, 1 = Arabic.</summary>
    static class Loc
    {
        public static bool Rtl;
        public static string Lang = "en";

        public static void Init()
        {
            string l = Settings.Lang;
            if (string.IsNullOrEmpty(l)) l = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName == "ar" ? "ar" : "en";
            Use(l);
        }

        static bool cleaned;

        public static void Use(string lang)
        {
            Lang = lang == "ar" ? "ar" : "en";
            Rtl = Lang == "ar";
            if (!cleaned)
            {
                // The long dash renders on top of the neighbouring Arabic word; Arabic uses a comma there anyway.
                cleaned = true;
                foreach (var v in D.Values) v[1] = v[1].Replace(" — ", "، ");
            }
        }

        public static string T(string key)
        {
            string[] v;
            return D.TryGetValue(key, out v) ? v[Rtl ? 1 : 0] : key;
        }

        public static string T(string key, params object[] args)
        {
            return string.Format(CultureInfo.InvariantCulture, T(key), args);
        }

        /// <summary>Keeps a value such as "↑ 3.9 Mbps" in left-to-right order when it sits inside Arabic text.</summary>
        public static string Ltr(string s)
        {
            return Rtl ? "‪" + s + "‬" : s;
        }

        static readonly Dictionary<string, string[]> D = new Dictionary<string, string[]>
        {
            // navigation
            { "nav.dash", new[] { "Dashboard", "الرئيسية" } },
            { "nav.opt", new[] { "Optimize", "التحسينات" } },
            { "nav.games", new[] { "Games", "الألعاب" } },
            { "nav.limit", new[] { "Limiter", "محدد السرعة" } },

            // limiter
            { "lim.sub", new[] { "Caps the upload of other programs while Boost is on, so they cannot fill your line. No administrator needed.", "يحدد سرعة رفع البرامج الثانية أثناء التثبيت حتى ما تملأ خطك. بدون صلاحية مسؤول." } },
            { "lim.title", new[] { "Upload limiter", "محدد الرفع" } },
            { "lim.st.off", new[] { "Off. Programs upload at full speed.", "متوقف. البرامج ترفع بكامل سرعتها." } },
            { "lim.st.cap", new[] { "Holding down now: {0}  ·  max {1}", "محدَّد الآن: {0}  ·  الحد {1}" } },
            { "lim.st.armed", new[] { "Ready: {0}. The cap starts as soon as Boost turns on.", "جاهز: {0}. يبدأ التحديد أول ما يشتغل التثبيت." } },
            { "lim.st.none", new[] { "On. No program from the list is running right now.", "يعمل. لا يوجد برنامج من القائمة شغال الآن." } },
            { "lim.st.unsup", new[] { "This Windows version refused the limit (needs Windows 10 or newer).", "نسخة ويندوز هذي رفضت التحديد (يحتاج ويندوز 10 أو أحدث)." } },
            { "lim.rate", new[] { "Upload limit per program", "حد الرفع لكل برنامج" } },
            { "lim.rate.d", new[] { "Voice chat needs about {0}. Lower = steadier ping.", "المحادثة الصوتية تحتاج {0} تقريباً. الأقل = بنق أثبت." } },
            { "lim.count", new[] { "Programs to limit  ·  {0}", "البرامج المحدَّدة  ·  {0}" } },
            { "lim.now", new[] { "USING YOUR LINE NOW", "يستهلك خطك الآن" } },
            { "lim.now.none", new[] { "Nothing heavy", "لا يوجد استهلاك عالي" } },
            { "lim.now.none.sub", new[] { "A program filling the line shows up here", "يظهر هنا البرنامج اللي يملأ الخط" } },
            { "lim.addtop", new[] { "Limit this program", "حدّد هذا البرنامج" } },
            { "lim.addtop.done", new[] { "Already on the list", "موجود بالقائمة" } },
            { "lim.add.run", new[] { "Add a running program", "إضافة برنامج يعمل الآن" } },
            { "lim.pick", new[] { "Choose a program to limit", "اختر برنامجاً لتحديده" } },
            { "lim.note", new[] { "Works on connections a program opens after it is on this list. If it was already streaming or in a call, restart that once. Games are never limited.", "يشتغل على الاتصالات اللي يفتحها البرنامج بعد إضافته للقائمة. إذا كان يبث أو بمكالمة من قبل، أعد تشغيلها مرة واحدة. الألعاب ما تتحدد أبداً." } },
            { "lim.tag.cap", new[] { "capped", "محدَّد" } },
            { "lim.tag.armed", new[] { "ready", "جاهز" } },
            { "nav.tune", new[] { "Auto-Tune", "الضبط التلقائي" } },
            { "nav.set", new[] { "Settings", "الإعدادات" } },
            { "side.on", new[] { "Boost active", "التثبيت يعمل" } },
            { "side.wait", new[] { "Waiting for a game", "بانتظار لعبة" } },
            { "side.off", new[] { "Monitoring only", "مراقبة فقط" } },
            { "side.credit", new[] { "Othman Malallah  ·  IG: ippokw", "Othman Malallah  ·  IG: ippokw" } },

            // boost + modes
            { "boost.off", new[] { "OFF", "إيقاف" } },
            { "boost.auto", new[] { "AUTO", "تلقائي" } },
            { "boost.on", new[] { "ON", "تشغيل" } },
            { "mode.0", new[] { "Eco", "اقتصادي" } },
            { "mode.1", new[] { "Balanced", "متوازن" } },
            { "mode.2", new[] { "Ultra", "قوي" } },
            { "mode.3", new[] { "Extreme", "أقصى" } },

            // dashboard
            { "hero.on", new[] { "Boost is ON", "التثبيت يعمل" } },
            { "hero.on.game", new[] { "Boost is ON  ·  {0}", "التثبيت يعمل  ·  {0}" } },
            { "hero.wait", new[] { "Waiting for a game", "بانتظار تشغيل لعبة" } },
            { "hero.off", new[] { "Boost is OFF", "التثبيت متوقف" } },
            { "hero.tune", new[] { "Auto-Tune is running…", "الضبط التلقائي يعمل…" } },
            { "hero.sub.on", new[] { "Pulse {0}/s is keeping your line awake", "نبض {0} بالثانية يبقي خطك نشطاً" } },
            { "hero.sub.wait", new[] { "Starts by itself when a listed game runs", "يبدأ تلقائياً عند تشغيل لعبة من القائمة" } },
            { "hero.sub.off", new[] { "Monitoring only — switch Boost on to stabilize", "مراقبة فقط — شغّل التثبيت لتثبيت البنق" } },
            { "hero.sub.tune", new[] { "Measuring your line with each pulse level", "جاري قياس خطك مع كل مستوى نبض" } },
            { "hero.sub.nonet", new[] { "No internet connection detected", "لا يوجد اتصال بالإنترنت" } },
            { "hero.sub.detect", new[] { "Detecting your connection…", "جاري فحص اتصالك…" } },
            { "hero.traffic", new[] { "{0}   {1}   ·   Boost data used: {2}", "{0}   {1}   ·   بيانات التثبيت: {2}" } },

            { "stat.ping", new[] { "PING", "البنق" } },
            { "stat.jitter", new[] { "JITTER", "التذبذب" } },
            { "stat.loss", new[] { "PACKET LOSS", "فقد الحزم" } },
            { "stat.score", new[] { "STABILITY", "الثبات" } },
            { "stat.avgmax", new[] { "avg {0}  ·  max {1}", "متوسط {0}  ·  أعلى {1}" } },
            { "stat.spikes", new[] { "{0} spikes in last minute", "{0} قفزة بآخر دقيقة" } },
            { "stat.lost", new[] { "{0} of {1} lost", "فُقد {0} من {1}" } },
            { "q.excellent", new[] { "Excellent", "ممتاز" } },
            { "q.good", new[] { "Good", "جيد" } },
            { "q.fair", new[] { "Fair", "متوسط" } },
            { "q.poor", new[] { "Poor", "ضعيف" } },

            { "graph.title", new[] { "Live ping — last 60 seconds", "البنق المباشر — آخر 60 ثانية" } },
            { "graph.inet", new[] { "Internet", "الإنترنت" } },
            { "graph.router", new[] { "Router", "الراوتر" } },
            { "graph.lost", new[] { "Lost", "مفقود" } },
            { "graph.wait", new[] { "Waiting for data…", "بانتظار البيانات…" } },

            { "info.conn", new[] { "CONNECTION", "الاتصال" } },
            { "info.router", new[] { "ROUTER", "الراوتر" } },
            { "info.diag", new[] { "DIAGNOSIS", "التشخيص" } },
            { "kind.wifi", new[] { "Wi-Fi", "واي فاي" } },
            { "kind.ethernet", new[] { "Ethernet cable", "كيبل Ethernet" } },
            { "kind.cellular", new[] { "Mobile data (5G / LTE)", "بيانات الجوال (5G / LTE)" } },
            { "kind.usb", new[] { "USB tethering", "ربط USB" } },
            { "kind.vpn", new[] { "VPN", "VPN" } },
            { "kind.other", new[] { "Network", "شبكة" } },
            { "kind.none", new[] { "No connection", "لا يوجد اتصال" } },
            { "wifi.sub", new[] { "{0}  ·  signal {1}%", "{0}  ·  الإشارة {1}%" } },
            { "router.sub", new[] { "jitter {0}  ·  loss {1}", "تذبذب {0}  ·  فقد {1}" } },
            { "router.na", new[] { "No reply", "لا يوجد رد" } },
            { "router.na.sub", new[] { "This router does not answer pings", "الراوتر لا يرد على البنق" } },

            { "diag.offline", new[] { "You are offline.", "أنت غير متصل." } },
            { "diag.wait", new[] { "Collecting data…", "جاري جمع البيانات…" } },
            { "diag.nonet", new[] { "No reply from the internet target.", "لا يوجد رد من هدف الإنترنت." } },
            { "diag.loss.local", new[] { "Packets are lost between you and the router — check Wi-Fi signal or cable.", "حزم تُفقد بينك وبين الراوتر — افحص إشارة الواي فاي أو الكيبل." } },
            { "diag.loss.isp", new[] { "Packets are lost on the provider / tower side.", "حزم تُفقد من جهة مزود الخدمة / البرج." } },
            { "diag.local", new[] { "Local network is unstable — move closer to the router or use a cable.", "الشبكة المحلية غير مستقرة — اقترب من الراوتر أو استخدم كيبل." } },
            { "diag.bg", new[] { "Heavy traffic on this PC ({0}) is hurting your ping.", "استهلاك عالي على جهازك ({0}) يؤثر على البنق." } },
            { "diag.hog", new[] { "{0} is using your line ({1}). Cap it on the Limiter page.", "{0} يستهلك خطك ({1}). حدّده من صفحة محدد السرعة." } },
            { "diag.hog.capped", new[] { "{0} is capped at {1}. Lower the limit if the ping is still unsteady.", "{0} محدَّد على {1}. قلل الحد إذا البنق ما زال غير ثابت." } },
            { "diag.hog.stale", new[] { "{0} was already connected before the limiter. Restart its call or stream once.", "{0} كان متصلاً قبل المحدد. أعد تشغيل مكالمته أو بثه مرة واحدة." } },
            { "diag.jitter.off", new[] { "Line jitter detected — switch Boost on.", "يوجد تذبذب بالخط — شغّل التثبيت." } },
            { "diag.jitter.on", new[] { "Jitter is coming from the provider / tower. Try Auto-Tune.", "التذبذب من مزود الخدمة / البرج. جرّب الضبط التلقائي." } },
            { "diag.ok", new[] { "Connection is stable.", "الاتصال مستقر." } },

            // optimize
            { "opt.wifi", new[] { "Wi-Fi Optimizer", "محسّن الواي فاي" } },
            { "opt.wifi.d", new[] { "Blocks the Windows background scans that cause a lag spike every minute.", "يمنع فحص الشبكات بالخلفية اللي يسبب قفزة بالبنق كل دقيقة." } },
            { "opt.wifi.none", new[] { "No Wi-Fi in use — not needed on a cable connection.", "لا يوجد واي فاي مستخدم — غير مطلوب مع الكيبل." } },
            { "opt.wifi.on", new[] { "{0}  ·  signal {1}%  ·  scans are blocked", "{0}  ·  الإشارة {1}%  ·  الفحص محظور الآن" } },
            { "opt.wifi.idle", new[] { "{0}  ·  signal {1}%  ·  activates together with Boost", "{0}  ·  الإشارة {1}%  ·  يتفعّل مع التثبيت" } },
            { "opt.wifi.err", new[] { "The Wi-Fi driver refused the request (not supported).", "تعريف الواي فاي رفض الطلب (غير مدعوم)." } },
            { "opt.classic", new[] { "Classic keep-alive (V1 method)", "الطريقة الكلاسيكية (نسخة V1)" } },
            { "opt.classic.d", new[] { "Also visits speedtest.net every 5 s like version 1. Uses about 150 MB per hour.", "يزور speedtest.net كل 5 ثواني مثل النسخة الأولى. يستهلك تقريباً 150 MB بالساعة." } },
            { "opt.sys", new[] { "System optimizations", "تحسينات النظام" } },
            { "opt.sys.sub", new[] { "One-time Windows tweaks. Asks for administrator approval. Fully reversible.", "تعديلات ويندوز لمرة واحدة. تطلب صلاحية المسؤول. يمكن التراجع عنها بالكامل." } },
            { "tw.nagle", new[] { "Disable Nagle's algorithm", "تعطيل خوارزمية Nagle" } },
            { "tw.nagle.d", new[] { "Sends game packets immediately instead of batching them (TCP games).", "يرسل حزم اللعبة فوراً بدون تجميعها (ألعاب TCP)." } },
            { "tw.throttle", new[] { "Disable network throttling", "تعطيل خنق الشبكة" } },
            { "tw.throttle.d", new[] { "Removes the Windows multimedia limit on network packets.", "يزيل حد ويندوز على حزم الشبكة أثناء تشغيل الوسائط." } },
            { "tw.power", new[] { "Network power saving off", "إيقاف توفير الطاقة للشبكة" } },
            { "tw.power.d", new[] { "Wi-Fi adapter at maximum performance, no USB sleep (USB modems, tethering).", "كرت الواي فاي بأقصى أداء، ومنع نوم منافذ USB (مودم USB، الربط)." } },
            { "tw.do", new[] { "Tame Windows Update", "تهدئة تحديثات ويندوز" } },
            { "tw.do.d", new[] { "No uploading updates to other PCs; background downloads capped at 25% of the line.", "يمنع رفع التحديثات لأجهزة ثانية، ويحدد تحميل الخلفية بـ 25% من الخط." } },
            { "tw.qos", new[] { "Game traffic priority (DSCP 46)", "أولوية حزم الألعاب (DSCP 46)" } },
            { "tw.qos.d", new[] { "Marks packets of your listed games as high priority. Helps most on Wi-Fi.", "يعلّم حزم ألعابك كأولوية عالية. أكثر فائدة على الواي فاي." } },
            { "pill.on", new[] { "Applied", "مفعّل" } },
            { "pill.off", new[] { "Not applied", "غير مفعّل" } },
            { "pill.na", new[] { "Not available", "غير متوفر" } },
            { "pill.check", new[] { "Checking…", "جاري الفحص…" } },
            { "opt.apply", new[] { "Apply selected", "تطبيق المحدد" } },
            { "opt.restore", new[] { "Restore defaults", "استرجاع الأصل" } },
            { "opt.note", new[] { "Nagle and throttling changes take effect after restarting Windows.", "تعديل Nagle والخنق يشتغل بعد إعادة تشغيل ويندوز." } },
            { "opt.applying", new[] { "Working… approve the Windows prompt.", "جاري التنفيذ… وافق على نافذة ويندوز." } },
            { "opt.done", new[] { "Done. Restart Windows to finish.", "تم. أعد تشغيل ويندوز لإكمال التفعيل." } },
            { "opt.restored", new[] { "Windows defaults restored.", "تم استرجاع إعدادات ويندوز الأصلية." } },
            { "opt.denied", new[] { "Cancelled — administrator approval was not given.", "أُلغي — لم تُمنح صلاحية المسؤول." } },
            { "opt.fail", new[] { "Some tweaks could not be applied (code {0}).", "بعض التعديلات لم تُطبّق (رمز {0})." } },

            // games
            { "games.sub", new[] { "In AUTO mode, Boost switches on by itself whenever one of these games is running.", "في الوضع التلقائي، يشتغل التثبيت لوحده أول ما تشتغل أي لعبة من هذي القائمة." } },
            { "games.count", new[] { "Games list  ·  {0}", "قائمة الألعاب  ·  {0}" } },
            { "games.detected", new[] { "RUNNING NOW", "تعمل الآن" } },
            { "games.none", new[] { "No game running", "لا توجد لعبة تعمل" } },
            { "games.none.sub", new[] { "Start a game from the list", "شغّل لعبة من القائمة" } },
            { "games.active.sub", new[] { "Detected by Latency Optimizer", "تم اكتشافها" } },
            { "games.add.run", new[] { "Add a running game", "إضافة لعبة تعمل الآن" } },
            { "games.add.exe", new[] { "Add .exe file", "إضافة ملف exe" } },
            { "games.remove", new[] { "Remove selected", "حذف المحدد" } },
            { "games.prio", new[] { "High CPU priority", "أولوية عالية للمعالج" } },
            { "games.prio.d", new[] { "Gives the detected game High priority in Windows. Games protected by anti-cheat may ignore it.", "يعطي اللعبة أولوية عالية في ويندوز. الألعاب المحمية بمضاد الغش قد تتجاهله." } },
            { "games.tip.t", new[] { "Tip", "نصيحة" } },
            { "games.tip", new[] { "Set Boost to AUTO on the Dashboard: no data is used while you are not playing, and stabilization starts the moment a game opens.", "اختر «تلقائي» من الرئيسية: ما يستهلك بيانات وأنت ما تلعب، ويبدأ التثبيت أول ما تفتح اللعبة." } },
            { "games.running", new[] { "running", "تعمل" } },
            { "games.filter", new[] { "Programs (*.exe)|*.exe", "برامج (*.exe)|*.exe" } },
            { "pick.title", new[] { "Choose a running game", "اختر لعبة تعمل الآن" } },
            { "pick.add", new[] { "Add", "إضافة" } },
            { "pick.cancel", new[] { "Cancel", "إلغاء" } },

            // auto-tune
            { "tune.desc", new[] { "Auto-Tune measures your line with Boost off and with every pulse level, then selects the lightest one that gives the steadiest ping. Takes about 2 minutes — don't download or play while it runs.", "الضبط التلقائي يقيس خطك بدون تثبيت ومع كل مستوى نبض، ثم يختار أخف مستوى يعطيك أثبت بنق. يأخذ دقيقتين تقريباً — لا تحمّل ولا تلعب أثناء الفحص." } },
            { "tune.start", new[] { "Start Auto-Tune", "ابدأ الضبط التلقائي" } },
            { "tune.stop", new[] { "Stop", "إيقاف" } },
            { "tune.idle", new[] { "Ready", "جاهز" } },
            { "tune.running", new[] { "Testing {0}  ·  round {1} of {2}", "جاري فحص {0}  ·  الجولة {1} من {2}" } },
            { "tune.finishing", new[] { "Calculating results…", "جاري حساب النتائج…" } },
            { "tune.left", new[] { "About {0} seconds left", "باقي {0} ثانية تقريباً" } },
            { "tune.hint", new[] { "Results appear here. Run it on the connection you actually play on.", "النتائج تظهر هنا. شغّله على نفس الاتصال اللي تلعب عليه." } },
            { "tune.cancelled", new[] { "Stopped — nothing was changed.", "تم الإيقاف — لم يتغير شيء." } },
            { "tune.nodata", new[] { "No ping replies — check your connection and try again.", "لا يوجد رد على البنق — افحص اتصالك وحاول مرة ثانية." } },
            { "tune.done", new[] { "Finished", "انتهى" } },
            { "tune.c.mode", new[] { "MODE", "الوضع" } },
            { "tune.c.avg", new[] { "AVERAGE", "المتوسط" } },
            { "tune.c.jitter", new[] { "JITTER", "التذبذب" } },
            { "tune.c.p95", new[] { "WORST 5%", "أسوأ 5%" } },
            { "tune.c.loss", new[] { "LOSS", "الفقد" } },
            { "tune.c.score", new[] { "SCORE", "التقييم" } },
            { "tune.off", new[] { "Boost off", "بدون تثبيت" } },
            { "tune.best", new[] { "BEST", "الأفضل" } },
            { "tune.res.good", new[] { "Best for your line: {0}. Jitter went from {1} ms to {2} ms ({3}% steadier). {0} mode is now selected.", "الأفضل لخطك: {0}. التذبذب نزل من {1} ms إلى {2} ms (أثبت بنسبة {3}%). تم اختيار وضع {0}." } },
            { "tune.res.same", new[] { "Best for your line: {0}. {0} mode is now selected.", "الأفضل لخطك: {0}. تم اختيار وضع {0}." } },
            { "tune.res.flat", new[] { "Your line is already steady — extra pulses change very little here (normal on fiber or cable). Eco mode is selected to keep things light.", "خطك ثابت أصلاً — النبض الإضافي ما يغيّر كثير هنا (طبيعي مع الألياف أو الكيبل). تم اختيار الوضع الاقتصادي عشان يكون خفيف." } },
            { "tune.res.nohelp", new[] { "The pulse makes little difference on your line right now: the jitter ({0} ms) is coming from the provider / tower or from other traffic, not from the link falling asleep. Eco mode is selected to keep things light. Check the Diagnosis box on the Dashboard.", "النبض ما يفرق كثير على خطك حالياً: التذبذب ({0} ms) جاي من مزود الخدمة / البرج أو من استهلاك ثاني، مو من نوم الخط. تم اختيار الوضع الاقتصادي عشان يكون خفيف. شوف خانة التشخيص بالرئيسية." } },
            { "tune.res.boostoff", new[] { " Switch Boost ON to use it.", " شغّل التثبيت عشان تستفيد منه." } },

            // settings
            { "set.autostart", new[] { "Start with Windows", "التشغيل مع ويندوز" } },
            { "set.autostart.d", new[] { "Launches quietly in the system tray when you sign in.", "يشتغل بهدوء بجانب الساعة عند تسجيل الدخول." } },
            { "set.min", new[] { "Start minimized", "البدء مصغّراً" } },
            { "set.min.d", new[] { "Opens straight to the tray instead of showing this window.", "يفتح مباشرة بجانب الساعة بدون إظهار هذي النافذة." } },
            { "set.notify", new[] { "Notifications", "الإشعارات" } },
            { "set.notify.d", new[] { "Shows a message when Boost turns on or off by itself.", "يظهر تنبيه لما يشتغل أو يتوقف التثبيت تلقائياً." } },
            { "set.trayping", new[] { "Live ping on the tray icon", "البنق المباشر على أيقونة الشريط" } },
            { "set.trayping.d", new[] { "The tray icon shows your current ping, coloured by quality.", "الأيقونة بجانب الساعة تعرض البنق الحالي بلون حسب الجودة." } },
            { "set.lang", new[] { "Language", "اللغة" } },
            { "set.target", new[] { "Ping target", "هدف البنق" } },
            { "set.target.auto", new[] { "Automatic — fastest of {0}", "تلقائي — الأسرع من {0}" } },
            { "set.target.custom", new[] { "Using: {0}", "المستخدم: {0}" } },
            { "set.apply", new[] { "Apply", "تطبيق" } },
            { "set.exit", new[] { "Exit program", "إغلاق البرنامج" } },
            { "about.text", new[] { "Keeps your 5G / Wi-Fi link awake with a steady, feather-light pulse so it never drops into power saving between game packets, blocks Wi-Fi scan spikes, and tunes Windows for low latency.", "يبقي خط الـ 5G / الواي فاي نشطاً بنبض ثابت وخفيف جداً حتى ما يدخل وضع توفير الطاقة بين حزم اللعبة، ويمنع قفزات فحص الواي فاي، ويضبط ويندوز لأقل تأخير." } },
            { "about.usage", new[] { "Data use:  Eco ≈ 2 MB/h  ·  Balanced ≈ 5 MB/h  ·  Ultra ≈ 10 MB/h  ·  Extreme ≈ 20 MB/h", "الاستهلاك:  اقتصادي ≈ 2 MB/س  ·  متوازن ≈ 5 MB/س  ·  قوي ≈ 10 MB/س  ·  أقصى ≈ 20 MB/س" } },
            { "about.credit", new[] { "Othman Malallah  ·  Instagram: ippokw", "Othman Malallah  ·  Instagram: ippokw" } },

            // tray
            { "tray.open", new[] { "Open dashboard", "فتح البرنامج" } },
            { "tray.exit", new[] { "Exit", "إغلاق" } },
            { "tray.boost", new[] { "Boost: {0}", "التثبيت: {0}" } },
            { "tray.mode", new[] { "Pulse mode", "وضع النبض" } },
            { "tray.noping", new[] { "No reply", "لا يوجد رد" } },
            { "ntf.tray.t", new[] { "Still running", "البرنامج يعمل" } },
            { "ntf.tray", new[] { "Latency Optimizer keeps working from the system tray.", "Latency Optimizer يكمل شغله بجانب الساعة." } },
            { "ntf.game.on.t", new[] { "Boost ON", "التثبيت يعمل" } },
            { "ntf.game.on", new[] { "{0} detected — stabilizing your ping.", "تم اكتشاف {0} — جاري تثبيت البنق." } },
            { "ntf.game.off.t", new[] { "Boost paused", "التثبيت متوقف مؤقتاً" } },
            { "ntf.game.off", new[] { "Game closed — waiting for the next one.", "اللعبة أُغلقت — بانتظار اللعبة القادمة." } },
        };
    }
}
