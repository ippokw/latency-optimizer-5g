using System;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace LO5G
{
    /// <summary>The adapter that currently carries internet traffic.</summary>
    sealed class NetSnapshot
    {
        public string Id = "", Name = "", Desc = "", Kind = "none";
        public IPAddress Local, Gateway;
        public NetworkInterface Nic;
    }

    static class NetInfo
    {
        static readonly byte[] probe = Encoding.ASCII.GetBytes("LO5G-route-probe");

        public static NetSnapshot Detect()
        {
            var s = new NetSnapshot();
            try
            {
                // Ask Windows which local address it would use to reach the internet (sends nothing).
                IPAddress local = null;
                try
                {
                    using (var u = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
                    {
                        u.Connect(new IPEndPoint(IPAddress.Parse("1.1.1.1"), 53));
                        local = ((IPEndPoint)u.LocalEndPoint).Address;
                    }
                }
                catch { }
                if (local == null || IPAddress.IsLoopback(local) || local.Equals(IPAddress.Any)) return s;

                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up) continue;
                    IPInterfaceProperties p;
                    try { p = ni.GetIPProperties(); } catch { continue; }
                    bool mine = false;
                    foreach (var ua in p.UnicastAddresses)
                        if (ua.Address.Equals(local)) { mine = true; break; }
                    if (!mine) continue;

                    s.Local = local;
                    s.Nic = ni;
                    s.Id = ni.Id;
                    s.Name = ni.Name;
                    s.Desc = ni.Description;
                    foreach (var g in p.GatewayAddresses)
                    {
                        if (g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any))
                        {
                            s.Gateway = g.Address;
                            break;
                        }
                    }
                    s.Kind = KindOf(ni);
                    break;
                }
            }
            catch (Exception ex) { Program.Log(ex); }
            return s;
        }

        static string KindOf(NetworkInterface ni)
        {
            string d = (ni.Description ?? "").ToLowerInvariant();
            switch (ni.NetworkInterfaceType)
            {
                case NetworkInterfaceType.Wireless80211: return "wifi";
                case NetworkInterfaceType.Wwanpp:
                case NetworkInterfaceType.Wwanpp2: return "cellular";
                case NetworkInterfaceType.Ppp:
                case NetworkInterfaceType.Tunnel: return "vpn";
            }
            if (d.Contains("vpn") || d.Contains("wireguard") || d.Contains("wintun") || d.Contains("tap-windows") || d.Contains("tunnel")) return "vpn";
            if (d.Contains("rndis") || d.Contains("remote ndis") || d.Contains("apple mobile") || d.Contains("usb tether")) return "usb";
            switch (ni.NetworkInterfaceType)
            {
                case NetworkInterfaceType.Ethernet:
                case NetworkInterfaceType.GigabitEthernet:
                case NetworkInterfaceType.FastEthernetT:
                case NetworkInterfaceType.FastEthernetFx:
                case NetworkInterfaceType.Ethernet3Megabit: return "ethernet";
            }
            return "other";
        }

        /// <summary>
        /// What the ping monitor measures. A custom address is used alone. Otherwise three independent
        /// public anycast services are probed together (best route first) and the fastest answer counts.
        /// </summary>
        public static IPAddress[] PickTargets(string custom)
        {
            custom = (custom ?? "").Trim();
            if (custom.Length > 0)
            {
                IPAddress ip;
                if (IPAddress.TryParse(custom, out ip) && ip.AddressFamily == AddressFamily.InterNetwork) return new[] { ip };
                try
                {
                    foreach (var a in Dns.GetHostAddresses(custom))
                        if (a.AddressFamily == AddressFamily.InterNetwork) return new[] { a };
                }
                catch { }
            }

            string[] cands = { "8.8.8.8", "1.1.1.1", "9.9.9.9" };
            var cost = new double[cands.Length];
            Parallel.For(0, cands.Length, i => { cost[i] = ProbeCost(IPAddress.Parse(cands[i])); });
            var order = new List<int> { 0, 1, 2 };
            order.Sort((x, y) => cost[x].CompareTo(cost[y]));
            var alive = new List<IPAddress>();
            foreach (int i in order) if (cost[i] < double.MaxValue) alive.Add(IPAddress.Parse(cands[i]));
            if (alive.Count == 0) foreach (string c in cands) alive.Add(IPAddress.Parse(c));   // keep trying all
            return alive.ToArray();
        }

        /// <summary>How good a target is: mostly its best-case latency (the real path length), plus a penalty for losses.</summary>
        static double ProbeCost(IPAddress ip)
        {
            const int Probes = 6;
            var ok = new List<long>();
            try
            {
                using (var p = new Ping())
                {
                    GC.SuppressFinalize(p);   // see PingMonitor.Probe: no finalizer while a request may be in flight
                    for (int i = 0; i < Probes; i++)
                    {
                        try
                        {
                            var r = p.Send(ip, 800);
                            if (r != null && r.Status == IPStatus.Success) ok.Add(r.RoundtripTime);
                        }
                        catch { }
                        System.Threading.Thread.Sleep(60);
                    }
                }
            }
            catch { }
            if (ok.Count == 0) return double.MaxValue;
            ok.Sort();
            return ok[0] * 0.6 + ok[ok.Count / 2] * 0.4 + (Probes - ok.Count) * 40;
        }

        /// <summary>
        /// Picks the hop limit for pulse packets: far enough to cross the access link (router, modem,
        /// radio) and reach the provider's network, but always short of the target itself.
        /// </summary>
        public static int FindPulseTtl(IPAddress target)
        {
            const int Max = 8;
            var status = new IPStatus[Max + 1];
            var addr = new IPAddress[Max + 1];
            for (int i = 0; i <= Max; i++) status[i] = IPStatus.Unknown;

            try
            {
                Parallel.For(1, Max + 1, new ParallelOptions { MaxDegreeOfParallelism = Max }, t =>
                {
                    try
                    {
                        using (var p = new Ping())
                        {
                            GC.SuppressFinalize(p);
                            var r = p.Send(target, 900, probe, new PingOptions(t, true));
                            if (r != null) { status[t] = r.Status; addr[t] = r.Address; }
                        }
                    }
                    catch { }
                });
            }
            catch { }

            int reached = 0, firstPublic = 0;
            for (int t = 1; t <= Max; t++)
            {
                if (status[t] == IPStatus.Success && reached == 0) reached = t;
                bool expired = status[t] == IPStatus.TtlExpired || status[t] == IPStatus.TimeExceeded;
                if (expired && firstPublic == 0 && addr[t] != null && !IsPrivate(addr[t])) firstPublic = t;
            }

            int ttl = firstPublic > 0 ? Math.Max(3, Math.Min(6, firstPublic)) : 4;
            if (reached > 0) ttl = Math.Min(ttl, reached - 1);
            return Math.Max(1, ttl);
        }

        public static bool IsPrivate(IPAddress ip)
        {
            byte[] b = ip.GetAddressBytes();
            if (b.Length != 4) return false;
            if (b[0] == 10 || b[0] == 127) return true;
            if (b[0] == 172 && b[1] >= 16 && b[1] <= 31) return true;
            if (b[0] == 192 && b[1] == 168) return true;
            if (b[0] == 169 && b[1] == 254) return true;
            return false;
        }
    }

    /// <summary>
    /// Stops the periodic Wi-Fi lag spike. Windows scans for other networks in the background every
    /// minute or so, and the radio leaves your channel while it does: a 100-300 ms spike each time.
    /// While Boost is on this turns background scanning off and puts the driver in media-streaming
    /// mode. Windows restores both automatically when the app exits or the adapter reconnects.
    /// </summary>
    sealed class WifiOptimizer
    {
        const int OpBackgroundScan = 2, OpStreamingMode = 3, OpCurrentConnection = 7, OpChannel = 8;

        readonly object lk = new object();
        IntPtr h = IntPtr.Zero;
        long retryAfter;
        Guid iface;
        volatile bool present, applied, failed;
        volatile string ssid;
        volatile int signal, channel, rate;

        /// <summary>A Wi-Fi adapter is connected right now.</summary>
        public bool Present { get { return present; } }
        public bool Applied { get { return applied; } }
        public bool Failed { get { return failed; } }
        public string Ssid { get { return ssid; } }
        public int Signal { get { return signal; } }
        public int Channel { get { return channel; } }
        public int RateMbps { get { return rate; } }

        bool Open()
        {
            if (h != IntPtr.Zero) return true;
            if (PingMonitor.Now < retryAfter) return false;
            try
            {
                uint ver;
                IntPtr hh;
                if (Native.WlanOpenHandle(2, IntPtr.Zero, out ver, out hh) == 0) { h = hh; return true; }
            }
            catch { }
            retryAfter = PingMonitor.Now + 60000;   // no WLAN service on this PC: do not keep retrying
            return false;
        }

        public void Refresh()
        {
            lock (lk) { RefreshCore(); }
        }

        void RefreshCore()
        {
            bool found = false;
            if (Open())
            {
                IntPtr list = IntPtr.Zero;
                try
                {
                    if (Native.WlanEnumInterfaces(h, IntPtr.Zero, out list) == 0 && list != IntPtr.Zero)
                    {
                        int n = Marshal.ReadInt32(list);
                        for (int i = 0; i < n && !found; i++)
                        {
                            IntPtr item = IntPtr.Add(list, 8 + i * 532);
                            int state = Marshal.ReadInt32(item, 528);
                            if (state != 1) continue;          // 1 = connected
                            iface = (Guid)Marshal.PtrToStructure(item, typeof(Guid));
                            found = true;
                        }
                    }
                }
                catch { }
                finally { if (list != IntPtr.Zero) Native.WlanFreeMemory(list); }
            }

            if (found) ReadConnection();
            else { ssid = null; signal = 0; channel = 0; rate = 0; applied = false; }
            present = found;
        }

        void ReadConnection()
        {
            IntPtr data = IntPtr.Zero;
            try
            {
                uint size;
                int type;
                if (Native.WlanQueryInterface(h, ref iface, OpCurrentConnection, IntPtr.Zero, out size, out data, out type) == 0
                    && data != IntPtr.Zero && size >= 588)
                {
                    int len = Math.Max(0, Math.Min(32, Marshal.ReadInt32(data, 520)));
                    var raw = new byte[len];
                    Marshal.Copy(IntPtr.Add(data, 524), raw, 0, len);
                    ssid = Encoding.UTF8.GetString(raw);
                    signal = Marshal.ReadInt32(data, 576);
                    rate = Marshal.ReadInt32(data, 580) / 1000;
                }
            }
            catch { }
            finally { if (data != IntPtr.Zero) Native.WlanFreeMemory(data); }

            data = IntPtr.Zero;
            try
            {
                uint size;
                int type;
                if (Native.WlanQueryInterface(h, ref iface, OpChannel, IntPtr.Zero, out size, out data, out type) == 0
                    && data != IntPtr.Zero && size >= 4)
                    channel = Marshal.ReadInt32(data);
            }
            catch { }
            finally { if (data != IntPtr.Zero) Native.WlanFreeMemory(data); }
        }

        /// <summary>Call repeatedly while Boost is on: Windows resets both settings on every reconnect.</summary>
        public void Apply(bool on)
        {
            lock (lk)
            {
                if (!on)
                {
                    if (applied && h != IntPtr.Zero)
                    {
                        Set(OpBackgroundScan, 1);
                        Set(OpStreamingMode, 0);
                    }
                    applied = false;
                    failed = false;
                    return;
                }
                RefreshCore();
                if (!present) { applied = false; failed = false; return; }
                uint a = Set(OpBackgroundScan, 0);
                uint b = Set(OpStreamingMode, 1);
                applied = a == 0 || b == 0;
                failed = !applied;
            }
        }

        uint Set(int opcode, int value)
        {
            IntPtr p = Marshal.AllocHGlobal(4);
            try
            {
                Marshal.WriteInt32(p, value);
                return Native.WlanSetInterface(h, ref iface, opcode, 4, p, IntPtr.Zero);
            }
            catch { return 0xFFFFFFFF; }
            finally { Marshal.FreeHGlobal(p); }
        }

        public void Close()
        {
            lock (lk)
            {
                if (h == IntPtr.Zero) return;
                if (applied)
                {
                    Set(OpBackgroundScan, 1);
                    Set(OpStreamingMode, 0);
                }
                try { Native.WlanCloseHandle(h, IntPtr.Zero); } catch { }
                h = IntPtr.Zero;
                applied = false;
            }
        }
    }
}
