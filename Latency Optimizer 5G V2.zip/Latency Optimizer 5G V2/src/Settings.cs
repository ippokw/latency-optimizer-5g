using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LO5G
{
    /// <summary>User settings, stored as key=value lines in %AppData%\LatencyOptimizer5G\settings.ini.</summary>
    static class Settings
    {
        // Declared first: static initialisers run in textual order and Games below depends on it.
        static readonly string[] DefaultGames =
        {
            "FortniteClient-Win64-Shipping.exe", "VALORANT-Win64-Shipping.exe", "cs2.exe", "r5apex.exe", "r5apex_dx12.exe",
            "cod.exe", "RocketLeague.exe", "League of Legends.exe", "Overwatch.exe", "TslGame.exe", "RainbowSix.exe",
            "GTA5.exe", "GTA5_Enhanced.exe", "FC26.exe", "FC25.exe", "eFootball.exe", "dota2.exe", "RobloxPlayerBeta.exe",
            "Marvel-Win64-Shipping.exe", "EscapeFromTarkov.exe", "destiny2.exe", "GenshinImpact.exe", "bf6.exe",
            "DeadByDaylight-Win64-Shipping.exe", "PUBG-Win64-Shipping.exe", "Rust.exe", "Minecraft.Windows.exe"
        };

        // Programs that typically upload in the background. Limited only if the user switches the limiter on.
        static readonly string[] DefaultLimitApps =
        {
            "Discord.exe", "OneDrive.exe", "Dropbox.exe", "GoogleDriveFS.exe", "qbittorrent.exe", "uTorrent.exe"
        };

        /// <summary>Upload limit choices, kbit/s.</summary>
        public static readonly int[] LimitChoices = { 500, 1000, 2000, 3000 };

        public static bool Limiter = false;
        public static int LimitKbps = 1000;
        public static List<string> LimitApps = new List<string>(DefaultLimitApps);

        public static int Boost = 2;                 // 0 off, 1 auto (only while a game runs), 2 on
        public static int Mode = 1;                  // 0 eco, 1 balanced, 2 ultra, 3 extreme
        public static bool WifiOpt = true;
        public static bool Classic = false;
        public static bool GamePriority = false;
        public static bool StartMinimized = false;
        public static bool Notifications = true;
        public static bool TrayPing = true;
        public static bool TrayHintShown = false;
        public static string Target = "";            // empty = pick automatically
        public static string Lang = "";              // empty = follow Windows
        public static List<string> Games = new List<string>(DefaultGames);

        /// <summary>Pulses per second for each mode.</summary>
        public static readonly int[] ModePps = { 10, 30, 60, 125 };

        /// <summary>Debug runs must never overwrite the real settings.</summary>
        public static bool ReadOnly;

        public static string Dir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LatencyOptimizer5G"); }
        }

        static string FilePath { get { return Path.Combine(Dir, "settings.ini"); } }

        public static void Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return;
                foreach (var raw in File.ReadAllLines(FilePath, Encoding.UTF8))
                {
                    int eq = raw.IndexOf('=');
                    if (eq <= 0) continue;
                    string k = raw.Substring(0, eq).Trim(), v = raw.Substring(eq + 1).Trim();
                    switch (k)
                    {
                        case "Boost": Boost = Clamp(ToInt(v, Boost), 0, 2); break;
                        case "Mode": Mode = Clamp(ToInt(v, Mode), 0, ModePps.Length - 1); break;
                        case "WifiOpt": WifiOpt = v == "1"; break;
                        case "Classic": Classic = v == "1"; break;
                        case "GamePriority": GamePriority = v == "1"; break;
                        case "StartMinimized": StartMinimized = v == "1"; break;
                        case "Notifications": Notifications = v == "1"; break;
                        case "TrayPing": TrayPing = v == "1"; break;
                        case "TrayHintShown": TrayHintShown = v == "1"; break;
                        case "Target": Target = v; break;
                        case "Lang": Lang = v == "ar" || v == "en" ? v : ""; break;
                        case "Games":
                            Games = v.Split('|').Select(s => s.Trim()).Where(s => s.Length > 0)
                                     .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                            break;
                        case "Limiter": Limiter = v == "1"; break;
                        case "LimitKbps": LimitKbps = Clamp(ToInt(v, LimitKbps), 100, 100000); break;
                        case "LimitApps":
                            LimitApps = v.Split('|').Select(s => s.Trim()).Where(s => s.Length > 0)
                                         .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                            break;
                    }
                }
            }
            catch (Exception ex) { Program.Log(ex); }
        }

        public static void Save()
        {
            if (ReadOnly) return;
            try
            {
                Directory.CreateDirectory(Dir);
                var sb = new StringBuilder();
                sb.AppendLine("Boost=" + Boost);
                sb.AppendLine("Mode=" + Mode);
                sb.AppendLine("WifiOpt=" + B(WifiOpt));
                sb.AppendLine("Classic=" + B(Classic));
                sb.AppendLine("GamePriority=" + B(GamePriority));
                sb.AppendLine("StartMinimized=" + B(StartMinimized));
                sb.AppendLine("Notifications=" + B(Notifications));
                sb.AppendLine("TrayPing=" + B(TrayPing));
                sb.AppendLine("TrayHintShown=" + B(TrayHintShown));
                sb.AppendLine("Target=" + Target);
                sb.AppendLine("Lang=" + Lang);
                sb.AppendLine("Games=" + string.Join("|", Games));
                sb.AppendLine("Limiter=" + B(Limiter));
                sb.AppendLine("LimitKbps=" + LimitKbps);
                sb.AppendLine("LimitApps=" + string.Join("|", LimitApps));
                string tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
                if (File.Exists(FilePath)) File.Delete(FilePath);
                File.Move(tmp, FilePath);
            }
            catch (Exception ex) { Program.Log(ex); }
        }

        static string B(bool b) { return b ? "1" : "0"; }
        static int ToInt(string s, int def) { int v; return int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out v) ? v : def; }
        static int Clamp(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
    }

    /// <summary>"Start with Windows" through the per-user Run key (no administrator needed).</summary>
    static class Autostart
    {
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string Name = "LatencyOptimizer5G";

        public static bool Enabled
        {
            get
            {
                try
                {
                    using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                    {
                        string v = k == null ? null : k.GetValue(Name) as string;
                        return v != null && v.IndexOf(Application.ExecutablePath, StringComparison.OrdinalIgnoreCase) >= 0;
                    }
                }
                catch { return false; }
            }
            set
            {
                try
                {
                    using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
                    {
                        if (value) k.SetValue(Name, "\"" + Application.ExecutablePath + "\" --tray", RegistryValueKind.String);
                        else k.DeleteValue(Name, false);
                    }
                }
                catch (Exception ex) { Program.Log(ex); }
            }
        }
    }

    static class Fmt
    {
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        public static string N0(double v) { return Math.Round(v).ToString("0", Inv); }
        public static string N1(double v) { return v.ToString("0.0", Inv); }

        public static string Rate(double bps)
        {
            if (bps >= 1e6) return (bps / 1e6).ToString("0.0", Inv) + " Mbps";
            return (bps / 1e3).ToString("0", Inv) + " kbps";
        }

        public static string Bytes(long b)
        {
            if (b >= 1L << 30) return (b / 1073741824.0).ToString("0.00", Inv) + " GB";
            if (b >= 1L << 20) return (b / 1048576.0).ToString("0.0", Inv) + " MB";
            return (b / 1024.0).ToString("0", Inv) + " KB";
        }
    }
}
