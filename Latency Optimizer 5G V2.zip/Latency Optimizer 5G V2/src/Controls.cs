using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LO5G
{
    /// <summary>Base for the owner-drawn controls: flicker-free, and painted over the parent's colour.</summary>
    class UiControl : Control
    {
        public UiControl()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            SetStyle(ControlStyles.Selectable | ControlStyles.StandardDoubleClick, false);
            TabStop = false;
        }

        protected Color Outer { get { return Parent != null ? Parent.BackColor : Theme.Bg; } }

        protected Graphics Begin(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Outer);
            Draw.Prep(g);
            return g;
        }

        protected static int S(int v) { return Theme.S(v); }
    }

    /// <summary>A text label that follows the UI direction.</summary>
    sealed class Txt : UiControl
    {
        public HA Align = HA.Start, VAlign = HA.Center;
        public bool Ltr, Wrap;

        public Txt(string text, Font font, Color color)
        {
            Font = font;
            ForeColor = color;
            Text = text;
        }

        protected override void OnTextChanged(EventArgs e) { base.OnTextChanged(e); Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            Draw.Str(g, Text, Font, ForeColor, ClientRectangle, Align, VAlign, Ltr, Wrap);
        }
    }

    /// <summary>A bitmap (the logo).</summary>
    sealed class Pic : UiControl
    {
        readonly Image img;
        public Pic(Image image) { img = image; }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            if (img != null) g.DrawImage(img, ClientRectangle);
        }
    }

    /// <summary>An icon glyph on a soft tinted tile.</summary>
    sealed class GlyphTile : UiControl
    {
        readonly string glyph;
        readonly Color color;
        public GlyphTile(string glyph, Color color) { this.glyph = glyph; this.color = color; }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0, 0, Width - 1, Height - 1);
            Draw.FillRound(g, Color.FromArgb(34, color), r, S(10));
            Draw.Str(g, glyph, Theme.Ico(13f), color, r, HA.Center, HA.Center, true);
        }
    }

    sealed class Toggle : UiControl
    {
        bool on;
        public event Action<bool> Toggled;

        public Toggle() { Cursor = Cursors.Hand; }

        public bool Checked
        {
            get { return on; }
            set { if (on != value) { on = value; Invalidate(); } }
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            if (!Enabled) return;
            on = !on;
            Invalidate();
            var h = Toggled;
            if (h != null) h(on);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            float h = Math.Min(Height - 1, Theme.Sf(24)), y = (Height - h) / 2f;
            var track = new RectangleF(0.5f, y, Width - 1f, h);
            Draw.FillRound(g, on ? Theme.Accent : Color.FromArgb(58, 66, 94), track, h / 2f);
            float d = h - Theme.Sf(6), x = on ? track.Right - d - Theme.Sf(3) : track.X + Theme.Sf(3);
            using (var b = new SolidBrush(on ? Color.White : Color.FromArgb(200, 206, 224)))
                g.FillEllipse(b, x, y + Theme.Sf(3), d, d);
        }
    }

    sealed class Check : UiControl
    {
        bool on;
        public Check() { Cursor = Cursors.Hand; }

        public bool Checked
        {
            get { return on; }
            set { if (on != value) { on = value; Invalidate(); } }
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            if (Enabled) { on = !on; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(1, 1, Width - 3, Height - 3);
            if (on)
            {
                Draw.FillRound(g, Theme.Accent, r, S(5));
                Draw.Str(g, "", Theme.Ico(8.5f), Theme.OnAccent, new RectangleF(0, 0, Width, Height), HA.Center, HA.Center, true);
            }
            else Draw.StrokeRound(g, Theme.Muted, r, S(5), 1.5f);
        }
    }

    sealed class Btn : UiControl
    {
        public bool Primary;
        public string Glyph;
        bool hover, down;

        public Btn(string text, bool primary = false, string glyph = null)
        {
            Text = text;
            Primary = primary;
            Glyph = glyph;
            Font = Theme.F(9.5f, true);
            Cursor = Cursors.Hand;
        }

        protected override void OnTextChanged(EventArgs e) { base.OnTextChanged(e); Invalidate(); }
        protected override void OnEnabledChanged(EventArgs e) { base.OnEnabledChanged(e); Invalidate(); }
        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Color bg = Primary ? Theme.Accent : Theme.CardHi, fg = Primary ? Theme.OnAccent : Theme.Text;
            if (!Enabled) { bg = Theme.Mix(bg, Outer, 0.6f); fg = Theme.Mix(fg, bg, 0.5f); }
            else if (down) bg = Theme.Mix(bg, Color.Black, 0.18f);
            else if (hover) bg = Theme.Mix(bg, Color.White, 0.12f);
            Draw.FillRound(g, bg, r, S(9));
            if (!Primary) Draw.StrokeRound(g, Theme.Mix(Theme.Border, Color.White, 0.06f), r, S(9));

            if (string.IsNullOrEmpty(Glyph))
            {
                Draw.Str(g, Text, Font, fg, r, HA.Center);
                return;
            }
            Font gf = Theme.Ico(10.5f);
            float gw = Draw.Width(g, Glyph, gf), tw = Draw.Width(g, Text, Font), gap = Theme.Sf(4);
            float x = (Width - (gw + gap + tw)) / 2f;
            var gRect = new RectangleF(Loc.Rtl ? x + tw + gap : x, 0, gw, Height);
            var tRect = new RectangleF(Loc.Rtl ? x : x + gw + gap, 0, tw + 2, Height);
            Draw.Str(g, Glyph, gf, fg, gRect, HA.Center, HA.Center, true);
            Draw.Str(g, Text, Font, fg, tRect, HA.Center);
        }
    }

    /// <summary>Segmented selector (OFF | AUTO | ON).</summary>
    sealed class Seg : UiControl
    {
        readonly string[] items;
        int sel, hover = -1;
        public Color[] Colors;
        /// <summary>Items are values like "1 Mbps" that must keep their left-to-right order in Arabic.</summary>
        public bool Ltr;
        public event Action<int> Changed;

        public Seg(string[] items)
        {
            this.items = items;
            Font = Theme.F(9.5f, true);
            Cursor = Cursors.Hand;
        }

        public int Selected
        {
            get { return sel; }
            set { if (sel != value) { sel = value; Invalidate(); } }
        }

        int IndexAt(int x)
        {
            int n = items.Length;
            int i = Math.Max(0, Math.Min(n - 1, x * n / Math.Max(1, Width)));
            return Loc.Rtl ? n - 1 - i : i;
        }

        RectangleF RectOf(int i)
        {
            int n = items.Length, vi = Loc.Rtl ? n - 1 - i : i;
            float pad = Theme.Sf(3), w = (Width - 2 * pad) / n;
            return new RectangleF(pad + vi * w, pad, w, Height - 2 * pad);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int i = IndexAt(e.X);
            if (i != hover) { hover = i; Invalidate(); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { hover = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!Enabled || e.Button != MouseButtons.Left) return;
            int i = IndexAt(e.X);
            if (i == sel) return;
            sel = i;
            Invalidate();
            var h = Changed;
            if (h != null) h(i);
        }

        protected override void OnEnabledChanged(EventArgs e) { base.OnEnabledChanged(e); Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            float rad = Math.Min(Theme.Sf(10), Height / 2f);
            Draw.FillRound(g, Theme.Inset, r, rad);
            Draw.StrokeRound(g, Theme.Border, r, rad);
            for (int i = 0; i < items.Length; i++)
            {
                var ir = RectOf(i);
                Color fg = i == hover && Enabled ? Theme.Text : Theme.Dim;
                if (i == sel)
                {
                    Color c = Colors != null && i < Colors.Length ? Colors[i] : Theme.Accent;
                    if (!Enabled) c = Theme.Mix(c, Theme.Inset, 0.5f);
                    Draw.FillRound(g, c, ir, Math.Max(2, rad - Theme.Sf(3)));
                    fg = c.GetBrightness() > 0.42f ? Theme.OnAccent : Color.White;
                }
                Draw.Str(g, items[i], Font, fg, ir, HA.Center, HA.Center, Ltr);
            }
        }
    }

    sealed class NavItem : UiControl
    {
        readonly string glyph;
        bool selected, hover;

        public NavItem(string text, string glyph)
        {
            Text = text;
            this.glyph = glyph;
            Font = Theme.F(10f, true);
            Cursor = Cursors.Hand;
        }

        public bool Selected
        {
            get { return selected; }
            set { if (selected != value) { selected = value; Invalidate(); } }
        }

        protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            if (selected) Draw.FillRound(g, Theme.CardHi, r, S(9));
            else if (hover) Draw.FillRound(g, Theme.Mix(Theme.Side, Theme.CardHi, 0.5f), r, S(9));

            Color fg = selected ? Theme.Text : hover ? Theme.Text : Theme.Dim;
            Color ic = selected ? Theme.Accent : fg;
            float iw = Theme.Sf(40);
            var iconRect = new RectangleF(Loc.Rtl ? Width - iw : 0, 0, iw, Height);
            var textRect = new RectangleF(Loc.Rtl ? Theme.Sf(6) : iw, 0, Width - iw - Theme.Sf(6), Height);
            Draw.Str(g, glyph, Theme.Ico(11.5f), ic, iconRect, HA.Center, HA.Center, true);
            Draw.Str(g, Text, Font, fg, textRect, HA.Start);
        }
    }

    /// <summary>Rounded container. Children inherit the card colour as their background.</summary>
    sealed class CardPanel : Panel
    {
        public Color OuterColor = Theme.Bg;

        public CardPanel()
        {
            BackColor = Theme.Card;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaintBackground(PaintEventArgs e) { }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(OuterColor);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Draw.FillRound(g, Theme.Card, r, Theme.S(12));
            Draw.StrokeRound(g, Theme.Border, r, Theme.S(12));
        }
    }

    /// <summary>A headline number with its label, unit and a small note.</summary>
    sealed class StatBox : UiControl
    {
        readonly string label, unit;
        string value = "—", sub = "";
        Color color = Theme.Text;

        public StatBox(string label, string unit) { this.label = label; this.unit = unit; }

        public void Set(string v, string s, Color c)
        {
            if (v == value && s == sub && c == color) return;
            value = v; sub = s; color = c;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Draw.FillRound(g, Theme.Card, r, S(12));
            Draw.StrokeRound(g, Theme.Border, r, S(12));

            float pad = Theme.Sf(14);
            Draw.Str(g, label, Theme.F(8f, true), Theme.Dim, new RectangleF(pad, Theme.Sf(9), Width - 2 * pad, Theme.Sf(18)));

            Font vf = Theme.F(21f, true), uf = Theme.F(9f);
            float vw = Draw.Width(g, value, vf), uw = Draw.Width(g, unit, uf);
            float x = Loc.Rtl ? Width - pad - vw - uw : pad;
            float top = Theme.Sf(25), vh = Theme.Sf(40);
            Draw.Str(g, value, vf, color, new RectangleF(x - Theme.Sf(3), top, vw + 4, vh), HA.Center, HA.Center, true);
            Draw.Str(g, unit, uf, Theme.Dim, new RectangleF(x + vw - Theme.Sf(5), top + Theme.Sf(9), uw + 4, vh - Theme.Sf(9)), HA.Center, HA.Center, true);

            Draw.Str(g, sub, Theme.F(8.5f), Theme.Dim, new RectangleF(pad, Height - Theme.Sf(27), Width - 2 * pad, Theme.Sf(18)));
        }
    }

    /// <summary>Small status chip.</summary>
    sealed class Pill : UiControl
    {
        Color color = Theme.Dim;

        public Pill() { Font = Theme.F(8.5f, true); }

        public void Set(string text, Color c)
        {
            if (text == Text && c == color) return;
            color = c;
            Text = text;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Draw.FillRound(g, Color.FromArgb(38, color), r, Height / 2f);
            Draw.Str(g, Text, Font, color, r, HA.Center);
        }
    }

    sealed class Bar : UiControl
    {
        float v;
        public float Value
        {
            get { return v; }
            set { float n = Math.Max(0, Math.Min(1, value)); if (Math.Abs(n - v) > 0.0005f) { v = n; Invalidate(); } }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            var r = new RectangleF(0, 0, Width, Height);
            Draw.FillRound(g, Theme.Inset, r, Height / 2f);
            if (v <= 0.001f) return;
            float w = Math.Max(Height, r.Width * v);
            var fr = new RectangleF(Loc.Rtl ? r.Right - w : 0, 0, w, Height);
            using (var p = Draw.Round(fr, Height / 2f))
            using (var b = new LinearGradientBrush(new RectangleF(0, 0, Width, Height), Theme.Accent, Theme.Accent2, 0f))
                g.FillPath(b, p);
        }
    }

    /// <summary>Colour key for the graph.</summary>
    sealed class Legend : UiControl
    {
        readonly string[] names;
        readonly Color[] colors;
        public Legend(string[] names, Color[] colors) { this.names = names; this.colors = colors; Font = Theme.F(8.5f); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            float dot = Theme.Sf(8), gap = Theme.Sf(14);
            // Laid out from the end edge backwards.
            float x = Loc.Rtl ? 0 : Width;
            for (int i = names.Length - 1; i >= 0; i--)
            {
                float tw = Draw.Width(g, names[i], Font) + 2;
                if (Loc.Rtl)
                {
                    Draw.Str(g, names[i], Font, Theme.Dim, new RectangleF(x, 0, tw, Height), HA.Center);
                    x += tw + Theme.Sf(2);
                    using (var b = new SolidBrush(colors[i])) g.FillEllipse(b, x, (Height - dot) / 2f, dot, dot);
                    x += dot + gap;
                }
                else
                {
                    x -= tw;
                    Draw.Str(g, names[i], Font, Theme.Dim, new RectangleF(x, 0, tw, Height), HA.Center);
                    x -= dot + Theme.Sf(2);
                    using (var b = new SolidBrush(colors[i])) g.FillEllipse(b, x, (Height - dot) / 2f, dot, dot);
                    x -= gap;
                }
            }
        }
    }

    /// <summary>Live ping chart: internet line with a soft fill, router line, and markers for lost packets.</summary>
    sealed class Graph : UiControl
    {
        public PingMonitor Main, Router;
        public int WindowMs = 60000;

        static readonly int[] Steps = { 20, 40, 60, 80, 100, 120, 160, 200, 300, 400, 600, 800, 1000, 1500, 2000, 4000, 10000 };

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            float left = Theme.Sf(40), right = Theme.Sf(10), top = Theme.Sf(8), bottom = Theme.Sf(20);
            var plot = new RectangleF(left, top, Width - left - right, Height - top - bottom);
            if (plot.Width < 10 || plot.Height < 10) return;

            long now = PingMonitor.Now;
            var main = Main != null ? Main.Snapshot(now - WindowMs - 1500) : new List<Sample>();
            var gw = Router != null ? Router.Snapshot(now - WindowMs - 3000) : new List<Sample>();

            int max = 0, valid = 0;
            foreach (var s in main) if (s.Rtt >= 0) { valid++; if (s.Rtt > max) max = s.Rtt; }
            int yMax = Steps[Steps.Length - 1];
            foreach (int st in Steps) if (st >= Math.Max(40, max * 1.15)) { yMax = st; break; }

            // grid + axis labels
            Font small = Theme.F(7.5f);
            using (var grid = new Pen(Color.FromArgb(150, Theme.Border)))
            {
                for (int i = 0; i <= 4; i++)
                {
                    float y = plot.Bottom - plot.Height * i / 4f;
                    g.DrawLine(grid, plot.Left, y, plot.Right, y);
                    Draw.Str(g, (yMax * i / 4).ToString(), small, Theme.Dim, new RectangleF(0, y - Theme.Sf(8), left - Theme.Sf(5), Theme.Sf(16)), Loc.Rtl ? HA.Start : HA.End, HA.Center, true);
                }
            }
            float lw = Theme.Sf(60), ly = plot.Bottom + Theme.Sf(2), lh = Theme.Sf(16);
            Draw.Str(g, "-60s", small, Theme.Dim, new RectangleF(plot.Left - Theme.Sf(4), ly, lw, lh), Loc.Rtl ? HA.End : HA.Start, HA.Center, true);
            Draw.Str(g, "-30s", small, Theme.Dim, new RectangleF(plot.Left + plot.Width / 2 - lw / 2, ly, lw, lh), HA.Center, HA.Center, true);
            Draw.Str(g, "0s", small, Theme.Dim, new RectangleF(plot.Right - lw + Theme.Sf(4), ly, lw, lh), Loc.Rtl ? HA.Start : HA.End, HA.Center, true);

            if (valid == 0)
            {
                Draw.Str(g, Loc.T("graph.wait"), Theme.F(9.5f), Theme.Dim, plot, HA.Center);
                return;
            }

            var state = g.Save();
            g.SetClip(plot);

            Func<long, float> X = t => plot.Right - (now - t) / (float)WindowMs * plot.Width;
            Func<int, float> Y = r => plot.Bottom - Math.Min(r, yMax) / (float)yMax * plot.Height;

            // router line (thin, behind)
            using (var pen = new Pen(Color.FromArgb(190, Theme.Accent2), Theme.Sf(1.3f)) { LineJoin = LineJoin.Round })
                foreach (var run in Runs(gw, X, Y))
                    if (run.Count > 1) g.DrawLines(pen, run.ToArray());

            // internet line with fill
            using (var pen = new Pen(Theme.Accent, Theme.Sf(2f)) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
            using (var dotBrush = new SolidBrush(Theme.Accent))
            {
                foreach (var run in Runs(main, X, Y))
                {
                    if (run.Count == 1)
                    {
                        g.FillEllipse(dotBrush, run[0].X - Theme.Sf(2), run[0].Y - Theme.Sf(2), Theme.Sf(4), Theme.Sf(4));
                        continue;
                    }
                    var poly = new List<PointF>(run);
                    poly.Add(new PointF(run[run.Count - 1].X, plot.Bottom));
                    poly.Add(new PointF(run[0].X, plot.Bottom));
                    using (var fill = new LinearGradientBrush(new RectangleF(plot.X, plot.Y - 1, plot.Width, plot.Height + 2),
                        Color.FromArgb(78, Theme.Accent), Color.FromArgb(0, Theme.Accent), 90f))
                        g.FillPolygon(fill, poly.ToArray());
                    g.DrawLines(pen, run.ToArray());
                }
            }

            // lost packets
            using (var pen = new Pen(Theme.Bad, Theme.Sf(2f)))
                foreach (var s in main)
                    if (s.Rtt == -1)
                    {
                        float x = X(s.T);
                        g.DrawLine(pen, x, plot.Bottom - Theme.Sf(12), x, plot.Bottom);
                    }

            g.Restore(state);
        }

        /// <summary>Splits the samples into unbroken runs of points (a lost packet ends a run).</summary>
        static List<List<PointF>> Runs(List<Sample> samples, Func<long, float> x, Func<int, float> y)
        {
            var runs = new List<List<PointF>>();
            List<PointF> cur = null;
            foreach (var s in samples)
            {
                if (s.Rtt == -2) continue;
                if (s.Rtt < 0) { cur = null; continue; }
                if (cur == null) { cur = new List<PointF>(); runs.Add(cur); }
                cur.Add(new PointF(x(s.T), y(s.Rtt)));
            }
            return runs;
        }
    }

    /// <summary>Auto-Tune results.</summary>
    sealed class TuneTable : UiControl
    {
        public TuneResult Result;
        public int Live = -99;      // mode currently being measured

        static readonly int[] Modes = { -1, 0, 1, 2, 3 };
        static readonly float[] Cols = { 0.30f, 0.14f, 0.14f, 0.14f, 0.14f, 0.14f };

        RectangleF Cell(int col, float y, float h)
        {
            float pad = Theme.Sf(12), w = Width - 2 * pad, x = pad;
            for (int i = 0; i < col; i++) x += Cols[i] * w;
            float cw = Cols[col] * w;
            if (Loc.Rtl) x = Width - x - cw;
            return new RectangleF(x, y, cw, h);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = Begin(e);
            float hh = Theme.Sf(30), rh = Theme.Sf(44);
            string[] heads = { "tune.c.mode", "tune.c.avg", "tune.c.jitter", "tune.c.p95", "tune.c.loss", "tune.c.score" };
            for (int c = 0; c < heads.Length; c++)
                Draw.Str(g, Loc.T(heads[c]), Theme.F(8f, true), Theme.Dim, Cell(c, 0, hh), c == 0 ? HA.Start : HA.Center);
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Theme.Sf(8), hh, Width - Theme.Sf(8), hh);

            for (int i = 0; i < Modes.Length; i++)
            {
                float y = hh + Theme.Sf(4) + i * rh;
                TuneRow row = Result != null && i < Result.Rows.Count ? Result.Rows[i] : null;
                bool best = Result != null && Result.BestRow == i;
                bool live = Live == Modes[i];
                var rowRect = new RectangleF(Theme.Sf(4), y + Theme.Sf(2), Width - Theme.Sf(8), rh - Theme.Sf(4));
                if (best) { Draw.FillRound(g, Color.FromArgb(30, Theme.Accent), rowRect, S(9)); Draw.StrokeRound(g, Color.FromArgb(120, Theme.Accent), rowRect, S(9)); }
                else if (live) Draw.FillRound(g, Color.FromArgb(36, Theme.Accent2), rowRect, S(9));

                string name = Modes[i] < 0 ? Loc.T("tune.off") : Loc.T("mode." + Modes[i]) + "  ·  " + Loc.Ltr(Settings.ModePps[Modes[i]] + "/s");
                if (best) name += "   ✓ " + Loc.T("tune.best");
                Draw.Str(g, name, Theme.F(10f, true), best ? Theme.Accent : live ? Theme.Text : Theme.Text, Cell(0, y, rh), HA.Start);

                bool has = row != null && row.Score < double.MaxValue && row.N > 0;
                string[] vals =
                {
                    has ? Fmt.N0(row.Avg) + " ms" : "—",
                    has ? Fmt.N1(row.Jitter) + " ms" : "—",
                    has ? Fmt.N0(row.P95) + " ms" : "—",
                    has ? Fmt.N1(row.Loss) + "%" : "—",
                    has ? Fmt.N1(row.Score) : "—"
                };
                for (int c = 0; c < vals.Length; c++)
                {
                    Color col = Theme.Text;
                    if (has && c == 1) col = Theme.JitterColor(row.Jitter);
                    if (has && c == 3) col = Theme.LossColor(row.Loss);
                    if (!has) col = Theme.Dim;
                    Draw.Str(g, vals[c], Theme.F(10f, c == 1), col, Cell(c + 1, y, rh), HA.Center, HA.Center, true);
                }
            }
        }
    }

    /// <summary>Dark list box (games list, process picker).</summary>
    sealed class DarkList : ListBox
    {
        /// <summary>Optional tag drawn at the end of a row (for example "running").</summary>
        public Func<object, string> TagOf;

        public DarkList()
        {
            DrawMode = DrawMode.OwnerDrawFixed;
            BorderStyle = BorderStyle.None;
            BackColor = Theme.Card;
            ForeColor = Theme.Text;
            Font = Theme.F(10f);
            ItemHeight = Theme.S(32);
            IntegralHeight = false;
            RightToLeft = Loc.Rtl ? RightToLeft.Yes : RightToLeft.No;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.DarkScrollBars(Handle);
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            var g = e.Graphics;
            Draw.Prep(g);
            using (var b = new SolidBrush(BackColor)) g.FillRectangle(b, e.Bounds);
            if (e.Index < 0 || e.Index >= Items.Count) return;

            bool selected = (e.State & DrawItemState.Selected) != 0;
            var r = new RectangleF(e.Bounds.X + 2, e.Bounds.Y + 1, e.Bounds.Width - 4, e.Bounds.Height - 2);
            if (selected) Draw.FillRound(g, Theme.CardHi, r, Theme.S(7));

            object item = Items[e.Index];
            string tag = TagOf != null ? TagOf(item) : null;
            float tagW = 0;
            if (!string.IsNullOrEmpty(tag))
            {
                Font tf = Theme.F(8f, true);
                tagW = Draw.Width(g, tag, tf) + Theme.Sf(16);
                var tr = new RectangleF(Loc.Rtl ? r.X + Theme.Sf(6) : r.Right - tagW - Theme.Sf(6), r.Y + Theme.Sf(5), tagW, r.Height - Theme.Sf(10));
                Draw.FillRound(g, Color.FromArgb(40, Theme.Accent), tr, tr.Height / 2f);
                Draw.Str(g, tag, tf, Theme.Accent, tr, HA.Center);
                tagW += Theme.Sf(10);
            }
            var textRect = new RectangleF(r.X + (Loc.Rtl ? tagW : Theme.Sf(10)), r.Y, r.Width - tagW - Theme.Sf(10), r.Height);
            Draw.Str(g, item.ToString(), Font, Theme.Text, textRect, HA.Start, HA.Center, true);
        }
    }

    sealed class DarkColors : ProfessionalColorTable
    {
        public override Color ToolStripDropDownBackground { get { return Theme.Card; } }
        public override Color ImageMarginGradientBegin { get { return Theme.Card; } }
        public override Color ImageMarginGradientMiddle { get { return Theme.Card; } }
        public override Color ImageMarginGradientEnd { get { return Theme.Card; } }
        public override Color MenuBorder { get { return Theme.Border; } }
        public override Color MenuItemBorder { get { return Theme.CardHi; } }
        public override Color MenuItemSelected { get { return Theme.CardHi; } }
        public override Color MenuItemSelectedGradientBegin { get { return Theme.CardHi; } }
        public override Color MenuItemSelectedGradientEnd { get { return Theme.CardHi; } }
        public override Color MenuItemPressedGradientBegin { get { return Theme.CardHi; } }
        public override Color MenuItemPressedGradientEnd { get { return Theme.CardHi; } }
        public override Color SeparatorDark { get { return Theme.Border; } }
        public override Color SeparatorLight { get { return Theme.Border; } }
        public override Color CheckBackground { get { return Theme.Card; } }
        public override Color CheckSelectedBackground { get { return Theme.CardHi; } }
        public override Color CheckPressedBackground { get { return Theme.CardHi; } }
    }

    /// <summary>Dark tray menu with an accent dot for the checked item.</summary>
    sealed class DarkMenuRenderer : ToolStripProfessionalRenderer
    {
        public DarkMenuRenderer() : base(new DarkColors()) { RoundedEdges = false; }

        protected override void OnRenderItemCheck(ToolStripItemImageRenderEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = e.ImageRectangle;
            float d = Math.Min(r.Width, r.Height) * 0.5f;
            using (var b = new SolidBrush(Theme.Accent))
                g.FillEllipse(b, r.X + (r.Width - d) / 2f, r.Y + (r.Height - d) / 2f, d, d);
        }

        protected override void OnRenderArrow(ToolStripArrowRenderEventArgs e)
        {
            e.ArrowColor = Theme.Text;
            base.OnRenderArrow(e);
        }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            e.TextColor = e.Item.Enabled ? Theme.Text : Theme.Dim;
            base.OnRenderItemText(e);
        }
    }
}
