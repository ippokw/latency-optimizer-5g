using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace LO5G
{
    /// <summary>
    /// Sub-millisecond sleep. Uses a high-resolution waitable timer (Windows 10 1803+), which stays
    /// accurate even when the process is hidden in the tray; falls back to Sleep on older systems.
    /// </summary>
    sealed class HiResWaiter : IDisposable
    {
        IntPtr h;

        public HiResWaiter()
        {
            try { h = Native.CreateWaitableTimerExW(IntPtr.Zero, null, 0x2, 0x1F0003); } catch { h = IntPtr.Zero; }
            if (h == IntPtr.Zero)
            {
                try { h = Native.CreateWaitableTimerExW(IntPtr.Zero, null, 0, 0x1F0003); } catch { h = IntPtr.Zero; }
            }
        }

        public void Wait(long micros)
        {
            if (micros <= 0) return;
            if (micros > 500000) micros = 500000;
            if (h != IntPtr.Zero)
            {
                long due = -micros * 10; // relative, 100 ns units
                if (Native.SetWaitableTimer(h, ref due, 0, IntPtr.Zero, IntPtr.Zero, false))
                {
                    Native.WaitForSingleObject(h, 1000);
                    return;
                }
            }
            Thread.Sleep((int)Math.Max(1, micros / 1000));
        }

        public void Dispose()
        {
            if (h != IntPtr.Zero) { Native.CloseHandle(h); h = IntPtr.Zero; }
        }
    }

    /// <summary>
    /// The stabilizer. Sends a steady stream of tiny UDP packets so the radio link (5G/LTE modem or
    /// Wi-Fi adapter) never drops into its power-saving / idle scheduling state between game packets.
    /// The packets carry a low TTL, so they cross your access link and then expire inside the ISP's
    /// network: nothing is ever delivered to, or loads, any server.
    /// </summary>
    sealed class PulseEngine
    {
        Thread th;
        volatile bool run, reconf;
        volatile int pps = 30, ttl = 4, gen;
        volatile IPEndPoint ep;
        long sent, bytes, errors, maxGap;
        static readonly byte[] payload = Encoding.ASCII.GetBytes("LO5G-KEEPALIVE!!");

        public long Sent { get { return Interlocked.Read(ref sent); } }
        public long Bytes { get { return Interlocked.Read(ref bytes); } }
        public long Errors { get { return Interlocked.Read(ref errors); } }
        public bool Running { get { return run; } }
        public int Pps { get { return pps; } }
        public int Ttl { get { return ttl; } }

        /// <summary>Longest gap between two pulses since the last call, in milliseconds.</summary>
        public double TakeMaxGapMs()
        {
            long g = Interlocked.Exchange(ref maxGap, 0);
            return g * 1000.0 / Stopwatch.Frequency;
        }

        public void Start(IPAddress target, int hopLimit, int rate)
        {
            var e = ep;
            if (e == null || !e.Address.Equals(target) || ttl != hopLimit)
            {
                ep = new IPEndPoint(target, 50505);
                ttl = hopLimit;
                reconf = true;
            }
            pps = Math.Max(1, rate);
            if (run && th != null && th.IsAlive) return;
            run = true;
            int g = ++gen;
            th = new Thread(() => Loop(g)) { IsBackground = true, Priority = ThreadPriority.Highest, Name = "LO5G pulse" };
            th.Start();
        }

        public void Stop()
        {
            run = false;
            gen++;
            var t = th;
            th = null;
            if (t != null && t.IsAlive && t != Thread.CurrentThread) t.Join(800);
        }

        void Loop(int myGen)
        {
            Native.timeBeginPeriod(1);
            var waiter = new HiResWaiter();
            Socket s = null;
            var sw = Stopwatch.StartNew();
            long next = 0, lastSend = 0;
            try
            {
                while (run && gen == myGen)
                {
                    if (s == null || reconf)
                    {
                        reconf = false;
                        Close(s);
                        s = Open();
                    }

                    bool ok = false;
                    if (s != null)
                    {
                        try
                        {
                            s.SendTo(payload, ep);
                            ok = true;
                            Interlocked.Increment(ref sent);
                            Interlocked.Add(ref bytes, payload.Length + 28);
                            long t = sw.ElapsedTicks;
                            if (lastSend != 0)
                            {
                                long gap = t - lastSend;
                                if (gap > Interlocked.Read(ref maxGap)) Interlocked.Exchange(ref maxGap, gap);
                            }
                            lastSend = t;
                        }
                        catch
                        {
                            Interlocked.Increment(ref errors);
                            Close(s);
                            s = null;
                        }
                    }

                    if (!ok)
                    {
                        // No route right now (network switching, cable out...). Back off and retry.
                        Thread.Sleep(300);
                        next = sw.ElapsedTicks;
                        lastSend = 0;
                        continue;
                    }

                    long interval = Stopwatch.Frequency / Math.Max(1, pps);
                    next += interval;
                    long now = sw.ElapsedTicks;
                    if (next < now) next = now;      // running late: never burst to catch up
                    waiter.Wait((next - now) * 1000000L / Stopwatch.Frequency);
                }
            }
            catch (Exception ex) { Program.Log(ex); }
            finally
            {
                Close(s);
                waiter.Dispose();
                Native.timeEndPeriod(1);
            }
        }

        Socket Open()
        {
            try
            {
                var s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                s.Ttl = (short)Math.Max(1, Math.Min(64, ttl));
                // Ignore ICMP "time exceeded / unreachable" answers instead of failing the socket.
                try { s.IOControl(unchecked((int)0x9800000C), new byte[] { 0, 0, 0, 0 }, null); } catch { }
                return s;
            }
            catch { return null; }
        }

        static void Close(Socket s)
        {
            if (s == null) return;
            try { s.Close(); } catch { }
        }
    }

    /// <summary>One ping probe. Rtt: -2 = still waiting, -1 = lost, otherwise milliseconds.</summary>
    struct Sample
    {
        public long T;
        public int Rtt;
        public int Wait;     // replies still outstanding (several targets are probed at once)
    }

    struct Stats
    {
        public bool Valid;
        public int Count, Lost, Spikes, Score;
        public double Last, Avg, Min, Max, Jitter, Median, P95, LossPct;

        public double SpikePct { get { return Count > 0 ? 100.0 * Spikes / Count : 0; } }

        public static Stats From(List<Sample> samples)
        {
            var st = new Stats { Last = -1 };
            var v = new List<int>(samples.Count);
            int lost = 0, prev = -1, last = -1, jn = 0;
            double jsum = 0, sum = 0;
            foreach (var x in samples)
            {
                if (x.Rtt == -2) continue;
                if (x.Rtt < 0) { lost++; prev = -1; last = -1; continue; }
                v.Add(x.Rtt);
                sum += x.Rtt;
                if (prev >= 0) { jsum += Math.Abs(x.Rtt - prev); jn++; }
                prev = x.Rtt;
                last = x.Rtt;
            }
            st.Count = v.Count + lost;
            st.Lost = lost;
            if (st.Count == 0) return st;
            st.LossPct = 100.0 * lost / st.Count;
            if (v.Count == 0) return st;

            st.Valid = true;
            st.Last = last;
            st.Avg = sum / v.Count;
            st.Jitter = jn > 0 ? jsum / jn : 0;
            var sorted = new List<int>(v);
            sorted.Sort();
            st.Min = sorted[0];
            st.Max = sorted[sorted.Count - 1];
            st.Median = sorted[sorted.Count / 2];
            st.P95 = sorted[Math.Min(sorted.Count - 1, (int)Math.Ceiling(sorted.Count * 0.95) - 1)];
            double spikeAt = st.Median + Math.Max(20, st.Median * 0.6);
            foreach (int r in v) if (r > spikeAt) st.Spikes++;

            double score = 100 - Math.Min(55, st.Jitter * 2.2) - Math.Min(30, st.LossPct * 6) - Math.Min(15, st.SpikePct * 1.5);
            st.Score = (int)Math.Round(Math.Max(0, Math.Min(100, score)));
            return st;
        }
    }

    /// <summary>
    /// Continuous ICMP monitor with a ring buffer of recent samples.
    /// With several targets, every tick probes all of them and keeps the fastest answer. A spike that
    /// shows on all routes at once is your own line; a spike on one route is that route's problem and
    /// is filtered out. That makes the number describe the line itself, which is what Boost works on.
    /// </summary>
    sealed class PingMonitor
    {
        static readonly Stopwatch clock = Stopwatch.StartNew();
        public static long Now { get { return clock.ElapsedMilliseconds; } }

        const int Cap = 4096;
        readonly Sample[] buf = new Sample[Cap];
        readonly object lk = new object();
        long seq;
        int epoch, interval;
        System.Threading.Timer timer;
        volatile IPAddress[] targets = new IPAddress[0];
        long probes;
        static readonly byte[] payload = Encoding.ASCII.GetBytes("LatencyOptimizer5G-monitor-probe");

        public int TimeoutMs = 1000;
        public IPAddress[] Targets { get { return targets; } }
        public IPAddress Target { get { var t = targets; return t.Length > 0 ? t[0] : null; } }
        public long Probes { get { return Interlocked.Read(ref probes); } }

        public void SetTarget(IPAddress ip)
        {
            SetTargets(ip == null ? new IPAddress[0] : new[] { ip });
        }

        public void SetTargets(IPAddress[] ips)
        {
            ips = ips ?? new IPAddress[0];
            lock (lk)
            {
                if (ips.SequenceEqual(targets)) return;
                targets = ips;
                epoch++;      // drop answers that belong to the old targets
                seq = 0;
            }
        }

        public void SetInterval(int ms)
        {
            lock (lk)
            {
                if (timer != null && ms == interval) return;
                interval = ms;
                if (timer == null) timer = new System.Threading.Timer(Tick, null, 0, ms);
                else timer.Change(ms, ms);
            }
        }

        public void Stop()
        {
            lock (lk)
            {
                if (timer != null) { timer.Dispose(); timer = null; }
            }
        }

        void Tick(object _)
        {
            IPAddress[] ips;
            long idx;
            int ep;
            lock (lk)
            {
                ips = targets;
                if (ips.Length == 0) return;
                idx = seq++;
                ep = epoch;
                buf[idx % Cap] = new Sample { T = Now, Rtt = -2, Wait = ips.Length };
            }
            Interlocked.Add(ref probes, ips.Length);
            foreach (var ip in ips) Probe(ip, idx, ep);
        }

        static int inFlight;

        /// <summary>Waits until every probe that was sent has answered or timed out (used before exiting).</summary>
        public static void WaitIdle(int maxMs)
        {
            long end = Now + maxMs;
            while (Volatile.Read(ref inFlight) > 0 && Now < end) Thread.Sleep(20);
        }

        void Probe(IPAddress ip, long idx, int ep)
        {
            Ping p = null;
            bool counted = false;
            try
            {
                p = new Ping();
                // Each probe is disposed in its own completion handler. Without this, the finalizer that
                // runs at process exit frees the reply buffer of a probe that is still in the air, and the
                // late answer then lands in freed memory (crash on exit).
                GC.SuppressFinalize(p);
                p.PingCompleted += (s, e) =>
                {
                    int rtt = -1;
                    try
                    {
                        if (!e.Cancelled && e.Error == null && e.Reply != null && e.Reply.Status == IPStatus.Success)
                            rtt = (int)Math.Min(e.Reply.RoundtripTime, 9999);
                    }
                    catch { }
                    Complete(idx, ep, rtt);
                    try { ((Ping)s).Dispose(); } catch { }
                    Interlocked.Decrement(ref inFlight);
                };
                Interlocked.Increment(ref inFlight);
                counted = true;
                p.SendAsync(ip, TimeoutMs, payload, null);
            }
            catch
            {
                if (counted) Interlocked.Decrement(ref inFlight);
                Complete(idx, ep, -1);
                if (p != null) { try { p.Dispose(); } catch { } }
            }
        }

        void Complete(long idx, int ep, int rtt)
        {
            lock (lk)
            {
                if (ep != epoch || idx >= seq || seq - idx > Cap) return;
                long i = idx % Cap;
                buf[i].Wait--;
                if (rtt >= 0)
                {
                    if (buf[i].Rtt < 0 || rtt < buf[i].Rtt) buf[i].Rtt = rtt;     // keep the fastest answer
                }
                else if (buf[i].Wait <= 0 && buf[i].Rtt == -2) buf[i].Rtt = -1;   // nobody answered: lost
            }
        }

        /// <summary>All samples sent at or after <paramref name="since"/> (monitor clock, ms), oldest first.</summary>
        public List<Sample> Snapshot(long since)
        {
            var r = new List<Sample>(256);
            lock (lk)
            {
                long start = Math.Max(0, seq - Cap);
                long i = seq - 1;
                while (i >= start && buf[i % Cap].T >= since) i--;
                for (long j = i + 1; j < seq; j++) r.Add(buf[j % Cap]);
            }
            return r;
        }

        public List<Sample> Range(long from, long to)
        {
            var all = Snapshot(from);
            all.RemoveAll(s => s.T > to);
            return all;
        }

        public Stats GetStats(int windowMs)
        {
            return Stats.From(Snapshot(Now - windowMs));
        }
    }

    /// <summary>
    /// The version 1 method, kept as an option: visit speedtest.net every 5 seconds. Heavier on data
    /// than the pulse, but some lines respond to the periodic burst.
    /// </summary>
    sealed class ClassicKeepAlive
    {
        public const string Url = "https://www.speedtest.net/";
        volatile bool run;
        volatile int gen;
        long bytes;
        int ok, fail;
        readonly AutoResetEvent wake = new AutoResetEvent(false);

        public long Bytes { get { return Interlocked.Read(ref bytes); } }
        public int Ok { get { return ok; } }
        public int Fail { get { return fail; } }
        public bool Running { get { return run; } }

        public void Start()
        {
            if (run) return;
            run = true;
            int g = ++gen;
            new Thread(() => Loop(g)) { IsBackground = true, Name = "LO5G classic" }.Start();
        }

        public void Stop()
        {
            if (!run) return;
            run = false;
            gen++;
            wake.Set();
        }

        public string LastError = "";

        void Loop(int myGen)
        {
            var buf = new byte[16384];
            // Modern TLS explicitly (3072 = TLS 1.2, 12288 = TLS 1.3); older defaults are refused by most sites.
            try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)(3072 | 12288); }
            catch { try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } catch { } }
            while (run && gen == myGen)
            {
                try
                {
                    var req = (HttpWebRequest)WebRequest.Create(Url);
                    req.Timeout = 10000;
                    req.ReadWriteTimeout = 10000;
                    req.KeepAlive = true;
                    req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) LatencyOptimizer5G/" + Program.Version;
                    req.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                    using (var resp = (HttpWebResponse)req.GetResponse())
                    using (var st = resp.GetResponseStream())
                    {
                        long total = 0;
                        int n;
                        while (st != null && (n = st.Read(buf, 0, buf.Length)) > 0 && total < 2000000) total += n;
                        Interlocked.Add(ref bytes, total + 2500);
                        ok++;
                    }
                }
                catch (WebException ex)
                {
                    // A reply with an error status still moved data over the line, which is all this is for.
                    var hr = ex.Response as HttpWebResponse;
                    if (hr != null) { ok++; Interlocked.Add(ref bytes, Math.Max(0, hr.ContentLength) + 2500); hr.Close(); }
                    else fail++;
                    LastError = ex.Status + ": " + ex.Message;
                }
                catch (Exception ex) { fail++; LastError = ex.Message; }
                wake.WaitOne(5000);
            }
        }
    }

    /// <summary>
    /// Names the program that is filling the line. The #1 cause of lag on a home connection is another
    /// app uploading or downloading at the same time. Windows gives per-program network counters only
    /// to administrators, so this compares each program's I/O rate with the adapter's traffic and
    /// reports the one that matches it (programs busy with the disk are far above the network rate
    /// and drop out). It is an estimate, and it is worded that way in the UI.
    /// </summary>
    sealed class TrafficWatch
    {
        readonly Dictionary<int, ulong> last = new Dictionary<int, ulong>();
        long lastT;
        int self;
        volatile string top;

        /// <summary>Program that appears to be using the connection right now, or null.</summary>
        public string Top { get { return top; } }

        public void Reset() { last.Clear(); lastT = 0; top = null; }

        /// <param name="lineBytesPerSec">Current adapter traffic (download + upload), bytes per second.</param>
        public void Sample(double lineBytesPerSec)
        {
            long now = PingMonitor.Now;
            double dt = lastT == 0 ? 0 : (now - lastT) / 1000.0;
            lastT = now;

            var games = new HashSet<string>(Settings.Games.Select(GameWatcher.Strip), StringComparer.OrdinalIgnoreCase);
            if (self == 0) using (var me = Process.GetCurrentProcess()) self = me.Id;
            var seen = new HashSet<int>();
            string best = null;
            double bestFit = 0;

            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    int pid = p.Id;
                    // Never open a handle to a listed game (anti-cheat), to ourselves, or to System/Idle.
                    if (pid <= 4 || pid == self || games.Contains(p.ProcessName)) continue;
                    IntPtr h = Native.OpenProcess(0x1000, false, pid);   // PROCESS_QUERY_LIMITED_INFORMATION
                    if (h == IntPtr.Zero) continue;
                    Native.IoCounters io;
                    bool ok = Native.GetProcessIoCounters(h, out io);
                    Native.CloseHandle(h);
                    if (!ok) continue;

                    ulong total = io.ReadBytes + io.WriteBytes;
                    seen.Add(pid);
                    ulong prev;
                    bool had = last.TryGetValue(pid, out prev);
                    last[pid] = total;
                    if (!had || dt < 0.5 || total < prev || lineBytesPerSec < 100000) continue;   // need 0.8 Mbps+ of traffic

                    double rate = (total - prev) / dt;
                    if (rate < lineBytesPerSec * 0.35 || rate > lineBytesPerSec * 3) continue;
                    double fit = Math.Min(rate, lineBytesPerSec) / Math.Max(rate, lineBytesPerSec);
                    if (fit > bestFit) { bestFit = fit; best = p.ProcessName; }
                }
                catch { }
                finally { p.Dispose(); }
            }

            foreach (int gone in last.Keys.Where(k => !seen.Contains(k)).ToList()) last.Remove(gone);
            top = best;
        }
    }

    /// <summary>Watches for a listed game so AUTO mode can switch Boost on by itself.</summary>
    sealed class GameWatcher
    {
        System.Threading.Timer timer;
        volatile string running;
        int busy;
        readonly HashSet<int> raised = new HashSet<int>();

        public string Running { get { return running; } }
        public event Action Changed;

        public void Start() { if (timer == null) timer = new System.Threading.Timer(_ => Check(), null, 500, 4000); }
        public void Stop() { if (timer != null) { timer.Dispose(); timer = null; } }
        public void Poke() { ThreadPool.QueueUserWorkItem(_ => Check()); }

        public static string Strip(string exe)
        {
            exe = (exe ?? "").Trim();
            return exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? exe.Substring(0, exe.Length - 4) : exe;
        }

        void Check()
        {
            if (Interlocked.Exchange(ref busy, 1) == 1) return;
            try
            {
                var games = Settings.Games;
                var set = new HashSet<string>(games.Select(Strip), StringComparer.OrdinalIgnoreCase);
                string found = null;
                if (set.Count > 0)
                {
                    foreach (var p in Process.GetProcesses())
                    {
                        try
                        {
                            if (!set.Contains(p.ProcessName)) continue;
                            if (found == null) found = p.ProcessName;
                            if (Settings.GamePriority && raised.Add(p.Id))
                            {
                                try { if (p.PriorityClass == ProcessPriorityClass.Normal) p.PriorityClass = ProcessPriorityClass.High; }
                                catch { /* protected by anti-cheat or elevated: leave it alone */ }
                            }
                        }
                        catch { }
                        finally { p.Dispose(); }
                    }
                }
                if (found == null) raised.Clear();
                if (found != running)
                {
                    running = found;
                    var h = Changed;
                    if (h != null) h();
                }
            }
            catch (Exception ex) { Program.Log(ex); }
            finally { Interlocked.Exchange(ref busy, 0); }
        }
    }
}
