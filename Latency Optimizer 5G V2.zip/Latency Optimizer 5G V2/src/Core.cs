using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;

namespace LO5G
{
    /// <summary>One row of an Auto-Tune run: how the line behaved with a given pulse level.</summary>
    sealed class TuneRow
    {
        public int Mode;          // -1 = Boost off, otherwise index into Settings.ModePps
        public int N;
        public double Avg, Jitter, P95, Loss, Score;
    }

    sealed class TuneResult
    {
        public List<TuneRow> Rows = new List<TuneRow>();
        public int BestRow = -1;       // index into Rows
        public int Mode;               // mode that was selected
        public bool AlreadyStable;     // pulses made no real difference on this line
        public double JitterOff, JitterBest, GainPct;
        public bool Cancelled, NoData;
    }

    /// <summary>Owns the engines and decides what runs: Boost state, game detection, network changes, Auto-Tune.</summary>
    static class Core
    {
        public static readonly PingMonitor Inet = new PingMonitor();
        public static readonly PingMonitor Gw = new PingMonitor();
        public static readonly PulseEngine Pulse = new PulseEngine();
        public static readonly WifiOptimizer Wifi = new WifiOptimizer();
        public static readonly ClassicKeepAlive Classic = new ClassicKeepAlive();
        public static readonly GameWatcher Games = new GameWatcher();
        public static readonly TrafficWatch Traffic = new TrafficWatch();
        public static readonly UploadLimiter Limiter = new UploadLimiter();

        public static volatile NetSnapshot Net = new NetSnapshot();
        /// <summary>Best-routed monitor target; the pulse is aimed towards it.</summary>
        public static volatile IPAddress Target;
        public static volatile int PulseTtl = 4;
        public static volatile bool Active, Tuning, UiVisible, NetBusy = true;
        /// <summary>Adapter traffic in bits per second: instant, and smoothed over a few seconds.</summary>
        public static double RxBps, TxBps, RxAvgBps, TxAvgBps;

        /// <summary>Something changed (Boost state, network, game): the UI should refresh. Raised on any thread.</summary>
        public static event Action Changed;
        /// <summary>Tray notification: title, text.</summary>
        public static event Action<string, string> Notify;

        static readonly object lk = new object();
        static readonly object netLock = new object();
        static Timer secTimer, netTimer;
        static long lastRx = -1, lastTx = -1, lastStatT;
        static int ticks;
        static volatile bool tuneCancel;

        public static long BoostBytes { get { return Pulse.Bytes + Classic.Bytes; } }

        public static void Start()
        {
            Native.DisablePowerThrottling();
            try { Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High; } catch { }

            Inet.SetInterval(1000);
            Gw.SetInterval(2000);
            Games.Changed += OnGameChanged;
            Games.Start();
            NetworkChange.NetworkAddressChanged += (s, e) => RestartNetwork(2000);
            secTimer = new Timer(_ => OnSecond(), null, 1000, 1000);
            RestartNetwork(0);
            ThreadPool.QueueUserWorkItem(_ =>
            {
                // A previous run that was killed may have left programs capped: free them, then arm as configured.
                try { Limiter.ClearLeftovers(); } catch (Exception ex) { Program.Log(ex); }
                ApplyLimiter();
            });
        }

        /// <summary>Keeps listed programs armed while the limiter is enabled, and holds them down while Boost is working.</summary>
        public static void ApplyLimiter()
        {
            try { Limiter.Update(Settings.Limiter, Active, Settings.LimitKbps, Settings.LimitApps); }
            catch (Exception ex) { Program.Log(ex); }
        }

        public static void Stop()
        {
            try
            {
                if (secTimer != null) secTimer.Dispose();
                if (netTimer != null) netTimer.Dispose();
                Inet.Stop();
                Gw.Stop();
                Games.Stop();
                Pulse.Stop();
                Classic.Stop();
                Wifi.Close();
                Limiter.Release();            // never leave another program capped after we are gone
                PingMonitor.WaitIdle(1400);   // let probes that are still in the air come home first
            }
            catch { }
        }

        /// <summary>Re-detects the adapter, target and route (debounced: Windows fires several change events in a row).</summary>
        public static void RestartNetwork(int delayMs)
        {
            lock (lk)
            {
                if (netTimer == null) netTimer = new Timer(_ => InitNetwork(), null, delayMs, Timeout.Infinite);
                else netTimer.Change(delayMs, Timeout.Infinite);
            }
        }

        static void InitNetwork()
        {
            lock (netLock)
            {
                NetBusy = true;
                try
                {
                    var net = NetInfo.Detect();
                    Net = net;
                    Gw.SetTarget(net.Gateway);
                    IPAddress[] ts = net.Local == null ? new IPAddress[0] : NetInfo.PickTargets(Settings.Target);
                    IPAddress t = ts.Length > 0 ? ts[0] : null;
                    if (t != null) PulseTtl = NetInfo.FindPulseTtl(t);
                    Target = t;
                    Inet.SetTargets(ts);
                    lastRx = -1;
                }
                catch (Exception ex) { Program.Log(ex); }
                NetBusy = false;
            }
            Reevaluate();
        }

        /// <summary>Applies the current settings: starts or stops the engines as needed.</summary>
        public static void Reevaluate()
        {
            lock (lk)
            {
                if (!Tuning)
                {
                    bool want = Settings.Boost == 2 || (Settings.Boost == 1 && Games.Running != null);
                    IPAddress t = Target;
                    if (want && t != null) Pulse.Start(t, PulseTtl, Settings.ModePps[Settings.Mode]);
                    else Pulse.Stop();
                    Wifi.Apply(want && Settings.WifiOpt);
                    if (want && Settings.Classic) Classic.Start(); else Classic.Stop();
                    Active = want;
                    ApplyRates();
                }
            }
            ApplyLimiter();
            Raise();
        }

        static void ApplyRates()
        {
            bool fast = Active || UiVisible;
            Inet.SetInterval(fast ? 250 : 1000);
            Gw.SetInterval(fast ? 1000 : 2000);
        }

        public static void SetUiVisible(bool v)
        {
            lock (lk)
            {
                UiVisible = v;
                if (!Tuning) ApplyRates();
            }
        }

        static void Raise()
        {
            var h = Changed;
            if (h != null) { try { h(); } catch { } }
        }

        static void OnGameChanged()
        {
            string g = Games.Running;
            if (Settings.Boost == 1)
            {
                var n = Notify;
                if (n != null)
                {
                    try
                    {
                        if (g != null) n(Loc.T("ntf.game.on.t"), Loc.T("ntf.game.on", g));
                        else n(Loc.T("ntf.game.off.t"), Loc.T("ntf.game.off"));
                    }
                    catch { }
                }
            }
            Reevaluate();
        }

        static void OnSecond()
        {
            try
            {
                // Throughput of the active adapter.
                var nic = Net.Nic;
                long now = PingMonitor.Now;
                if (nic != null)
                {
                    try
                    {
                        var s = nic.GetIPv4Statistics();
                        long rx = s.BytesReceived, tx = s.BytesSent;
                        if (lastRx >= 0 && now > lastStatT)
                        {
                            double dt = (now - lastStatT) / 1000.0;
                            RxBps = Math.Max(0, rx - lastRx) * 8 / dt;
                            TxBps = Math.Max(0, tx - lastTx) * 8 / dt;
                        }
                        lastRx = rx; lastTx = tx; lastStatT = now;
                    }
                    catch { }
                }
                else { RxBps = 0; TxBps = 0; }
                RxAvgBps += (RxBps - RxAvgBps) * 0.35;
                TxAvgBps += (TxBps - TxAvgBps) * 0.35;

                ticks++;
                // Programs started after the limiter was switched on must be armed too.
                if (ticks % 3 == 1 && Settings.Limiter) ApplyLimiter();
                // Who is using the line? Only worth the work while someone is looking or Boost is on.
                if (ticks % 3 == 0)
                {
                    if (Active || UiVisible) Traffic.Sample((RxAvgBps + TxAvgBps) / 8);
                    else Traffic.Reset();
                }
                if (ticks % 5 == 0)
                {
                    // Windows forgets the Wi-Fi settings on every reconnect/roam, so keep re-asserting them.
                    if (Active && Settings.WifiOpt && !Tuning) Wifi.Apply(true);
                    else Wifi.Refresh();
                }
            }
            catch (Exception ex) { Program.Log(ex); }
        }

        // ---- Auto-Tune ----------------------------------------------------------------------

        public const int TuneRounds = 3, TuneSettleMs = 1000, TuneCollectMs = 6000;
        static readonly int[] TuneModes = { -1, 0, 1, 2, 3 };

        public static int TuneTotalSeconds { get { return TuneRounds * TuneModes.Length * (TuneSettleMs + TuneCollectMs) / 1000 + 2; } }

        public static void CancelAutoTune() { tuneCancel = true; }

        /// <summary>
        /// Measures the line with Boost off and with every pulse level (interleaved over several rounds
        /// so that drifting conditions affect all of them equally), then selects the lightest level
        /// that is as steady as the best one. progress: (fraction, mode being tested, round).
        /// </summary>
        public static void StartAutoTune(Action<double, int, int> progress, Action<TuneResult> done)
        {
            lock (lk)
            {
                if (Tuning) return;
                Tuning = true;
                tuneCancel = false;
            }
            new Thread(() =>
            {
                var res = new TuneResult { Mode = Settings.Mode };
                try { RunTune(res, progress); }
                catch (Exception ex) { Program.Log(ex); res.NoData = true; }
                finally
                {
                    lock (lk) { Tuning = false; }
                    Reevaluate();
                    try { done(res); } catch { }
                }
            }) { IsBackground = true, Name = "LO5G tune" }.Start();
            Raise();
        }

        static void RunTune(TuneResult res, Action<double, int, int> progress)
        {
            IPAddress t = Target;
            if (t == null) { res.NoData = true; return; }

            int n = TuneModes.Length;
            var windows = new List<long[]>[n];
            for (int i = 0; i < n; i++) windows[i] = new List<long[]>();
            lock (lk) { Inet.SetInterval(200); }

            int phase = 0, phases = TuneRounds * n;
            for (int r = 0; r < TuneRounds && !tuneCancel; r++)
            {
                for (int j = 0; j < n && !tuneCancel; j++)
                {
                    int ci = (j + r * 2) % n;          // different order every round
                    int mode = TuneModes[ci];
                    lock (lk)
                    {
                        if (mode < 0) Pulse.Stop();
                        else Pulse.Start(t, PulseTtl, Settings.ModePps[mode]);
                    }
                    progress((double)phase / phases, mode, r + 1);
                    if (!SleepCancellable(TuneSettleMs)) break;
                    long t0 = PingMonitor.Now;
                    if (!SleepCancellable(TuneCollectMs, ms => progress((phase + (TuneSettleMs + ms) / (double)(TuneSettleMs + TuneCollectMs)) / phases, mode, r + 1))) break;
                    windows[ci].Add(new[] { t0, PingMonitor.Now });
                    phase++;
                }
            }

            lock (lk) { Pulse.Stop(); }
            if (tuneCancel) { res.Cancelled = true; return; }
            Thread.Sleep(1100);      // let the last probes time out or answer
            progress(1, -2, TuneRounds);

            for (int i = 0; i < n; i++)
            {
                var all = new List<Sample>();
                double jsum = 0;
                int jn = 0;
                foreach (var w in windows[i])
                {
                    var part = Inet.Range(w[0], w[1]);
                    var ps = Stats.From(part);
                    // Jitter is only meaningful inside one window, so average it per window.
                    if (ps.Valid && ps.Count - ps.Lost > 1) { jsum += ps.Jitter * (ps.Count - ps.Lost - 1); jn += ps.Count - ps.Lost - 1; }
                    all.AddRange(part);
                }
                var st = Stats.From(all);
                var row = new TuneRow { Mode = TuneModes[i], N = st.Count };
                if (st.Valid)
                {
                    row.Avg = st.Avg;
                    row.Jitter = jn > 0 ? jsum / jn : st.Jitter;
                    row.P95 = st.P95;
                    row.Loss = st.LossPct;
                    // Lower is better: steadiness first (jitter, how bad the worst 5% gets, loss), then raw latency.
                    row.Score = row.Jitter + 0.35 * Math.Max(0, st.P95 - st.Median) + 0.15 * st.Avg + 15 * st.LossPct;
                }
                else row.Score = double.MaxValue;
                res.Rows.Add(row);
            }

            var usable = res.Rows.Where(x => x.N >= 10 && x.Score < double.MaxValue).ToList();
            if (usable.Count == 0) { res.NoData = true; return; }

            // Lightest level that is within a hair of the best score.
            double best = usable.Min(x => x.Score);
            TuneRow pick = usable.First(x => x.Score <= best * 1.08 + 0.3);
            TuneRow off = res.Rows[0];
            res.JitterOff = off.Jitter;
            res.JitterBest = pick.Jitter;
            if (pick.Mode < 0)
            {
                res.AlreadyStable = true;
                res.Mode = 0;
                res.BestRow = 0;
            }
            else
            {
                res.Mode = pick.Mode;
                res.BestRow = res.Rows.IndexOf(pick);
                res.GainPct = off.Score < double.MaxValue && off.Jitter > 0.05 ? 100.0 * (off.Jitter - pick.Jitter) / off.Jitter : 0;
            }
            Settings.Mode = res.Mode;
            Settings.Save();
        }

        static bool SleepCancellable(int ms, Action<int> tick = null)
        {
            long end = PingMonitor.Now + ms;
            while (true)
            {
                long left = end - PingMonitor.Now;
                if (left <= 0) return true;
                if (tuneCancel) return false;
                Thread.Sleep((int)Math.Min(100, left));
                if (tick != null) tick(ms - (int)Math.Max(0, end - PingMonitor.Now));
            }
        }
    }
}
