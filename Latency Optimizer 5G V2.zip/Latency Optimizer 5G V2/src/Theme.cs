using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace LO5G
{
    /// <summary>Horizontal/vertical placement. "Start" is the left edge in English and the right edge in Arabic.</summary>
    enum HA { Start, Center, End }

    static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(12, 14, 22);
        public static readonly Color Side = Color.FromArgb(16, 19, 30);
        public static readonly Color Card = Color.FromArgb(23, 27, 41);
        public static readonly Color CardHi = Color.FromArgb(36, 42, 62);
        public static readonly Color Inset = Color.FromArgb(14, 17, 27);
        public static readonly Color Border = Color.FromArgb(38, 44, 66);
        public static readonly Color Text = Color.FromArgb(236, 240, 250);
        public static readonly Color Dim = Color.FromArgb(139, 148, 176);
        public static readonly Color Accent = Color.FromArgb(0, 220, 170);
        public static readonly Color Accent2 = Color.FromArgb(108, 128, 255);
        public static readonly Color Good = Color.FromArgb(46, 213, 132);
        public static readonly Color Warn = Color.FromArgb(255, 186, 56);
        public static readonly Color Bad = Color.FromArgb(255, 92, 110);
        public static readonly Color OnAccent = Color.FromArgb(5, 26, 22);
        public static readonly Color Muted = Color.FromArgb(120, 128, 152);

        /// <summary>Screen DPI / 96. All layout numbers are written for 100% and multiplied by this.</summary>
        public static float Scale = 1f;

        public static int S(int v) { return (int)Math.Round(v * Scale); }
        public static float Sf(float v) { return v * Scale; }

        static readonly Dictionary<string, Font> cache = new Dictionary<string, Font>();

        public static Font F(float pt, bool bold = false) { return Get("Segoe UI", pt, bold ? FontStyle.Bold : FontStyle.Regular); }
        public static Font Ico(float pt) { return Get("Segoe MDL2 Assets", pt, FontStyle.Regular); }

        static Font Get(string family, float pt, FontStyle style)
        {
            string key = family + "|" + pt + "|" + style;
            lock (cache)
            {
                Font f;
                if (!cache.TryGetValue(key, out f))
                {
                    f = new Font(family, pt, style, GraphicsUnit.Point);
                    cache[key] = f;
                }
                return f;
            }
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t),
                (int)(a.B + (b.B - a.B) * t));
        }

        public static Color PingColor(double ms) { return ms < 0 ? Bad : ms <= 60 ? Good : ms <= 120 ? Warn : Bad; }
        public static Color JitterColor(double ms) { return ms <= 5 ? Good : ms <= 15 ? Warn : Bad; }
        public static Color LossColor(double pct) { return pct < 0.05 ? Good : pct < 2 ? Warn : Bad; }
        public static Color ScoreColor(int score) { return score >= 85 ? Good : score >= 60 ? Warn : Bad; }
    }

    static class Draw
    {
        public static void Prep(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }

        public static GraphicsPath Round(RectangleF r, float radius)
        {
            var p = new GraphicsPath();
            float d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            if (d <= 0.5f) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static void FillRound(Graphics g, Color c, RectangleF r, float radius)
        {
            using (var p = Round(r, radius))
            using (var b = new SolidBrush(c))
                g.FillPath(b, p);
        }

        public static void StrokeRound(Graphics g, Color c, RectangleF r, float radius, float width = 1f)
        {
            using (var p = Round(r, radius))
            using (var pen = new Pen(c, width))
                g.DrawPath(pen, p);
        }

        /// <summary>
        /// Text drawing that understands the UI direction. "ltr" forces left-to-right order for values
        /// like "23 ms" that must not be reordered inside Arabic text, while still hugging the right edge.
        /// </summary>
        public static StringFormat Format(HA h, HA v, bool ltr, bool wrap)
        {
            var sf = new StringFormat(StringFormat.GenericDefault);
            bool rtlFlag = Loc.Rtl && !ltr;
            if (rtlFlag) sf.FormatFlags |= StringFormatFlags.DirectionRightToLeft;
            if (!wrap) sf.FormatFlags |= StringFormatFlags.NoWrap;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.SetDigitSubstitution(0x0409, StringDigitSubstitute.None);   // always 0-9, never ٠-٩
            if (h == HA.Center) sf.Alignment = StringAlignment.Center;
            else
            {
                bool left = Loc.Rtl ? h == HA.End : h == HA.Start;
                sf.Alignment = left != rtlFlag ? StringAlignment.Near : StringAlignment.Far;
            }
            sf.LineAlignment = v == HA.Start ? StringAlignment.Near : v == HA.Center ? StringAlignment.Center : StringAlignment.Far;
            return sf;
        }

        public static void Str(Graphics g, string s, Font f, Color c, RectangleF r, HA h = HA.Start, HA v = HA.Center, bool ltr = false, bool wrap = false)
        {
            if (string.IsNullOrEmpty(s) || r.Width <= 0 || r.Height <= 0) return;
            using (var sf = Format(h, v, ltr, wrap))
            using (var b = new SolidBrush(c))
                g.DrawString(s, f, b, r, sf);
        }

        public static float Width(Graphics g, string s, Font f)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            using (var sf = new StringFormat(StringFormat.GenericDefault))
            {
                sf.FormatFlags |= StringFormatFlags.NoWrap | StringFormatFlags.MeasureTrailingSpaces;
                sf.SetDigitSubstitution(0x0409, StringDigitSubstitute.None);
                return g.MeasureString(s, f, 10000, sf).Width;
            }
        }
    }

    /// <summary>The logo and the live tray badge, drawn in code so no image files ship with the app.</summary>
    static class IconArt
    {
        static readonly float[] Xs = { 0.14f, 0.33f, 0.43f, 0.56f, 0.66f, 0.72f, 0.86f };
        static readonly float[] Ys = { 0.56f, 0.56f, 0.27f, 0.78f, 0.44f, 0.56f, 0.56f };

        public static Bitmap Logo(int size)
        {
            var b = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.Clear(Color.Transparent);
                float pad = size * 0.03f;
                var r = new RectangleF(pad, pad, size - 2 * pad, size - 2 * pad);
                using (var p = Draw.Round(r, size * 0.24f))
                using (var br = new LinearGradientBrush(new PointF(0, 0), new PointF(size, size), Theme.Accent, Theme.Accent2))
                    g.FillPath(br, p);

                var pts = new PointF[Xs.Length];
                for (int i = 0; i < pts.Length; i++) pts[i] = new PointF(r.X + Xs[i] * r.Width, r.Y + Ys[i] * r.Height);
                using (var pen = new Pen(Color.White, Math.Max(1.2f, size * 0.085f)) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLines(pen, pts);
            }
            return b;
        }

        /// <summary>Tray badge: the ping number. Filled when Boost is working, outlined when only monitoring.</summary>
        public static Bitmap Badge(int size, string text, Color col, bool filled)
        {
            var b = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.Clear(Color.Transparent);
                var r = new RectangleF(0.5f, 0.5f, size - 1f, size - 1f);
                float rad = size * 0.22f;
                if (filled) Draw.FillRound(g, col, r, rad);
                else
                {
                    Draw.FillRound(g, Color.FromArgb(240, 20, 23, 35), r, rad);
                    Draw.StrokeRound(g, Color.FromArgb(210, col), r, rad, Math.Max(1f, size / 16f));
                }
                float px = text.Length <= 2 ? size * 0.66f : size * 0.48f;
                using (var f = new Font("Segoe UI", px, FontStyle.Bold, GraphicsUnit.Pixel))
                using (var sf = new StringFormat(StringFormat.GenericTypographic) { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                using (var br = new SolidBrush(filled ? Color.White : col))
                {
                    sf.FormatFlags |= StringFormatFlags.NoWrap | StringFormatFlags.NoClip;
                    g.DrawString(text, f, br, new RectangleF(-size, 0, size * 3, size), sf);
                }
            }
            return b;
        }

        /// <summary>Converts a bitmap into an Icon that owns its handle (safe to Dispose).</summary>
        public static Icon ToIcon(Bitmap b)
        {
            IntPtr h = b.GetHicon();
            try
            {
                using (var tmp = Icon.FromHandle(h)) return (Icon)tmp.Clone();
            }
            finally { Native.DestroyIcon(h); }
        }

        /// <summary>Writes the multi-size .ico that is embedded in the exe at build time.</summary>
        public static void WriteIco(string path)
        {
            int[] sizes = { 16, 20, 24, 32, 40, 48, 64, 256 };
            var blobs = new List<byte[]>();
            foreach (int s in sizes)
                using (var b = Logo(s)) blobs.Add(s >= 256 ? Png(b) : Dib(b));

            using (var fs = File.Create(path))
            using (var w = new BinaryWriter(fs))
            {
                w.Write((short)0); w.Write((short)1); w.Write((short)sizes.Length);
                int offset = 6 + 16 * sizes.Length;
                for (int i = 0; i < sizes.Length; i++)
                {
                    int s = sizes[i];
                    w.Write((byte)(s >= 256 ? 0 : s));
                    w.Write((byte)(s >= 256 ? 0 : s));
                    w.Write((byte)0); w.Write((byte)0);
                    w.Write((short)1); w.Write((short)32);
                    w.Write(blobs[i].Length);
                    w.Write(offset);
                    offset += blobs[i].Length;
                }
                foreach (var blob in blobs) w.Write(blob);
            }
        }

        static byte[] Png(Bitmap b)
        {
            using (var ms = new MemoryStream())
            {
                b.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        static byte[] Dib(Bitmap b)
        {
            int s = b.Width;
            using (var ms = new MemoryStream())
            using (var w = new BinaryWriter(ms))
            {
                w.Write(40); w.Write(s); w.Write(s * 2);
                w.Write((short)1); w.Write((short)32);
                w.Write(0); w.Write(0); w.Write(0); w.Write(0); w.Write(0); w.Write(0);
                var data = b.LockBits(new Rectangle(0, 0, s, s), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                try
                {
                    var row = new byte[s * 4];
                    for (int y = s - 1; y >= 0; y--)
                    {
                        Marshal.Copy(IntPtr.Add(data.Scan0, y * data.Stride), row, 0, row.Length);
                        w.Write(row);
                    }
                }
                finally { b.UnlockBits(data); }
                w.Write(new byte[((s + 31) / 32) * 4 * s]);   // AND mask (unused with 32-bit alpha)
                w.Flush();
                return ms.ToArray();
            }
        }
    }
}
