using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace LO5G
{
    sealed partial class MainForm
    {
        // dashboard
        Txt heroTitle, heroSub, heroSub2, iConn, iConnSub, iRouter, iRouterSub, iDiag;
        Seg boostSeg, modeSeg;
        StatBox sPing, sJit, sLoss, sScore;
        Graph graph;
        // optimize
        Txt wifiDesc, tweakMsg;
        Toggle wifiTog, classicTog;
        readonly Check[] tweakChk = new Check[Tweaks.Ids.Length];
        readonly Pill[] tweakPill = new Pill[Tweaks.Ids.Length];
        readonly int[] tweakState = { -2, -2, -2, -2, -2 };
        Btn applyBtn, restoreBtn;
        bool tweakBusy;
        // games
        DarkList gameList;
        Txt gamesCount, gameNow, gameNowSub;
        Toggle prioTog;
        // tune
        Btn tuneBtn;
        Txt tuneStatus, tuneSub, tuneVerdict;
        Bar tuneBar;
        TuneTable tuneTable;
        TuneResult lastTune;
        string tuneVerdictKey = "tune.hint";
        // settings
        readonly Toggle[] setTog = new Toggle[4];
        Seg langSeg;
        TextBox targetBox;
        Txt targetNow;

        // =====================================================================================
        // Dashboard
        // =====================================================================================

        Panel BuildDashboard()
        {
            var p = NewPage();
            Title(p, T("nav.dash"));

            var hero = NewCard(p, PX, 62, PW, 104);
            heroTitle = Lbl(hero, "", Theme.F(15f, true), Theme.Text, 20, 12, 350, 32);
            heroSub = Lbl(hero, "", Theme.F(9.5f), Theme.Dim, 20, 46, 350, 22);
            heroSub2 = Lbl(hero, "", Theme.F(9f), Theme.Dim, 20, 70, 350, 22);

            boostSeg = Put(hero, new Seg(new[] { T("boost.off"), T("boost.auto"), T("boost.on") })
            {
                Colors = new[] { Theme.Muted, Theme.Accent2, Theme.Accent },
                Font = Theme.F(10f, true)
            }, PW - 20 - 230, 14, 230, 38);
            boostSeg.Changed += SetBoost;

            modeSeg = Put(hero, new Seg(new[] { T("mode.0"), T("mode.1"), T("mode.2"), T("mode.3") }) { Font = Theme.F(9f, true) },
                PW - 20 - 300, 62, 300, 30);
            modeSeg.Changed += SetMode;

            const int bw = 167, gap = 12;
            sPing = Put(p, new StatBox(T("stat.ping"), "ms"), PX, 178, bw, 92);
            sJit = Put(p, new StatBox(T("stat.jitter"), "ms"), PX + (bw + gap), 178, bw, 92);
            sLoss = Put(p, new StatBox(T("stat.loss"), "%"), PX + 2 * (bw + gap), 178, bw, 92);
            sScore = Put(p, new StatBox(T("stat.score"), "/100"), PX + 3 * (bw + gap), 178, bw, 92);

            var gc = NewCard(p, PX, 282, PW, 240);
            Lbl(gc, T("graph.title"), Theme.F(10.5f, true), Theme.Text, 18, 10, 340, 24);
            Put(gc, new Legend(new[] { T("graph.inet"), T("graph.router"), T("graph.lost") }, new[] { Theme.Accent, Theme.Accent2, Theme.Bad }),
                PW - 18 - 300, 10, 300, 24);
            graph = Put(gc, new Graph { Main = Core.Inet, Router = Core.Gw }, 8, 38, PW - 16, 196);

            var ic = NewCard(p, PX, 534, PW, 86);
            Font cap = Theme.F(8f, true);
            Lbl(ic, T("info.conn"), cap, Theme.Dim, 18, 9, 200, 18);
            iConn = Lbl(ic, "", Theme.F(10.5f, true), Theme.Text, 18, 29, 204, 24);
            iConnSub = Lbl(ic, "", Theme.F(8.5f), Theme.Dim, 18, 55, 204, 20);
            Lbl(ic, T("info.router"), cap, Theme.Dim, 236, 9, 190, 18);
            iRouter = Lbl(ic, "", Theme.F(10.5f, true), Theme.Text, 236, 29, 190, 24);
            iRouterSub = Lbl(ic, "", Theme.F(8.5f), Theme.Dim, 236, 55, 196, 20);
            Lbl(ic, T("info.diag"), cap, Theme.Dim, 444, 9, 240, 18);
            iDiag = Lbl(ic, "", Theme.F(9f, true), Theme.Text, 444, 27, 246, 54);
            iDiag.Wrap = true;
            iDiag.VAlign = HA.Start;
            return p;
        }

        /// <summary>Pushes setting values into the controls (they can change from the tray menu).</summary>
        void SyncControls()
        {
            if (boostSeg == null) return;
            boostSeg.Selected = Settings.Boost;
            modeSeg.Selected = Settings.Mode;
            boostSeg.Enabled = modeSeg.Enabled = !Core.Tuning;
            wifiTog.Checked = Settings.WifiOpt;
            classicTog.Checked = Settings.Classic;
            limTog.Checked = Settings.Limiter;
            limSeg.Selected = Math.Max(0, Array.IndexOf(Settings.LimitChoices, Settings.LimitKbps));
            prioTog.Checked = Settings.GamePriority;
            setTog[1].Checked = Settings.StartMinimized;
            setTog[2].Checked = Settings.Notifications;
            setTog[3].Checked = Settings.TrayPing;
            langSeg.Selected = Loc.Rtl ? 1 : 0;

            Color c = Core.Active ? Theme.Accent : Settings.Boost == 1 ? Theme.Accent2 : Theme.Dim;
            sidePill.Set("●  " + T(Core.Active ? "side.on" : Settings.Boost == 1 ? "side.wait" : "side.off"), c);
        }

        void RefreshUi()
        {
            if (heroTitle == null) return;
            switch (page)
            {
                case 0: RefreshDashboard(); break;
                case 1: RefreshOptimize(); break;
                case 2: RefreshLimiter(); break;
                case 3: RefreshGames(); break;
                case 5: RefreshSettings(); break;
            }
        }

        void RefreshDashboard()
        {
            var st = Core.Inet.GetStats(60000);
            var gw = Core.Gw.GetStats(30000);
            var net = Core.Net;
            string game = Core.Games.Running;

            if (Core.Tuning)
            {
                heroTitle.Text = T("hero.tune"); heroTitle.ForeColor = Theme.Accent2;
                heroSub.Text = T("hero.sub.tune");
            }
            else if (Core.Active)
            {
                heroTitle.Text = Settings.Boost == 1 && game != null ? Loc.T("hero.on.game", game) : T("hero.on");
                heroTitle.ForeColor = Theme.Accent;
                heroSub.Text = Core.Target != null ? Loc.T("hero.sub.on", Core.Pulse.Pps)
                             : Core.NetBusy ? T("hero.sub.detect") : T("hero.sub.nonet");
            }
            else if (Settings.Boost == 1)
            {
                heroTitle.Text = T("hero.wait"); heroTitle.ForeColor = Theme.Accent2;
                heroSub.Text = T("hero.sub.wait");
            }
            else
            {
                heroTitle.Text = T("hero.off"); heroTitle.ForeColor = Theme.Text;
                heroSub.Text = T("hero.sub.off");
            }
            heroSub2.Text = Loc.T("hero.traffic", Loc.Ltr("↓ " + Fmt.Rate(Core.RxAvgBps)), Loc.Ltr("↑ " + Fmt.Rate(Core.TxAvgBps)), Loc.Ltr(Fmt.Bytes(Core.BoostBytes)));

            bool live = st.Valid && st.Last >= 0;
            sPing.Set(live ? Fmt.N0(st.Last) : "—",
                      st.Valid ? Loc.T("stat.avgmax", Fmt.N0(st.Avg), Fmt.N0(st.Max)) : "",
                      st.Count == 0 ? Theme.Dim : live ? Theme.PingColor(st.Last) : Theme.Bad);
            sJit.Set(st.Valid ? Fmt.N1(st.Jitter) : "—",
                     st.Valid ? Loc.T("stat.spikes", st.Spikes) : "",
                     st.Valid ? Theme.JitterColor(st.Jitter) : Theme.Dim);
            sLoss.Set(st.Count > 0 ? (st.LossPct < 10 ? Fmt.N1(st.LossPct) : Fmt.N0(st.LossPct)) : "—",
                      st.Count > 0 ? Loc.T("stat.lost", st.Lost, st.Count) : "",
                      st.Count > 0 ? Theme.LossColor(st.LossPct) : Theme.Dim);
            string q = st.Score >= 90 ? "q.excellent" : st.Score >= 75 ? "q.good" : st.Score >= 50 ? "q.fair" : "q.poor";
            sScore.Set(st.Valid ? st.Score.ToString() : "—", st.Valid ? T(q) : "", st.Valid ? Theme.ScoreColor(st.Score) : Theme.Dim);

            iConn.Text = T("kind." + net.Kind);
            if (net.Kind == "wifi" && Core.Wifi.Present && !string.IsNullOrEmpty(Core.Wifi.Ssid))
            {
                iConnSub.Ltr = false;
                iConnSub.Text = Loc.T("wifi.sub", Core.Wifi.Ssid, Core.Wifi.Signal);
            }
            else
            {
                iConnSub.Ltr = true;
                iConnSub.Text = net.Desc;
            }

            if (gw.Valid && gw.Last >= 0)
            {
                iRouter.Ltr = true;
                iRouter.Text = gw.Last < 1 ? "< 1 ms" : Fmt.N0(gw.Last) + " ms";
                iRouter.ForeColor = gw.Last <= 10 ? Theme.Good : gw.Last <= 30 ? Theme.Warn : Theme.Bad;
                iRouterSub.Text = Loc.T("router.sub", Loc.Ltr(Fmt.N1(gw.Jitter) + " ms"), Loc.Ltr(Fmt.N0(gw.LossPct) + "%"));
            }
            else
            {
                iRouter.Ltr = false;
                iRouter.Text = net.Gateway == null ? "—" : T("router.na");
                iRouter.ForeColor = Theme.Dim;
                iRouterSub.Text = net.Gateway != null && gw.Count >= 4 ? T("router.na.sub") : "";
            }

            Color dc;
            iDiag.Text = Diagnose(st, gw, out dc);
            iDiag.ForeColor = dc;
            graph.Invalidate();
        }

        static string Diagnose(Stats st, Stats gw, out Color col)
        {
            col = Theme.Good;
            if (Core.Net.Local == null && !Core.NetBusy) { col = Theme.Bad; return T("diag.offline"); }
            if (st.Count < 8) { col = Theme.Dim; return T("diag.wait"); }
            if (!st.Valid) { col = Theme.Bad; return T("diag.nonet"); }

            // Another program filling the line is the most common (and most fixable) cause: name it first.
            bool heavy = Core.TxAvgBps > 1.2e6 || Core.RxAvgBps > 8e6;
            bool rough = st.LossPct >= 1 || st.Jitter >= 8 || st.SpikePct >= 3;
            if (heavy && rough)
            {
                col = Theme.Warn;
                string rate = Loc.Ltr(Core.TxAvgBps * 4 > Core.RxAvgBps ? "↑ " + Fmt.Rate(Core.TxAvgBps) : "↓ " + Fmt.Rate(Core.RxAvgBps));
                string hog = Core.Traffic.Top;
                if (hog == null) return Loc.T("diag.bg", rate);
                if (Core.Limiter.CappedNow.Contains(hog, StringComparer.OrdinalIgnoreCase))
                {
                    // Capped on paper. If it still uploads well above the limit, its connection predates the limiter.
                    double cap = Settings.LimitKbps * 1000.0;
                    return Core.TxAvgBps > cap * 1.3 + 300000
                        ? Loc.T("diag.hog.stale", hog)
                        : Loc.T("diag.hog.capped", hog, Loc.Ltr(Fmt.Rate(cap)));
                }
                return Loc.T("diag.hog", hog, rate);
            }

            bool gwSeen = gw.Valid && gw.Count >= 5;
            if (st.LossPct >= 2)
            {
                col = Theme.Bad;
                return gwSeen && gw.LossPct >= 2 ? T("diag.loss.local") : T("diag.loss.isp");
            }
            bool localBad = gwSeen && (gw.Jitter >= 6 || gw.Avg >= 20);
            if (st.Jitter >= 10 || st.SpikePct >= 3)
            {
                col = Theme.Warn;
                if (localBad) return T("diag.local");
                return Core.Active ? T("diag.jitter.on") : T("diag.jitter.off");
            }
            if (localBad) { col = Theme.Warn; return T("diag.local"); }
            return T("diag.ok");
        }

        // =====================================================================================
        // Optimize
        // =====================================================================================

        Panel BuildOptimize()
        {
            var p = NewPage();
            Title(p, T("nav.opt"));

            var a = NewCard(p, PX, 62, PW, 78);
            Put(a, new GlyphTile("", Theme.Accent), 16, 20, 38, 38);
            Lbl(a, T("opt.wifi"), Theme.F(11f, true), Theme.Text, 64, 14, 540, 24);
            wifiDesc = Lbl(a, "", Theme.F(9f), Theme.Dim, 64, 40, 560, 22);
            wifiTog = Put(a, new Toggle(), PW - 20 - 46, 26, 46, 26);
            wifiTog.Toggled += v => { Settings.WifiOpt = v; Settings.Save(); Core.Reevaluate(); };

            var b = NewCard(p, PX, 150, PW, 78);
            Put(b, new GlyphTile("", Theme.Accent2), 16, 20, 38, 38);
            Lbl(b, T("opt.classic"), Theme.F(11f, true), Theme.Text, 64, 14, 540, 24);
            Lbl(b, T("opt.classic.d"), Theme.F(9f), Theme.Dim, 64, 40, 560, 22);
            classicTog = Put(b, new Toggle(), PW - 20 - 46, 26, 46, 26);
            classicTog.Toggled += v => { Settings.Classic = v; Settings.Save(); Core.Reevaluate(); };

            var c = NewCard(p, PX, 238, PW, 382);
            Lbl(c, T("opt.sys"), Theme.F(11f, true), Theme.Text, 18, 12, 500, 24);
            Lbl(c, T("opt.sys.sub"), Theme.F(9f), Theme.Dim, 18, 36, 668, 20);
            for (int i = 0; i < Tweaks.Ids.Length; i++)
            {
                int y = 62 + i * 50;
                string id = Tweaks.Ids[i];
                tweakChk[i] = Put(c, new Check { Checked = true }, 18, y + 13, 22, 22);
                Lbl(c, T("tw." + id), Theme.F(10f, true), Theme.Text, 52, y + 3, 500, 22);
                Lbl(c, T("tw." + id + ".d"), Theme.F(8.5f), Theme.Dim, 52, y + 25, 510, 18);
                tweakPill[i] = Put(c, new Pill(), PW - 18 - 112, y + 12, 112, 24);
            }
            applyBtn = Put(c, new Btn(T("opt.apply"), true, ""), 18, 324, 210, 40);
            restoreBtn = Put(c, new Btn(T("opt.restore"), false, ""), 238, 324, 190, 40);
            tweakMsg = Lbl(c, T("opt.note"), Theme.F(8.5f), Theme.Dim, 440, 322, 246, 44);
            tweakMsg.Wrap = true;
            applyBtn.Click += (s, e) => ApplyTweaks();
            restoreBtn.Click += (s, e) => RestoreTweaks();
            ShowTweakStates();
            return p;
        }

        void RefreshOptimize()
        {
            var w = Core.Wifi;
            if (!w.Present) wifiDesc.Text = Core.Net.Kind == "wifi" ? T("opt.wifi.d") : T("opt.wifi.none");
            else if (w.Failed) wifiDesc.Text = T("opt.wifi.err");
            else wifiDesc.Text = Loc.T(w.Applied ? "opt.wifi.on" : "opt.wifi.idle", w.Ssid ?? "Wi-Fi", w.Signal);
            wifiDesc.ForeColor = w.Present && w.Applied ? Theme.Accent : w.Failed ? Theme.Warn : Theme.Dim;
        }

        void ShowTweakStates()
        {
            for (int i = 0; i < tweakPill.Length; i++)
            {
                if (tweakPill[i] == null) continue;
                switch (tweakState[i])
                {
                    case 1: tweakPill[i].Set(T("pill.on"), Theme.Good); break;
                    case 0: tweakPill[i].Set(T("pill.off"), Theme.Dim); break;
                    case -1: tweakPill[i].Set(T("pill.na"), Theme.Dim); break;
                    default: tweakPill[i].Set(T("pill.check"), Theme.Dim); break;
                }
            }
        }

        /// <summary>Reads the real state of every tweak from Windows (in the background: one of them runs powercfg).</summary>
        void RefreshTweaks()
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                var states = new int[Tweaks.Ids.Length];
                for (int i = 0; i < states.Length; i++) states[i] = Tweaks.State(Tweaks.Ids[i]);
                try
                {
                    BeginInvoke(new Action(() =>
                    {
                        if (IsDisposed) return;
                        Array.Copy(states, tweakState, states.Length);
                        ShowTweakStates();
                    }));
                }
                catch { }
            });
        }

        void SetTweakBusy(bool busy, string msg, Color col)
        {
            tweakBusy = busy;
            applyBtn.Enabled = restoreBtn.Enabled = !busy;
            tweakMsg.Text = msg;
            tweakMsg.ForeColor = col;
        }

        void ApplyTweaks()
        {
            if (tweakBusy) return;
            var ids = Tweaks.Ids.Where((id, i) => tweakChk[i].Checked && tweakState[i] != -1).ToArray();
            if (ids.Length == 0) return;
            string games = string.Join("|", Settings.Games.Select(Tweaks.Sanitize).Where(s => s.Length > 0));
            SetTweakBusy(true, T("opt.applying"), Theme.Accent2);
            RunElevated("--elevated apply " + string.Join(",", ids) + " --games \"" + games + "\"", code =>
            {
                if (code == 0) SetTweakBusy(false, T("opt.done"), Theme.Good);
                else if (code == -3) SetTweakBusy(false, T("opt.denied"), Theme.Warn);
                else SetTweakBusy(false, Loc.T("opt.fail", code), Theme.Warn);
                RefreshTweaks();
            });
        }

        void RestoreTweaks()
        {
            if (tweakBusy) return;
            SetTweakBusy(true, T("opt.applying"), Theme.Accent2);
            RunElevated("--elevated restore", code =>
            {
                if (code == 0) SetTweakBusy(false, T("opt.restored"), Theme.Good);
                else if (code == -3) SetTweakBusy(false, T("opt.denied"), Theme.Warn);
                else SetTweakBusy(false, Loc.T("opt.fail", code), Theme.Warn);
                RefreshTweaks();
            });
        }

        /// <summary>Relaunches this exe elevated for one job (a single UAC prompt), then reports its exit code.</summary>
        void RunElevated(string args, Action<int> done)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                int code;
                try
                {
                    var psi = new ProcessStartInfo(Application.ExecutablePath, args) { UseShellExecute = true, Verb = "runas" };
                    using (var p = Process.Start(psi))
                    {
                        if (p == null) code = -1;
                        else if (p.WaitForExit(300000)) code = p.ExitCode;
                        else code = -2;
                    }
                }
                catch (Win32Exception) { code = -3; }   // the user said No on the UAC prompt
                catch (Exception ex) { Program.Log(ex); code = -1; }
                try { BeginInvoke(new Action(() => { if (!IsDisposed) done(code); })); } catch { }
            });
        }

        // =====================================================================================
        // Games
        // =====================================================================================

        Panel BuildGames()
        {
            var p = NewPage();
            Title(p, T("nav.games"));
            Lbl(p, T("games.sub"), Theme.F(9.5f), Theme.Dim, PX, 52, PW, 22);

            var lc = NewCard(p, PX, 84, 430, 536);
            gamesCount = Lbl(lc, "", Theme.F(10.5f, true), Theme.Text, 16, 10, 398, 24);
            gameList = Put(lc, new DarkList(), 8, 40, 414, 488);
            gameList.TagOf = o => string.Equals(GameWatcher.Strip(o.ToString()), Core.Games.Running, StringComparison.OrdinalIgnoreCase) ? T("games.running") : null;

            const int rx = PX + 442, rw = 262;
            var sc = NewCard(p, rx, 84, rw, 92);
            Lbl(sc, T("games.detected"), Theme.F(8f, true), Theme.Dim, 16, 10, rw - 32, 18);
            gameNow = Lbl(sc, "", Theme.F(11f, true), Theme.Text, 16, 31, rw - 32, 26);
            gameNowSub = Lbl(sc, "", Theme.F(8.5f), Theme.Dim, 16, 59, rw - 32, 20);

            Put(p, new Btn(T("games.add.run"), true, ""), rx, 188, rw, 40).Click += (s, e) => AddRunningGame();
            Put(p, new Btn(T("games.add.exe"), false, ""), rx, 236, rw, 40).Click += (s, e) => AddGameFile();
            Put(p, new Btn(T("games.remove"), false, ""), rx, 284, rw, 40).Click += (s, e) => RemoveGame();

            var pc = NewCard(p, rx, 336, rw, 118);
            Lbl(pc, T("games.prio"), Theme.F(10f, true), Theme.Text, 16, 12, rw - 32 - 56, 24);
            prioTog = Put(pc, new Toggle(), rw - 16 - 46, 11, 46, 26);
            prioTog.Toggled += v => { Settings.GamePriority = v; Settings.Save(); Core.Games.Poke(); };
            var pd = Lbl(pc, T("games.prio.d"), Theme.F(8.5f), Theme.Dim, 16, 42, rw - 32, 68);
            pd.Wrap = true; pd.VAlign = HA.Start;

            var hc = NewCard(p, rx, 466, rw, 154);
            Lbl(hc, T("games.tip.t"), Theme.F(10f, true), Theme.Accent, 16, 12, rw - 32, 24);
            var tip = Lbl(hc, T("games.tip"), Theme.F(9f), Theme.Dim, 16, 40, rw - 32, 106);
            tip.Wrap = true; tip.VAlign = HA.Start;

            LoadGames();
            return p;
        }

        void LoadGames()
        {
            if (gameList == null) return;
            object sel = gameList.SelectedItem;
            gameList.BeginUpdate();
            gameList.Items.Clear();
            foreach (string g in Settings.Games.OrderBy(x => x, StringComparer.OrdinalIgnoreCase)) gameList.Items.Add(g);
            if (sel != null && gameList.Items.Contains(sel)) gameList.SelectedItem = sel;
            gameList.EndUpdate();
            gamesCount.Text = Loc.T("games.count", Settings.Games.Count);
        }

        string shownGame = "\0";

        void RefreshGames()
        {
            string g = Core.Games.Running;
            gameNow.Text = g != null ? g + ".exe" : T("games.none");
            gameNow.Ltr = g != null;
            gameNow.ForeColor = g != null ? Theme.Accent : Theme.Text;
            gameNowSub.Text = g != null ? T("games.active.sub") : T("games.none.sub");
            if (g != shownGame) { shownGame = g; gameList.Invalidate(); }
        }

        void SaveGames(IEnumerable<string> list)
        {
            // Replace the list instead of editing it: the watcher thread reads it concurrently.
            Settings.Games = list.Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            Settings.Save();
            LoadGames();
            Core.Games.Poke();
        }

        void AddGame(string exe)
        {
            exe = Tweaks.Sanitize(exe);
            if (exe.Length == 0) return;
            SaveGames(Settings.Games.Concat(new[] { exe }));
            gameList.SelectedItem = gameList.Items.Cast<object>().FirstOrDefault(o => string.Equals(o.ToString(), exe, StringComparison.OrdinalIgnoreCase));
        }

        void AddRunningGame()
        {
            using (var dlg = new GamePicker(T("pick.title")))
                if (dlg.ShowDialog(this) == DialogResult.OK && dlg.Picked != null) AddGame(dlg.Picked);
        }

        void AddGameFile()
        {
            using (var dlg = new OpenFileDialog { Filter = T("games.filter"), CheckFileExists = true })
                if (dlg.ShowDialog(this) == DialogResult.OK) AddGame(Path.GetFileName(dlg.FileName));
        }

        void RemoveGame()
        {
            string sel = gameList.SelectedItem as string;
            if (sel == null) return;
            int idx = gameList.SelectedIndex;
            SaveGames(Settings.Games.Where(g => !string.Equals(g, sel, StringComparison.OrdinalIgnoreCase)));
            if (gameList.Items.Count > 0) gameList.SelectedIndex = Math.Min(idx, gameList.Items.Count - 1);
        }

        // =====================================================================================
        // Auto-Tune
        // =====================================================================================

        Panel BuildTune()
        {
            var p = NewPage();
            Title(p, T("nav.tune"));
            var d = Lbl(p, T("tune.desc"), Theme.F(9.5f), Theme.Dim, PX, 52, PW, 42);
            d.Wrap = true; d.VAlign = HA.Start;

            var c = NewCard(p, PX, 102, PW, 92);
            tuneBtn = Put(c, new Btn(T(Core.Tuning ? "tune.stop" : "tune.start"), !Core.Tuning, Core.Tuning ? "" : ""), 18, 24, 200, 44);
            tuneBtn.Click += (s, e) => ToggleTune();
            tuneStatus = Lbl(c, T("tune.idle"), Theme.F(10f, true), Theme.Text, 236, 14, 450, 24);
            tuneBar = Put(c, new Bar(), 238, 44, 446, 8);
            tuneSub = Lbl(c, "", Theme.F(8.5f), Theme.Dim, 236, 58, 450, 20);

            var r = NewCard(p, PX, 206, PW, 414);
            tuneTable = Put(r, new TuneTable { Result = lastTune }, 8, 8, PW - 16, 262);
            tuneVerdict = Lbl(r, "", Theme.F(10f), Theme.Dim, 20, 280, PW - 40, 120);
            tuneVerdict.Wrap = true; tuneVerdict.VAlign = HA.Start;
            ShowTuneVerdict();
            return p;
        }

        void ToggleTune()
        {
            if (Core.Tuning) { Core.CancelAutoTune(); return; }
            lastTune = null;
            tuneVerdictKey = "";
            tuneTable.Result = null;
            tuneTable.Invalidate();
            tuneVerdict.Text = "";
            tuneBtn.Primary = false;
            tuneBtn.Glyph = "";
            tuneBtn.Text = T("tune.stop");
            tuneBtn.Invalidate();
            tuneBar.Value = 0;
            Core.StartAutoTune(OnTuneProgress, OnTuneDone);
        }

        void OnTuneProgress(double frac, int mode, int round)
        {
            try
            {
                BeginInvoke(new Action(() =>
                {
                    if (IsDisposed || tuneBar == null || !Core.Tuning) return;
                    tuneBar.Value = (float)frac;
                    if (mode == -2) { tuneStatus.Text = T("tune.finishing"); tuneSub.Text = ""; }
                    else
                    {
                        string name = mode < 0 ? T("tune.off") : T("mode." + mode);
                        tuneStatus.Text = Loc.T("tune.running", name, round, Core.TuneRounds);
                        tuneSub.Text = Loc.T("tune.left", (int)Math.Ceiling(Core.TuneTotalSeconds * (1 - frac)));
                    }
                    if (tuneTable.Live != mode) { tuneTable.Live = mode; tuneTable.Invalidate(); }
                }));
            }
            catch { }
        }

        void OnTuneDone(TuneResult res)
        {
            try
            {
                BeginInvoke(new Action(() =>
                {
                    if (IsDisposed) return;
                    lastTune = res.Cancelled || res.NoData ? null : res;
                    tuneVerdictKey = res.Cancelled ? "tune.cancelled" : res.NoData ? "tune.nodata" : "result";
                    if (tuneTable == null) return;
                    tuneTable.Live = -99;
                    tuneTable.Result = lastTune;
                    tuneTable.Invalidate();
                    tuneBar.Value = lastTune != null ? 1f : 0f;
                    tuneStatus.Text = lastTune != null ? T("tune.done") : T("tune.idle");
                    tuneSub.Text = "";
                    tuneBtn.Primary = true;
                    tuneBtn.Glyph = "";
                    tuneBtn.Text = T("tune.start");
                    tuneBtn.Invalidate();
                    ShowTuneVerdict();
                    SyncControls();
                }));
            }
            catch { }
        }

        void ShowTuneVerdict()
        {
            if (tuneVerdict == null) return;
            if (tuneVerdictKey != "result" || lastTune == null)
            {
                tuneVerdict.Text = tuneVerdictKey.Length == 0 ? "" : T(tuneVerdictKey);
                tuneVerdict.ForeColor = tuneVerdictKey == "tune.nodata" ? Theme.Warn : Theme.Dim;
                return;
            }
            var r = lastTune;
            string text;
            if (r.AlreadyStable) text = r.JitterOff >= 8 ? Loc.T("tune.res.nohelp", Fmt.N0(r.JitterOff)) : T("tune.res.flat");
            else if (r.GainPct >= 1)
                text = Loc.T("tune.res.good", T("mode." + r.Mode), Fmt.N1(r.JitterOff), Fmt.N1(r.JitterBest), Fmt.N0(r.GainPct));
            else text = Loc.T("tune.res.same", T("mode." + r.Mode));
            if (Settings.Boost == 0) text += T("tune.res.boostoff");
            tuneVerdict.Text = text;
            tuneVerdict.ForeColor = Theme.Text;
        }

        // =====================================================================================
        // Settings
        // =====================================================================================

        Panel BuildSettings()
        {
            var p = NewPage();
            Title(p, T("nav.set"));

            var g = NewCard(p, PX, 62, PW, 196);
            string[] keys = { "set.autostart", "set.min", "set.notify", "set.trayping" };
            for (int i = 0; i < keys.Length; i++)
            {
                int y = 10 + i * 44;
                Lbl(g, T(keys[i]), Theme.F(10f, true), Theme.Text, 18, y + 2, 560, 22);
                Lbl(g, T(keys[i] + ".d"), Theme.F(8.5f), Theme.Dim, 18, y + 22, 560, 18);
                setTog[i] = Put(g, new Toggle(), PW - 18 - 46, y + 8, 46, 26);
            }
            setTog[0].Checked = Autostart.Enabled;
            setTog[0].Toggled += v => { Autostart.Enabled = v; };
            setTog[1].Toggled += v => { Settings.StartMinimized = v; Settings.Save(); };
            setTog[2].Toggled += v => { Settings.Notifications = v; Settings.Save(); };
            setTog[3].Toggled += v => { Settings.TrayPing = v; Settings.Save(); UpdateTray(); };

            var l = NewCard(p, PX, 270, 346, 100);
            Lbl(l, T("set.lang"), Theme.F(10f, true), Theme.Text, 18, 12, 300, 22);
            langSeg = Put(l, new Seg(new[] { "English", "العربية" }) { Font = Theme.F(10f, true) }, 18, 46, 250, 38);
            langSeg.Changed += i =>
            {
                Settings.Lang = i == 0 ? "en" : "ar";
                Settings.Save();
                Loc.Use(Settings.Lang);
                BeginInvoke(new Action(Rebuild));   // rebuild after this click finishes
            };

            var t = NewCard(p, PX + 358, 270, 346, 100);
            Lbl(t, T("set.target"), Theme.F(10f, true), Theme.Text, 18, 12, 310, 22);
            targetBox = new TextBox
            {
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Theme.Inset,
                ForeColor = Theme.Text,
                Font = Theme.F(10.5f),
                Text = Settings.Target,
                RightToLeft = RightToLeft.No
            };
            Put(t, targetBox, 18, 43, 200, 28);
            targetBox.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; ApplyTarget(); } };
            Put(t, new Btn(T("set.apply")), 228, 40, 100, 32).Click += (s, e) => ApplyTarget();
            targetNow = Lbl(t, "", Theme.F(8.5f), Theme.Dim, 18, 74, 310, 20);

            var ab = NewCard(p, PX, 382, PW, 238);
            Put(ab, new Pic(IconArt.Logo(S(56))), 20, 20, 56, 56);
            Lbl(ab, "Latency Optimizer 5G", Theme.F(14f, true), Theme.Text, 90, 16, 400, 30).Ltr = true;
            Lbl(ab, "Version " + Program.Version, Theme.F(9f, true), Theme.Accent, 90, 44, 400, 20).Ltr = true;
            Lbl(ab, T("about.credit"), Theme.F(9f), Theme.Dim, 90, 62, 400, 20).Ltr = true;
            var at = Lbl(ab, T("about.text"), Theme.F(9.5f), Theme.Text, 20, 92, PW - 40, 62);
            at.Wrap = true; at.VAlign = HA.Start;
            var us = Lbl(ab, T("about.usage"), Theme.F(8.5f), Theme.Dim, 20, 156, PW - 40, 22);
            us.Wrap = false;
            Put(ab, new Btn(T("set.exit"), false, ""), PW - 20 - 180, 184, 180, 38).Click += (s, e) => ExitApp();
            return p;
        }

        void RefreshSettings()
        {
            var ts = Core.Inet.Targets;
            if (ts.Length == 0) targetNow.Text = "";
            else if (Settings.Target.Trim().Length == 0)
                targetNow.Text = Loc.T("set.target.auto", Loc.Ltr(string.Join("   ", ts.Select(x => x.ToString()))));
            else targetNow.Text = Loc.T("set.target.custom", Loc.Ltr(ts[0].ToString()));
        }

        void ApplyTarget()
        {
            Settings.Target = targetBox.Text.Trim();
            Settings.Save();
            Core.RestartNetwork(0);
        }
    }
}
