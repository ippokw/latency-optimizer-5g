using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("Latency Optimizer 5G")]
[assembly: AssemblyProduct("Latency Optimizer 5G")]
[assembly: AssemblyDescription("Ping stabilizer for 5G, Wi-Fi and cable connections")]
[assembly: AssemblyCompany("Othman Malallah")]
[assembly: AssemblyCopyright("Othman Malallah - Instagram: ippokw")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
// Without this the runtime treats the exe as a .NET 4.0 program and applies old defaults (TLS 1.0 only...).
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]

namespace LO5G
{
    static class Program
    {
        public const string Version = "2.0";

        [STAThread]
        static int Main(string[] args)
        {
            try { return Run(args); }
            catch (Exception ex) { Log(ex); return 1; }
        }

        static int Run(string[] a)
        {
            // Elevated helper: apply or restore the Windows tweaks, then exit. No UI.
            if (a.Length > 0 && a[0] == "--elevated") return Tweaks.RunElevated(a);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (var g = Graphics.FromHwnd(IntPtr.Zero)) Theme.Scale = g.DpiX / 96f;

            if (a.Length > 1 && a[0] == "--makeicon") { IconArt.WriteIco(a[1]); return 0; }
            if (a.Length > 3 && a[0] == "--flood") return DevTools.Flood(a);

            Settings.Load();
            Loc.Init();

            // Developer checks (never touch the saved settings).
            if (a.Length > 0 && (a[0] == "--selftest" || a[0] == "--tune" || a[0] == "--shot" || a[0] == "--tweakstate" || a[0] == "--exp" || a[0] == "--limtest"))
            {
                Settings.ReadOnly = true;
                switch (a[0])
                {
                    case "--limtest": return DevTools.LimiterTest(a);
                    case "--selftest": return DevTools.SelfTest(a);
                    case "--tune": return DevTools.Tune(a);
                    case "--exp": return DevTools.Experiment(a);
                    case "--tweakstate": return DevTools.TweakState(a);
                    default: return DevTools.Shot(a);
                }
            }

            // One instance only: a second launch just brings the first one's window up.
            bool first;
            using (var mutex = new Mutex(true, @"Local\LatencyOptimizer5G_Instance", out first))
            using (var showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, @"Local\LatencyOptimizer5G_Show"))
            using (var exitEvent = new EventWaitHandle(false, EventResetMode.AutoReset, @"Local\LatencyOptimizer5G_Exit"))
            {
                // "LatencyOptimizer5G.exe --exit" closes the running copy cleanly (handy for scripts / uninstall).
                if (a.Contains("--exit")) { if (!first) exitEvent.Set(); return 0; }
                if (!first) { showEvent.Set(); return 0; }

                Application.ThreadException += (s, e) => Log(e.Exception);
                AppDomain.CurrentDomain.UnhandledException += (s, e) => Log(e.ExceptionObject as Exception);

                bool hidden = a.Contains("--tray") || Settings.StartMinimized;
                Core.Start();
                var form = new MainForm(hidden);

                var listener = new Thread(() =>
                {
                    while (true)
                    {
                        try
                        {
                            int which = WaitHandle.WaitAny(new WaitHandle[] { showEvent, exitEvent });
                            if (form.IsDisposed) return;
                            if (which == 1) { form.BeginInvoke(new Action(form.ExitApp)); return; }
                            form.BeginInvoke(new Action(form.ShowWindow));
                        }
                        catch { return; }
                    }
                }) { IsBackground = true, Name = "LO5G show" };
                listener.Start();

                Application.Run(form);
                Core.Stop();
                GC.KeepAlive(mutex);
            }
            return 0;
        }

        static readonly object logLock = new object();

        public static void Log(Exception ex)
        {
            if (ex == null) return;
            try
            {
                lock (logLock)
                {
                    Directory.CreateDirectory(Settings.Dir);
                    string path = Path.Combine(Settings.Dir, "error.log");
                    if (File.Exists(path) && new FileInfo(path).Length > 512 * 1024) File.Delete(path);
                    File.AppendAllText(path, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  " + ex + Environment.NewLine);
                }
            }
            catch { }
        }
    }

    /// <summary>Command-line checks used while building and verifying the app.</summary>
    static class DevTools
    {
        static string Line(string name, Stats s)
        {
            return string.Format(CultureInfo.InvariantCulture,
                "{0}: n={1} lost={2} last={3} avg={4:0.0} min={5} max={6} jitter={7:0.00} p95={8} spikes={9} score={10}",
                name, s.Count, s.Lost, s.Last, s.Avg, s.Min, s.Max, s.Jitter, s.P95, s.Spikes, s.Score);
        }

        /// <summary>--selftest &lt;seconds&gt; &lt;out.txt&gt; [mode]: runs the engine headless and reports what it did.</summary>
        public static int SelfTest(string[] a)
        {
            int sec = int.Parse(a[1]);
            string outPath = a[2];
            if (a.Length > 3) Settings.Mode = int.Parse(a[3]);
            Settings.Boost = 2;
            Core.Start();
            for (int i = 0; i < 100 && Core.NetBusy; i++) Thread.Sleep(100);
            Thread.Sleep(1500);

            long s0 = Core.Pulse.Sent, t0 = PingMonitor.Now;
            Core.Pulse.TakeMaxGapMs();
            Thread.Sleep(sec * 1000);
            long s1 = Core.Pulse.Sent, t1 = PingMonitor.Now;
            double gap = Core.Pulse.TakeMaxGapMs();

            var net = Core.Net;
            var sb = new StringBuilder();
            sb.AppendLine("kind=" + net.Kind + " name=" + net.Name + " desc=" + net.Desc);
            sb.AppendLine("local=" + net.Local + " gateway=" + net.Gateway + " target=" + Core.Target + " pulseTtl=" + Core.PulseTtl);
            sb.AppendLine("active=" + Core.Active + " pulseRunning=" + Core.Pulse.Running + " configuredPps=" + Core.Pulse.Pps);
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "pulse: sent={0} in {1} ms => {2:0.0}/s, maxGap={3:0.00} ms, errors={4}, bytes={5}",
                s1 - s0, t1 - t0, (s1 - s0) * 1000.0 / (t1 - t0), gap, Core.Pulse.Errors, Core.Pulse.Bytes));
            sb.AppendLine(Line("internet", Core.Inet.GetStats(sec * 1000)));
            sb.AppendLine(Line("router", Core.Gw.GetStats(sec * 1000)));
            sb.AppendLine("wifi: present=" + Core.Wifi.Present + " applied=" + Core.Wifi.Applied + " failed=" + Core.Wifi.Failed + " ssid=" + Core.Wifi.Ssid);
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "throughput: rx={0:0} bps tx={1:0} bps", Core.RxBps, Core.TxBps));
            sb.AppendLine("game=" + Core.Games.Running);
            sb.AppendLine("targets=" + string.Join(",", Core.Inet.Targets.Select(x => x.ToString())) + " probes=" + Core.Inet.Probes);
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "avg throughput: rx={0:0} bps tx={1:0} bps, top program={2}", Core.RxAvgBps, Core.TxAvgBps, Core.Traffic.Top ?? "(none)"));
            File.WriteAllText(outPath, sb.ToString());
            Core.Stop();
            return 0;
        }

        /// <summary>
        /// --exp &lt;out.txt&gt; &lt;phaseSeconds&gt; &lt;rounds&gt; &lt;cfg,cfg,...&gt;: interleaved A/B measurement of arbitrary
        /// engine combinations. cfg = off | pN (pulse N per second) | classic | pN+classic.
        /// </summary>
        public static int Experiment(string[] a)
        {
            string outPath = a[1];
            int phaseMs = int.Parse(a[2]) * 1000, rounds = int.Parse(a[3]);
            string[] cfgs = a[4].Split(',');
            Settings.Boost = 0;
            Core.Start();
            for (int i = 0; i < 100 && Core.NetBusy; i++) Thread.Sleep(100);
            Thread.Sleep(1000);
            Core.Tuning = true;                 // keep Core from touching the engines
            Core.Inet.SetInterval(200);
            var target = Core.Target;
            var windows = cfgs.Select(c => new System.Collections.Generic.List<long[]>()).ToArray();

            for (int r = 0; r < rounds; r++)
            {
                for (int j = 0; j < cfgs.Length; j++)
                {
                    int ci = (j + r) % cfgs.Length;
                    string c = cfgs[ci];
                    int pps = 0;
                    foreach (string part in c.Split('+')) if (part.StartsWith("p")) pps = int.Parse(part.Substring(1));
                    if (pps > 0 && target != null) Core.Pulse.Start(target, Core.PulseTtl, pps); else Core.Pulse.Stop();
                    if (c.Contains("classic")) Core.Classic.Start(); else Core.Classic.Stop();
                    Thread.Sleep(2000);
                    long t0 = PingMonitor.Now;
                    Thread.Sleep(phaseMs);
                    windows[ci].Add(new[] { t0, PingMonitor.Now });
                }
            }
            Core.Pulse.Stop();
            Core.Classic.Stop();
            Thread.Sleep(1200);

            var sb = new StringBuilder();
            sb.AppendLine("targets=" + string.Join(",", Core.Inet.Targets.Select(x => x.ToString())) + " ttl=" + Core.PulseTtl
                + " classicOk=" + Core.Classic.Ok + " classicFail=" + Core.Classic.Fail + " classicBytes=" + Core.Classic.Bytes
                + " classicLastError=" + Core.Classic.LastError);
            for (int i = 0; i < cfgs.Length; i++)
            {
                var all = new System.Collections.Generic.List<Sample>();
                double jsum = 0;
                int jn = 0;
                foreach (var w in windows[i])
                {
                    var part = Core.Inet.Range(w[0], w[1]);
                    var ps = Stats.From(part);
                    int v = ps.Count - ps.Lost;
                    if (ps.Valid && v > 1) { jsum += ps.Jitter * (v - 1); jn += v - 1; }
                    all.AddRange(part);
                }
                var st = Stats.From(all);
                sb.AppendLine(string.Format(CultureInfo.InvariantCulture,
                    "{0,-14} n={1,-4} avg={2,6:0.0} median={3,4} jitter={4,6:0.00} p95={5,4} max={6,4} loss={7:0.0}% spikes={8}",
                    cfgs[i], st.Count, st.Avg, st.Median, jn > 0 ? jsum / jn : 0, st.P95, st.Max, st.LossPct, st.Spikes));
            }
            File.WriteAllText(outPath, sb.ToString());
            Core.Stop();
            return 0;
        }

        /// <summary>--flood &lt;seconds&gt; &lt;packetsPerSecond&gt; &lt;ip&gt;: test sender, 1200-byte UDP packets to a closed port on the LAN.</summary>
        public static int Flood(string[] a)
        {
            int sec = int.Parse(a[1]), pps = int.Parse(a[2]);
            var ep = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(a[3]), 9);
            int ttl = a.Length > 4 ? int.Parse(a[4]) : 64, delay = a.Length > 5 ? int.Parse(a[5]) : 0;
            var payload = new byte[1200];
            if (delay > 0) Thread.Sleep(delay);      // lets the test set a limit before the socket exists
            using (var s = new System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Dgram, System.Net.Sockets.ProtocolType.Udp))
            using (var waiter = new HiResWaiter())
            {
                s.Ttl = (short)ttl;
                try { s.IOControl(unchecked((int)0x9800000C), new byte[] { 0, 0, 0, 0 }, null); } catch { }
                var sw = System.Diagnostics.Stopwatch.StartNew();
                long next = 0, interval = System.Diagnostics.Stopwatch.Frequency / pps;
                while (sw.ElapsedMilliseconds < sec * 1000)
                {
                    try { s.SendTo(payload, ep); } catch { }
                    next += interval;
                    long now = sw.ElapsedTicks;
                    if (next < now) next = now;
                    waiter.Wait((next - now) * 1000000L / System.Diagnostics.Stopwatch.Frequency);
                }
            }
            return 0;
        }

        /// <summary>
        /// --limtest &lt;out.txt&gt;: proves the upload limiter on a throw-away sender (a second copy of this exe
        /// that floods the router's closed UDP port). Measures what really leaves the network adapter.
        /// </summary>
        public static int LimiterTest(string[] a)
        {
            var sb = new StringBuilder();
            var net = NetInfo.Detect();
            if (net.Nic == null || net.Gateway == null) { File.WriteAllText(a[1], "no network"); return 1; }
            sb.AppendLine("admin=" + Tweaks.IsAdmin() + " adapter=" + net.Desc + " sink=" + net.Gateway + ":9 (LAN only)");

            Func<int, double> txKBps = seconds =>
            {
                long b0 = net.Nic.GetIPv4Statistics().BytesSent, t0 = PingMonitor.Now;
                Thread.Sleep(seconds * 1000);
                return (net.Nic.GetIPv4Statistics().BytesSent - b0) / 1000.0 / ((PingMonitor.Now - t0) / 1000.0);
            };

            if (a.Length > 2 && a[2] == "matrix2")
            {
                // Can a connection that was opened while the program was merely "armed" be capped and released on demand?
                const long Huge = 12500000000L, Cap = 50000;     // 100 Gbit/s (= no limit) and 400 kbit/s, in bytes per second
                Func<IntPtr, long, uint, bool> set = (job, bytes, flags) =>
                {
                    var info = new Native.NetRateControl { MaxBandwidth = (ulong)bytes, ControlFlags = flags };
                    return Native.SetInformationJobObject(job, 32, ref info, System.Runtime.InteropServices.Marshal.SizeOf(typeof(Native.NetRateControl)));
                };
                foreach (string v in new[] { "armed-huge", "joined-only" })
                {
                    var ch = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(Application.ExecutablePath,
                        "--flood 34 500 " + net.Gateway + " 64 2500") { UseShellExecute = false });
                    Thread.Sleep(600);
                    IntPtr job = Native.CreateJobObjectW(IntPtr.Zero, null);
                    IntPtr h = Native.OpenProcess(0x0101, false, ch.Id);
                    bool joined = Native.AssignProcessToJobObject(job, h);
                    Native.CloseHandle(h);
                    bool armed = v == "armed-huge" && set(job, Huge, 3);
                    Thread.Sleep(2600);                       // the sender opens its socket now
                    var line = new StringBuilder(v + " (joined=" + joined + " armed=" + armed + "):");
                    line.AppendFormat(CultureInfo.InvariantCulture, "  free {0:0}", txKBps(3));
                    set(job, Cap, 3); Thread.Sleep(500);
                    line.AppendFormat(CultureInfo.InvariantCulture, " | cap400 {0:0}", txKBps(3));
                    set(job, Huge, 3); Thread.Sleep(500);
                    line.AppendFormat(CultureInfo.InvariantCulture, " | huge {0:0}", txKBps(3));
                    set(job, Cap, 3); Thread.Sleep(500);
                    line.AppendFormat(CultureInfo.InvariantCulture, " | cap400 {0:0}", txKBps(3));
                    set(job, 0, 0); Thread.Sleep(500);
                    line.AppendFormat(CultureInfo.InvariantCulture, " | flags0 {0:0} then {1:0}", txKBps(2), txKBps(2));
                    set(job, Cap, 3); Thread.Sleep(500);
                    line.AppendFormat(CultureInfo.InvariantCulture, " | cap400 {0:0}", txKBps(3));
                    sb.AppendLine(line + "   KB/s (full speed = 615, cap = 50)");
                    set(job, 0, 0);
                    try { ch.Kill(); } catch { }
                    ch.WaitForExit(3000);
                    Native.CloseHandle(job);
                    Thread.Sleep(500);
                }
                File.WriteAllText(a[1], sb.ToString());
                return 0;
            }

            // The real product flow, end to end.
            string[] apps = { "LatencyOptimizer5G.exe" };
            var child = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(Application.ExecutablePath,
                "--flood 48 500 " + net.Gateway + " 64 3000") { UseShellExecute = false });
            Thread.Sleep(600);
            // Put the sender in an unrelated job first, the way Chromium/Electron apps (Discord) keep their processes in jobs.
            IntPtr outer = Native.CreateJobObjectW(IntPtr.Zero, null);
            IntPtr hp = Native.OpenProcess(0x0101, false, child.Id);
            bool nested = Native.AssignProcessToJobObject(outer, hp);
            Native.CloseHandle(hp);

            var lim = new UploadLimiter();
            lim.Update(true, false, 400, apps);                 // limiter on, Boost off: program is armed, not slowed
            sb.AppendLine("sender pid=" + child.Id + " inside another job=" + nested + " armed=[" + string.Join(",", lim.ArmedNow) + "] capped=[" + string.Join(",", lim.CappedNow) + "]");
            Thread.Sleep(3200);                                  // the sender opens its connection now
            Action<string> step = label => sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "{0,-46} {1,5:0} KB/s   capped=[{2}]", label, txKBps(3), string.Join(",", lim.CappedNow)));

            step("1) armed, Boost off (expect ~615, full speed)");
            lim.Update(true, true, 400, apps); Thread.Sleep(500);
            step("2) Boost on, limit 400 kbps (expect ~50)");
            lim.Update(true, true, 2000, apps); Thread.Sleep(500);
            step("3) limit raised to 2 Mbps (expect ~250)");
            lim.Update(true, false, 2000, apps); Thread.Sleep(500);
            step("4) Boost off again (expect ~615)");
            lim.Update(true, true, 400, apps); Thread.Sleep(500);
            step("5) Boost on, 400 kbps (expect ~50)");

            // "The app was killed while capping": a brand-new limiter must find the cap by name and clear it.
            int cleared = new UploadLimiter().ClearLeftovers(); Thread.Sleep(800);
            step("6) crash recovery cleared " + cleared + " cap (expect ~615)");

            // "The app was started again": it must take the same program back under control.
            var lim2 = new UploadLimiter();
            lim2.Update(true, true, 400, apps); Thread.Sleep(500);
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "{0,-46} {1,5:0} KB/s   capped=[{2}]", "7) after restart, 400 kbps (expect ~50)", txKBps(3), string.Join(",", lim2.CappedNow)));
            lim2.Update(false, true, 400, apps); Thread.Sleep(800);
            sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "{0,-46} {1,5:0} KB/s   armed=[{2}]", "8) limiter switched off (expect ~615)", txKBps(3), string.Join(",", lim2.ArmedNow)));

            lim.Release(); lim2.Release();
            try { child.Kill(); } catch { }
            child.WaitForExit(3000);
            Native.CloseHandle(outer);
            sb.AppendLine("unsupported=" + lim.Unsupported);
            File.WriteAllText(a[1], sb.ToString());
            return 0;
        }


        /// <summary>--tune &lt;out.txt&gt;: runs a full Auto-Tune headless.</summary>
        public static int Tune(string[] a)
        {
            string outPath = a[1];
            Settings.Boost = 2;
            Core.Start();
            for (int i = 0; i < 100 && Core.NetBusy; i++) Thread.Sleep(100);
            Thread.Sleep(1000);

            var done = new ManualResetEvent(false);
            TuneResult res = null;
            Core.StartAutoTune((f, m, r) => { }, x => { res = x; done.Set(); });
            done.WaitOne(300000);

            var sb = new StringBuilder();
            if (res == null) sb.AppendLine("timeout");
            else
            {
                sb.AppendLine("cancelled=" + res.Cancelled + " noData=" + res.NoData + " best=" + res.BestRow + " mode=" + res.Mode
                    + " alreadyStable=" + res.AlreadyStable + " gain=" + res.GainPct.ToString("0.0", CultureInfo.InvariantCulture));
                foreach (var row in res.Rows)
                    sb.AppendLine(string.Format(CultureInfo.InvariantCulture, "mode={0} n={1} avg={2:0.0} jitter={3:0.00} p95={4} loss={5:0.0} score={6:0.00}",
                        row.Mode, row.N, row.Avg, row.Jitter, row.P95, row.Loss, row.Score));
            }
            File.WriteAllText(outPath, sb.ToString());
            Core.Stop();
            return 0;
        }

        /// <summary>--tweakstate &lt;out.txt&gt; [--testroot]: prints the detected state of each Windows tweak.</summary>
        public static int TweakState(string[] a)
        {
            if (a.Contains("--testroot")) Tweaks.Test = true;
            Core.Net = NetInfo.Detect();
            var sb = new StringBuilder();
            sb.AppendLine("interface=" + Core.Net.Id);
            foreach (string id in Tweaks.Ids) sb.AppendLine(id + "=" + Tweaks.State(id));
            File.WriteAllText(a[1], sb.ToString());
            return 0;
        }

        /// <summary>--shot &lt;page&gt; &lt;en|ar&gt; &lt;out.png&gt; [waitMs]: renders one page of the real window to a PNG.</summary>
        public static int Shot(string[] a)
        {
            int page = int.Parse(a[1]);
            Loc.Use(a[2]);
            string outPath = a[3];
            int wait = a.Length > 4 ? int.Parse(a[4]) : 6000;

            if (page == 9)
            {
                // Tray icon sheet: every badge state at the real tray sizes (100%, 150%, 200%), enlarged 4x to inspect.
                string[] texts = { "23", "87", "154", "9", "!", "-" };
                Color[] fills = { Color.FromArgb(22, 160, 96), Color.FromArgb(214, 140, 0), Color.FromArgb(222, 58, 80), Color.FromArgb(22, 160, 96), Color.FromArgb(222, 58, 80), Color.FromArgb(96, 104, 130) };
                Color[] lines = { Theme.Good, Theme.Warn, Theme.Bad, Theme.Good, Theme.Bad, Color.FromArgb(96, 104, 130) };
                int[] sizes = { 16, 24, 32 };
                using (var sheet = new Bitmap(40 + texts.Length * 2 * 140, 40 + sizes.Length * 140))
                using (var g = Graphics.FromImage(sheet))
                {
                    g.Clear(Color.FromArgb(32, 32, 32));
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
                    g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
                    for (int r = 0; r < sizes.Length; r++)
                        for (int c = 0; c < texts.Length * 2; c++)
                        {
                            bool filled = c < texts.Length;
                            int i = c % texts.Length;
                            using (var b = IconArt.Badge(sizes[r], texts[i], filled ? fills[i] : lines[i], filled))
                                g.DrawImage(b, 20 + c * 140, 20 + r * 140, sizes[r] * 4, sizes[r] * 4);
                        }
                    sheet.Save(outPath, System.Drawing.Imaging.ImageFormat.Png);
                }
                return 0;
            }

            Core.Start();
            var form = new MainForm(false) { StartPosition = FormStartPosition.Manual, Location = new Point(-4000, -4000), ShowInTaskbar = false };
            var timer = new System.Windows.Forms.Timer { Interval = wait };
            form.Shown += (s, e) =>
            {
                form.DebugShowPage(page);
                timer.Start();
            };
            timer.Tick += (s, e) =>
            {
                timer.Stop();
                try
                {
                    using (var bmp = new Bitmap(form.ClientSize.Width, form.ClientSize.Height))
                    {
                        form.DebugRender(bmp);
                        bmp.Save(outPath, System.Drawing.Imaging.ImageFormat.Png);
                    }
                }
                catch (Exception ex) { Program.Log(ex); }
                form.ExitApp();
            };
            Application.Run(form);
            Core.Stop();
            return 0;
        }
    }
}
