using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace LO5G
{
    /// <summary>The "Limiter" page: cap the upload of other programs while Boost is on.</summary>
    sealed partial class MainForm
    {
        Toggle limTog;
        Seg limSeg;
        Txt limStatus, limCount, limTop, limTopSub;
        Btn limAddTop;
        DarkList limList;
        string limSignature = "";

        static readonly StringComparer NoCase = StringComparer.OrdinalIgnoreCase;

        static string RateName(int kbps)
        {
            return kbps >= 1000 && kbps % 1000 == 0 ? (kbps / 1000) + " Mbps" : Fmt.N1(kbps / 1000.0) + " Mbps";
        }

        Panel BuildLimiter()
        {
            var p = NewPage();
            Title(p, T("nav.limit"));
            Lbl(p, T("lim.sub"), Theme.F(9.5f), Theme.Dim, PX, 52, PW, 22);

            var a = NewCard(p, PX, 84, PW, 78);
            Put(a, new GlyphTile("", Theme.Accent), 16, 20, 38, 38);
            Lbl(a, T("lim.title"), Theme.F(11f, true), Theme.Text, 64, 14, 540, 24);
            limStatus = Lbl(a, "", Theme.F(9f), Theme.Dim, 64, 40, 560, 22);
            limTog = Put(a, new Toggle(), PW - 20 - 46, 26, 46, 26);
            limTog.Toggled += v => { Settings.Limiter = v; Settings.Save(); ApplyLimiterAsync(); };

            var b = NewCard(p, PX, 172, PW, 66);
            Lbl(b, T("lim.rate"), Theme.F(10f, true), Theme.Text, 18, 10, 340, 22);
            Lbl(b, Loc.T("lim.rate.d", Loc.Ltr("0.1 Mbps")), Theme.F(8.5f), Theme.Dim, 18, 33, 340, 20);
            limSeg = Put(b, new Seg(Settings.LimitChoices.Select(RateName).ToArray()) { Ltr = true, Font = Theme.F(9.5f, true) }, PW - 18 - 320, 15, 320, 36);
            limSeg.Changed += i => { Settings.LimitKbps = Settings.LimitChoices[i]; Settings.Save(); ApplyLimiterAsync(); };

            var lc = NewCard(p, PX, 250, 430, 370);
            limCount = Lbl(lc, "", Theme.F(10.5f, true), Theme.Text, 16, 10, 398, 24);
            limList = Put(lc, new DarkList(), 8, 40, 414, 322);
            limList.TagOf = o =>
            {
                string n = GameWatcher.Strip(o.ToString());
                if (Core.Limiter.CappedNow.Contains(n, NoCase)) return T("lim.tag.cap");
                if (Core.Limiter.ArmedNow.Contains(n, NoCase)) return T("lim.tag.armed");
                return null;
            };

            const int rx = PX + 442, rw = 262;
            var nc = NewCard(p, rx, 250, rw, 132);
            Lbl(nc, T("lim.now"), Theme.F(8f, true), Theme.Dim, 16, 10, rw - 32, 18);
            limTop = Lbl(nc, "", Theme.F(11f, true), Theme.Text, 16, 30, rw - 32, 26);
            limTopSub = Lbl(nc, "", Theme.F(8.5f), Theme.Dim, 16, 56, rw - 32, 20);
            limAddTop = Put(nc, new Btn(T("lim.addtop"), true, ""), 16, 84, rw - 32, 36);
            limAddTop.Click += (s, e) => { string top = Core.Traffic.Top; if (top != null) AddLimitApp(top + ".exe"); };

            Put(p, new Btn(T("lim.add.run"), false, ""), rx, 394, rw, 40).Click += (s, e) =>
            {
                using (var dlg = new GamePicker(T("lim.pick")))
                    if (dlg.ShowDialog(this) == DialogResult.OK && dlg.Picked != null) AddLimitApp(dlg.Picked);
            };
            Put(p, new Btn(T("games.add.exe"), false, ""), rx, 442, rw, 40).Click += (s, e) =>
            {
                using (var dlg = new OpenFileDialog { Filter = T("games.filter"), CheckFileExists = true })
                    if (dlg.ShowDialog(this) == DialogResult.OK) AddLimitApp(Path.GetFileName(dlg.FileName));
            };
            Put(p, new Btn(T("games.remove"), false, ""), rx, 490, rw, 40).Click += (s, e) =>
            {
                string sel = limList.SelectedItem as string;
                if (sel == null) return;
                int idx = limList.SelectedIndex;
                SaveLimitApps(Settings.LimitApps.Where(x => !string.Equals(x, sel, StringComparison.OrdinalIgnoreCase)));
                if (limList.Items.Count > 0) limList.SelectedIndex = Math.Min(idx, limList.Items.Count - 1);
            };

            var note = Lbl(p, T("lim.note"), Theme.F(8.5f), Theme.Dim, rx + 4, 540, rw - 8, 80);
            note.Wrap = true;
            note.VAlign = HA.Start;

            LoadLimitApps();
            return p;
        }

        static void ApplyLimiterAsync()
        {
            ThreadPool.QueueUserWorkItem(_ => Core.ApplyLimiter());
        }

        void LoadLimitApps()
        {
            if (limList == null) return;
            object sel = limList.SelectedItem;
            limList.BeginUpdate();
            limList.Items.Clear();
            foreach (string x in Settings.LimitApps.OrderBy(v => v, StringComparer.OrdinalIgnoreCase)) limList.Items.Add(x);
            if (sel != null && limList.Items.Contains(sel)) limList.SelectedItem = sel;
            limList.EndUpdate();
            limCount.Text = Loc.T("lim.count", Settings.LimitApps.Count);
        }

        void SaveLimitApps(IEnumerable<string> list)
        {
            // Replace the list instead of editing it: the limiter thread reads it concurrently.
            Settings.LimitApps = list.Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            Settings.Save();
            LoadLimitApps();
            ApplyLimiterAsync();
        }

        void AddLimitApp(string exe)
        {
            exe = Tweaks.Sanitize(exe);
            if (exe.Length == 0) return;
            // A game must never be limited: the limiter skips anything on the Games list anyway.
            SaveLimitApps(Settings.LimitApps.Concat(new[] { exe }));
            limList.SelectedItem = limList.Items.Cast<object>().FirstOrDefault(o => string.Equals(o.ToString(), exe, StringComparison.OrdinalIgnoreCase));
        }

        void RefreshLimiter()
        {
            var lim = Core.Limiter;
            string[] capped = lim.CappedNow, armed = lim.ArmedNow;

            if (!Settings.Limiter) { limStatus.Text = T("lim.st.off"); limStatus.ForeColor = Theme.Dim; }
            else if (lim.Unsupported) { limStatus.Text = T("lim.st.unsup"); limStatus.ForeColor = Theme.Warn; }
            else if (capped.Length > 0)
            {
                limStatus.Text = Loc.T("lim.st.cap", string.Join(", ", capped), Loc.Ltr(RateName(Settings.LimitKbps)));
                limStatus.ForeColor = Theme.Accent;
            }
            else if (armed.Length > 0) { limStatus.Text = Loc.T("lim.st.armed", string.Join(", ", armed)); limStatus.ForeColor = Theme.Accent2; }
            else { limStatus.Text = T("lim.st.none"); limStatus.ForeColor = Theme.Dim; }

            string top = Core.Traffic.Top;
            if (top != null)
            {
                bool listed = Settings.LimitApps.Any(x => string.Equals(GameWatcher.Strip(x), top, StringComparison.OrdinalIgnoreCase));
                limTop.Ltr = true;
                limTop.Text = top + ".exe";
                limTop.ForeColor = Theme.Warn;
                limTopSub.Ltr = true;
                limTopSub.Text = "↑ " + Fmt.Rate(Core.TxAvgBps) + "    ↓ " + Fmt.Rate(Core.RxAvgBps);
                limAddTop.Enabled = !listed;
                limAddTop.Text = T(listed ? "lim.addtop.done" : "lim.addtop");
            }
            else
            {
                limTop.Ltr = false;
                limTop.Text = T("lim.now.none");
                limTop.ForeColor = Theme.Text;
                limTopSub.Ltr = false;
                limTopSub.Text = T("lim.now.none.sub");
                limAddTop.Enabled = false;
                limAddTop.Text = T("lim.addtop");
            }

            string sig = string.Join("|", capped) + "#" + string.Join("|", armed);
            if (sig != limSignature) { limSignature = sig; limList.Invalidate(); }
        }
    }
}
