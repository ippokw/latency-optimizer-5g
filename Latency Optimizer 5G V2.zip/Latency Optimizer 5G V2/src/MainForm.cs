using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace LO5G
{
    /// <summary>Main window + tray icon. Layout numbers are for 100% scaling; S() applies the DPI factor.</summary>
    sealed partial class MainForm : Form
    {
        const int CW = 960, CH = 640, SIDE = 200, PX = 28, PW = 704;

        readonly bool startHidden;
        bool allowShow, exiting;
        Panel side, content;
        // Page order: 0 dashboard, 1 optimize, 2 limiter, 3 games, 4 auto-tune, 5 settings.
        readonly Panel[] pages = new Panel[6];
        readonly NavItem[] navs = new NavItem[6];
        int page;
        Pill sidePill;

        NotifyIcon tray;
        ContextMenuStrip menu;
        Icon trayIcon;
        string trayKey = "";
        ToolStripMenuItem miStatus;
        readonly ToolStripMenuItem[] miBoost = new ToolStripMenuItem[3];
        readonly ToolStripMenuItem[] miMode = new ToolStripMenuItem[4];

        readonly Timer uiTimer = new Timer { Interval = 200 };
        readonly Timer trayTimer = new Timer { Interval = 1000 };

        static int S(int v) { return Theme.S(v); }
        static string T(string key) { return Loc.T(key); }

        public MainForm(bool startHidden)
        {
            this.startHidden = startHidden;
            Text = "Latency Optimizer 5G";
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9.5f);
            ClientSize = new Size(S(CW), S(CH));
            using (var b = IconArt.Logo(48)) Icon = IconArt.ToIcon(b);
            ToolStripManager.Renderer = new DarkMenuRenderer();

            BuildUi();
            BuildTray();

            uiTimer.Tick += (s, e) => { if (Visible) RefreshUi(); };
            trayTimer.Tick += (s, e) => UpdateTray();
            uiTimer.Start();
            trayTimer.Start();

            Core.Changed += OnCoreChanged;
            Core.Notify += OnCoreNotify;
            if (!IsHandleCreated) CreateHandle();
            UpdateTray();
        }

        // ---- window behaviour ---------------------------------------------------------------

        protected override void SetVisibleCore(bool value)
        {
            // Started with --tray: stay hidden until the user asks for the window.
            if (startHidden && !allowShow)
            {
                if (!IsHandleCreated) CreateHandle();
                base.SetVisibleCore(false);
                return;
            }
            base.SetVisibleCore(value);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.DarkTitleBar(Handle, Theme.Bg);
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            Core.SetUiVisible(Visible);
            if (Visible) { SyncControls(); RefreshUi(); }
        }

        public void ShowWindow()
        {
            allowShow = true;
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
        }

        void ToggleWindow()
        {
            if (Visible && Native.GetForegroundWindow() == Handle) Hide();
            else ShowWindow();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing)
            {
                // The X button sends the app to the tray; it keeps working there.
                e.Cancel = true;
                Hide();
                if (!Settings.TrayHintShown)
                {
                    Settings.TrayHintShown = true;
                    Settings.Save();
                    Balloon(T("ntf.tray.t"), T("ntf.tray"), true);
                }
                return;
            }
            uiTimer.Stop();
            trayTimer.Stop();
            Core.Changed -= OnCoreChanged;
            Core.Notify -= OnCoreNotify;
            if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
            base.OnFormClosing(e);
        }

        public void ExitApp()
        {
            exiting = true;
            Close();
        }

        // Used by the "--shot" developer check to capture a page of the real window.
        public void DebugShowPage(int i) { ShowPage(i); }

        public void DebugRender(Bitmap bmp)
        {
            RefreshUi();
            foreach (Control c in Controls) c.DrawToBitmap(bmp, c.Bounds);
        }

        void OnCoreChanged()
        {
            if (!IsHandleCreated || IsDisposed) return;
            try { BeginInvoke(new Action(() => { if (IsDisposed) return; SyncControls(); if (Visible) RefreshUi(); UpdateTray(); })); }
            catch { }
        }

        void OnCoreNotify(string title, string text)
        {
            if (!IsHandleCreated || IsDisposed) return;
            try { BeginInvoke(new Action(() => Balloon(title, text, false))); }
            catch { }
        }

        void Balloon(string title, string text, bool always)
        {
            if (tray == null || (!always && !Settings.Notifications)) return;
            try { tray.ShowBalloonTip(3000, title, text, ToolTipIcon.None); } catch { }
        }

        // ---- frame --------------------------------------------------------------------------

        void BuildUi()
        {
            SuspendLayout();
            foreach (Control c in Controls.Cast<Control>().ToList()) { Controls.Remove(c); c.Dispose(); }

            side = new Panel { BackColor = Theme.Side };
            side.SetBounds(0, 0, S(SIDE), S(CH));
            content = new Panel { BackColor = Theme.Bg };
            content.SetBounds(S(SIDE), 0, S(CW - SIDE), S(CH));
            Controls.Add(side);
            Controls.Add(content);

            BuildSide();
            pages[0] = BuildDashboard();
            pages[1] = BuildOptimize();
            pages[2] = BuildLimiter();
            pages[3] = BuildGames();
            pages[4] = BuildTune();
            pages[5] = BuildSettings();
            for (int i = 0; i < pages.Length; i++) pages[i].Visible = i == page;

            if (Loc.Rtl) Mirror(this);
            ResumeLayout();
            SyncControls();
            RefreshUi();
        }

        /// <summary>Arabic: flip every control to the opposite side of its container.</summary>
        static void Mirror(Control parent)
        {
            int w = parent.ClientSize.Width;
            foreach (Control c in parent.Controls)
            {
                c.Left = w - c.Right;
                if (c is Panel) Mirror(c);
            }
        }

        void Rebuild()
        {
            BuildUi();
            BuildTray();
            if (page == 1) RefreshTweaks();
            UpdateTray();
        }

        void BuildSide()
        {
            Put(side, new Pic(IconArt.Logo(S(40))), 16, 20, 40, 40);
            Lbl(side, "Latency Optimizer", Theme.F(10f, true), Theme.Text, 62, 19, 134, 22).Ltr = true;
            Lbl(side, "5G   ·   V" + Program.Version, Theme.F(8.5f, true), Theme.Accent, 62, 40, 134, 20).Ltr = true;

            string[] glyphs = { "", "", "", "", "", "" };
            string[] keys = { "nav.dash", "nav.opt", "nav.limit", "nav.games", "nav.tune", "nav.set" };
            for (int i = 0; i < navs.Length; i++)
            {
                int idx = i;
                navs[i] = Put(side, new NavItem(T(keys[i]), glyphs[i]) { Selected = i == page }, 12, 92 + i * 46, 176, 40);
                navs[i].Click += (s, e) => ShowPage(idx);
            }

            sidePill = Put(side, new Pill(), 16, 562, 168, 28);
            var credit = Lbl(side, T("side.credit"), Theme.F(8f), Theme.Dim, 8, 598, 184, 20);
            credit.Align = HA.Center;
            credit.Ltr = true;
        }

        void ShowPage(int i)
        {
            page = i;
            for (int k = 0; k < pages.Length; k++)
            {
                pages[k].Visible = k == i;
                navs[k].Selected = k == i;
            }
            if (i == 1) RefreshTweaks();
            if (i == 2) LoadLimitApps();
            if (i == 3) LoadGames();
            RefreshUi();
        }

        // ---- layout helpers -----------------------------------------------------------------

        Panel NewPage()
        {
            var p = new Panel { BackColor = Theme.Bg };
            p.SetBounds(0, 0, content.Width, content.Height);
            content.Controls.Add(p);
            return p;
        }

        static TC Put<TC>(Control parent, TC c, int x, int y, int w, int h) where TC : Control
        {
            c.SetBounds(S(x), S(y), S(w), S(h));
            parent.Controls.Add(c);
            return c;
        }

        static Txt Lbl(Control parent, string text, Font f, Color c, int x, int y, int w, int h)
        {
            return Put(parent, new Txt(text, f, c), x, y, w, h);
        }

        static CardPanel NewCard(Control parent, int x, int y, int w, int h)
        {
            return Put(parent, new CardPanel { OuterColor = parent.BackColor }, x, y, w, h);
        }

        void Title(Panel p, string text)
        {
            Lbl(p, text, Theme.F(17f, true), Theme.Text, PX, 16, PW, 36);
        }

        // ---- tray ---------------------------------------------------------------------------

        void BuildTray()
        {
            if (tray == null)
            {
                tray = new NotifyIcon { Visible = true, Text = "Latency Optimizer 5G" };
                tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ToggleWindow(); };
            }
            if (menu != null) menu.Dispose();

            menu = new ContextMenuStrip
            {
                ShowImageMargin = false,
                ShowCheckMargin = true,
                BackColor = Theme.Card,
                ForeColor = Theme.Text,
                Font = Theme.F(9.5f),
                RightToLeft = Loc.Rtl ? RightToLeft.Yes : RightToLeft.No
            };

            menu.Items.Add(new ToolStripMenuItem("Latency Optimizer 5G") { Enabled = false, Font = Theme.F(9.5f, true) });
            miStatus = new ToolStripMenuItem("") { Enabled = false };
            menu.Items.Add(miStatus);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem(T("tray.open"), null, (s, e) => ShowWindow()));
            menu.Items.Add(new ToolStripSeparator());

            string[] bk = { "boost.off", "boost.auto", "boost.on" };
            for (int i = 0; i < 3; i++)
            {
                int v = i;
                miBoost[i] = new ToolStripMenuItem(Loc.T("tray.boost", T(bk[i])), null, (s, e) => SetBoost(v));
                menu.Items.Add(miBoost[i]);
            }

            var modeMenu = new ToolStripMenuItem(T("tray.mode"));
            var dd = (ToolStripDropDownMenu)modeMenu.DropDown;
            dd.ShowImageMargin = false;
            dd.ShowCheckMargin = true;
            dd.BackColor = Theme.Card;
            dd.ForeColor = Theme.Text;
            dd.RightToLeft = menu.RightToLeft;
            for (int i = 0; i < 4; i++)
            {
                int v = i;
                miMode[i] = new ToolStripMenuItem(T("mode." + i) + "  (" + Settings.ModePps[i] + "/s)", null, (s, e) => SetMode(v));
                modeMenu.DropDownItems.Add(miMode[i]);
            }
            menu.Items.Add(modeMenu);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(new ToolStripMenuItem(T("tray.exit"), null, (s, e) => ExitApp()));

            menu.Opening += (s, e) => SyncMenu();
            tray.ContextMenuStrip = menu;
            SyncMenu();
        }

        void SyncMenu()
        {
            if (menu == null) return;
            for (int i = 0; i < 3; i++) miBoost[i].Checked = Settings.Boost == i;
            for (int i = 0; i < 4; i++) miMode[i].Checked = Settings.Mode == i;
            var st = Core.Inet.GetStats(60000);
            miStatus.Text = st.Valid && st.Last >= 0
                ? "Ping " + Fmt.N0(st.Last) + " ms   ·   Jitter " + Fmt.N1(st.Jitter) + " ms"
                : T("tray.noping");
        }

        void SetBoost(int v)
        {
            Settings.Boost = v;
            Settings.Save();
            Core.Reevaluate();
        }

        void SetMode(int v)
        {
            Settings.Mode = v;
            Settings.Save();
            Core.Reevaluate();
        }

        static readonly Color FillGood = Color.FromArgb(22, 160, 96), FillWarn = Color.FromArgb(214, 140, 0),
                              FillBad = Color.FromArgb(222, 58, 80), FillIdle = Color.FromArgb(96, 104, 130);

        void UpdateTray()
        {
            if (tray == null) return;
            try
            {
                var st = Core.Inet.GetStats(60000);
                bool live = st.Valid && st.Last >= 0;
                int size = SystemInformation.SmallIconSize.Width;
                string key;
                Bitmap bmp;

                if (!Settings.TrayPing)
                {
                    key = "logo" + size;
                    bmp = key == trayKey ? null : IconArt.Logo(size);
                }
                else
                {
                    string text = live ? ((int)Math.Min(999, Math.Round(st.Last))).ToString() : st.Count > 0 ? "!" : "-";
                    Color col = !live ? (st.Count > 0 ? FillBad : FillIdle)
                              : st.Last <= 60 ? (Core.Active ? FillGood : Theme.Good)
                              : st.Last <= 120 ? (Core.Active ? FillWarn : Theme.Warn)
                              : (Core.Active ? FillBad : Theme.Bad);
                    key = text + "|" + col.ToArgb() + "|" + Core.Active + "|" + size;
                    bmp = key == trayKey ? null : IconArt.Badge(size, text, col, Core.Active);
                }

                if (bmp != null)
                {
                    using (bmp)
                    {
                        Icon ic = IconArt.ToIcon(bmp), old = trayIcon;
                        trayIcon = ic;
                        tray.Icon = ic;
                        trayKey = key;
                        if (old != null) old.Dispose();
                    }
                }

                string state = Core.Active ? "ON" : Settings.Boost == 1 ? "AUTO" : "OFF";
                string tip = "Latency Optimizer 5G\n"
                           + (live ? "Ping " + Fmt.N0(st.Last) + " ms  |  Jitter " + Fmt.N1(st.Jitter) + " ms" : "No reply")
                           + "\nBoost: " + state;
                tray.Text = tip.Length > 63 ? tip.Substring(0, 63) : tip;
            }
            catch (Exception ex) { Program.Log(ex); }
        }
    }

    /// <summary>Small dialog listing programs that have a window, to add one as a game.</summary>
    sealed class GamePicker : Form
    {
        sealed class Item
        {
            public string Exe, Title;
            public override string ToString() { return Exe + "   —   " + Title; }
        }

        readonly DarkList list = new DarkList();
        public string Picked;

        public GamePicker(string caption)
        {
            Text = caption;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Theme.Bg;
            ClientSize = new Size(Theme.S(460), Theme.S(470));

            var card = new CardPanel { OuterColor = Theme.Bg };
            card.SetBounds(Theme.S(14), Theme.S(14), Theme.S(432), Theme.S(386));
            list.SetBounds(Theme.S(8), Theme.S(8), Theme.S(416), Theme.S(370));
            card.Controls.Add(list);
            Controls.Add(card);

            var add = new Btn(Loc.T("pick.add"), true);
            var cancel = new Btn(Loc.T("pick.cancel"));
            add.SetBounds(Theme.S(Loc.Rtl ? 14 : 236), Theme.S(414), Theme.S(210), Theme.S(40));
            cancel.SetBounds(Theme.S(Loc.Rtl ? 236 : 14), Theme.S(414), Theme.S(210), Theme.S(40));
            Controls.Add(add);
            Controls.Add(cancel);

            add.Click += (s, e) => Accept();
            cancel.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            list.DoubleClick += (s, e) => Accept();

            var skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "explorer", "ApplicationFrameHost", "SystemSettings", "TextInputHost", "ShellExperienceHost",
                "StartMenuExperienceHost", "SearchHost", "LockApp", "LatencyOptimizer5G"
            };
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in System.Diagnostics.Process.GetProcesses())
            {
                try
                {
                    if (p.MainWindowHandle == IntPtr.Zero) continue;
                    string title = p.MainWindowTitle;
                    if (string.IsNullOrWhiteSpace(title) || skip.Contains(p.ProcessName) || !seen.Add(p.ProcessName)) continue;
                    list.Items.Add(new Item { Exe = p.ProcessName + ".exe", Title = title });
                }
                catch { }
                finally { p.Dispose(); }
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.DarkTitleBar(Handle, Theme.Bg);
        }

        void Accept()
        {
            var it = list.SelectedItem as Item;
            if (it == null) return;
            Picked = it.Exe;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
