using System;
using System.Runtime.InteropServices;

namespace LO5G
{
    /// <summary>Win32 entry points used by the engine and the UI.</summary>
    static class Native
    {
        // ---- timing -------------------------------------------------------------------------
        [DllImport("winmm.dll")] public static extern uint timeBeginPeriod(uint ms);
        [DllImport("winmm.dll")] public static extern uint timeEndPeriod(uint ms);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr CreateWaitableTimerExW(IntPtr attrs, string name, uint flags, uint access);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool SetWaitableTimer(IntPtr h, ref long dueTime, int period, IntPtr routine, IntPtr arg, bool resume);

        [DllImport("kernel32.dll")] public static extern uint WaitForSingleObject(IntPtr h, uint ms);
        [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
        [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();

        [StructLayout(LayoutKind.Sequential)]
        struct PowerThrottling { public uint Version, ControlMask, StateMask; }

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool SetProcessInformation(IntPtr process, int infoClass, ref PowerThrottling info, int size);

        /// <summary>
        /// Windows 11 throttles hidden (tray) processes: it slows their CPU and ignores their timer
        /// resolution. Both would wreck a steady pulse, so opt this process out.
        /// </summary>
        public static void DisablePowerThrottling()
        {
            try
            {
                var s = new PowerThrottling { Version = 1, ControlMask = 0x1 | 0x4, StateMask = 0 };
                if (!SetProcessInformation(GetCurrentProcess(), 4, ref s, 12))
                {
                    s.ControlMask = 0x1; // older Windows 10: execution speed only
                    SetProcessInformation(GetCurrentProcess(), 4, ref s, 12);
                }
            }
            catch { }
        }

        // ---- per-process I/O (to spot which program is using the line) -------------------------
        [StructLayout(LayoutKind.Sequential)]
        public struct IoCounters
        {
            public ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes;
        }

        [DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll", SetLastError = true)] public static extern bool GetProcessIoCounters(IntPtr process, out IoCounters counters);

        // ---- job objects (upload limiter) ------------------------------------------------------
        [StructLayout(LayoutKind.Sequential)]
        public struct NetRateControl
        {
            public ulong MaxBandwidth;   // outgoing bytes per second
            public uint ControlFlags;    // 1 = enable, 2 = max bandwidth
            public byte DscpTag;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern IntPtr CreateJobObjectW(IntPtr attrs, string name);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern IntPtr OpenJobObjectW(uint access, bool inherit, string name);
        [DllImport("kernel32.dll", SetLastError = true)] public static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
        [DllImport("kernel32.dll", SetLastError = true)] public static extern bool SetInformationJobObject(IntPtr job, int infoClass, ref NetRateControl info, int size);
        [DllImport("kernel32.dll", SetLastError = true)] public static extern bool GetProcessTimes(IntPtr process, out long creation, out long exit, out long kernel, out long user);

        // ---- UI -----------------------------------------------------------------------------
        [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr h);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)] static extern int SetWindowTheme(IntPtr hwnd, string app, string idList);

        public static void DarkTitleBar(IntPtr hwnd, System.Drawing.Color caption)
        {
            try
            {
                int on = 1;
                DwmSetWindowAttribute(hwnd, 20, ref on, 4);                       // immersive dark mode
                int rgb = caption.R | (caption.G << 8) | (caption.B << 16);
                DwmSetWindowAttribute(hwnd, 35, ref rgb, 4);                      // caption colour (Windows 11)
            }
            catch { }
        }

        public static void DarkScrollBars(IntPtr hwnd)
        {
            try { SetWindowTheme(hwnd, "DarkMode_Explorer", null); } catch { }
        }

        // ---- Wi-Fi (wlanapi) ----------------------------------------------------------------
        [DllImport("wlanapi.dll")] public static extern uint WlanOpenHandle(uint clientVersion, IntPtr reserved, out uint negotiated, out IntPtr handle);
        [DllImport("wlanapi.dll")] public static extern uint WlanCloseHandle(IntPtr handle, IntPtr reserved);
        [DllImport("wlanapi.dll")] public static extern uint WlanEnumInterfaces(IntPtr handle, IntPtr reserved, out IntPtr list);
        [DllImport("wlanapi.dll")] public static extern uint WlanSetInterface(IntPtr handle, ref Guid iface, int opcode, uint size, IntPtr data, IntPtr reserved);
        [DllImport("wlanapi.dll")] public static extern uint WlanQueryInterface(IntPtr handle, ref Guid iface, int opcode, IntPtr reserved, out uint size, out IntPtr data, out int valueType);
        [DllImport("wlanapi.dll")] public static extern void WlanFreeMemory(IntPtr p);
    }
}
