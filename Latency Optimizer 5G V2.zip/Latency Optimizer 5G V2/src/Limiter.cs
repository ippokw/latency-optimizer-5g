using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace LO5G
{
    /// <summary>
    /// Caps the upload of chosen programs (a Discord stream, a cloud sync, a torrent...) while Boost is
    /// on, so they cannot fill the line and push your ping up.
    ///
    /// It uses a Windows 10+ feature that needs no administrator rights and no driver: each program's
    /// process is placed in its own job object, and the job is given a maximum outgoing bandwidth.
    /// Windows itself then paces that program's packets. The program is never restarted, paused or
    /// modified, and games on your list are never touched.
    ///
    /// How Windows behaves (measured, see "--limtest"):
    ///   * A connection is only controllable if rate control was already switched on for the job at
    ///     the moment the program opened that connection. So listed programs are "armed" all the time
    ///     with a limit so high it is no limit at all, and the number is lowered only while Boost is on.
    ///   * Once a connection is controllable, raising, lowering or removing the limit acts instantly.
    ///   * A connection opened before the program was armed stays free until the program reopens it.
    ///
    /// A process cannot leave a job, so every job is named after the process it holds. If this app is
    /// killed while a cap is active, the next start finds those jobs by name and clears them.
    /// </summary>
    sealed class UploadLimiter
    {
        sealed class Entry
        {
            public IntPtr Job;
            public string Name;
            public long Applied;      // bytes per second currently set on the job; 0 = rate control off
        }

        /// <summary>100 Gbit/s in bytes per second: rate control is on, but nothing is slowed down.</summary>
        public const long Unlimited = 12500000000L;

        const int JobNetRateControl = 32;
        const uint ProcAccess = 0x0001 | 0x0100 | 0x1000;   // TERMINATE + SET_QUOTA (both required to join a job) + QUERY_LIMITED

        readonly Dictionary<int, Entry> jobs = new Dictionary<int, Entry>();
        readonly HashSet<int> refused = new HashSet<int>();
        readonly object lk = new object();
        volatile string[] cappedNow = new string[0], armedNow = new string[0];
        volatile bool unsupported;
        int self;

        /// <summary>Programs whose upload is being held down at this moment.</summary>
        public string[] CappedNow { get { return cappedNow; } }
        /// <summary>Programs that are running and under control (capped or ready to be capped).</summary>
        public string[] ArmedNow { get { return armedNow; } }
        /// <summary>This Windows version refused the bandwidth setting.</summary>
        public bool Unsupported { get { return unsupported; } }

        static string JobName(int pid, long created) { return @"Local\LO5G_Limit_" + pid + "_" + created.ToString("x"); }

        public static bool SetRate(IntPtr job, long bytesPerSec)
        {
            var info = new Native.NetRateControl
            {
                MaxBandwidth = (ulong)Math.Max(0, bytesPerSec),
                ControlFlags = bytesPerSec > 0 ? 0x3u : 0u        // enable + max bandwidth, or everything off
            };
            return Native.SetInformationJobObject(job, JobNetRateControl, ref info, Marshal.SizeOf(typeof(Native.NetRateControl)));
        }

        /// <summary>
        /// Brings Windows in line with the settings. Safe to call repeatedly (it is called every few
        /// seconds to pick up programs that were started later).
        /// </summary>
        /// <param name="enabled">The limiter feature is switched on: keep listed programs armed.</param>
        /// <param name="capNow">Boost is working: hold them down to <paramref name="kbps"/>.</param>
        public void Update(bool enabled, bool capNow, int kbps, IEnumerable<string> apps)
        {
            lock (lk)
            {
                if (self == 0) using (var me = Process.GetCurrentProcess()) self = me.Id;
                long rate = Math.Max(16, kbps) * 1000L / 8;
                var want = new HashSet<string>(apps.Select(GameWatcher.Strip), StringComparer.OrdinalIgnoreCase);
                var games = new HashSet<string>(Settings.Games.Select(GameWatcher.Strip), StringComparer.OrdinalIgnoreCase);
                var alive = new HashSet<int>();
                var capped = new List<string>();
                var armed = new List<string>();

                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        int pid = p.Id;
                        string name = p.ProcessName;
                        alive.Add(pid);
                        bool match = enabled && pid != self && pid > 4 && want.Contains(name) && !games.Contains(name);

                        Entry e;
                        if (jobs.TryGetValue(pid, out e) && !string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase))
                        {
                            // The process we held is gone and its id was reused by something else.
                            Native.CloseHandle(e.Job);
                            jobs.Remove(pid);
                            e = null;
                        }
                        if (e == null)
                        {
                            if (!match || refused.Contains(pid)) continue;
                            e = Attach(pid, name);
                            if (e == null) { refused.Add(pid); continue; }
                            jobs[pid] = e;
                        }

                        long target = !match ? 0 : capNow ? rate : Unlimited;
                        if (e.Applied != target)
                        {
                            if (SetRate(e.Job, target)) e.Applied = target;
                            else if (target > 0) unsupported = true;
                        }
                        if (e.Applied > 0 && !armed.Contains(e.Name, StringComparer.OrdinalIgnoreCase)) armed.Add(e.Name);
                        if (e.Applied > 0 && e.Applied < Unlimited && !capped.Contains(e.Name, StringComparer.OrdinalIgnoreCase)) capped.Add(e.Name);
                    }
                    catch { }
                    finally { p.Dispose(); }
                }

                foreach (int pid in jobs.Keys.Where(k => !alive.Contains(k)).ToList())
                {
                    Native.CloseHandle(jobs[pid].Job);
                    jobs.Remove(pid);
                }
                refused.RemoveWhere(k => !alive.Contains(k));
                cappedNow = capped.ToArray();
                armedNow = armed.ToArray();
            }
        }

        Entry Attach(int pid, string name)
        {
            IntPtr hp = Native.OpenProcess(ProcAccess, false, pid);
            if (hp == IntPtr.Zero) return null;      // elevated or protected program: leave it alone
            try
            {
                long created, x1, x2, x3;
                if (!Native.GetProcessTimes(hp, out created, out x1, out x2, out x3)) return null;
                string jobName = JobName(pid, created);
                // A job with this name can only be ours from an earlier run: the process is already inside it.
                IntPtr job = Native.OpenJobObjectW(0x0006, false, jobName);
                if (job == IntPtr.Zero)
                {
                    job = Native.CreateJobObjectW(IntPtr.Zero, jobName);
                    if (job == IntPtr.Zero) return null;
                    if (!Native.AssignProcessToJobObject(job, hp))
                    {
                        Native.CloseHandle(job);
                        return null;
                    }
                }
                return new Entry { Job = job, Name = name };
            }
            finally { Native.CloseHandle(hp); }
        }

        /// <summary>
        /// Clears caps left behind by a previous run that did not exit cleanly (killed from Task Manager,
        /// power cut...). Called once at start-up. Returns how many were cleared.
        /// </summary>
        public int ClearLeftovers()
        {
            int cleared = 0;
            lock (lk)
            {
                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        int pid = p.Id;
                        if (pid <= 4 || jobs.ContainsKey(pid)) continue;
                        IntPtr hp = Native.OpenProcess(0x1000, false, pid);
                        if (hp == IntPtr.Zero) continue;
                        long created, x1, x2, x3;
                        bool ok = Native.GetProcessTimes(hp, out created, out x1, out x2, out x3);
                        Native.CloseHandle(hp);
                        if (!ok) continue;
                        IntPtr job = Native.OpenJobObjectW(0x0002, false, JobName(pid, created));   // JOB_OBJECT_SET_ATTRIBUTES
                        if (job == IntPtr.Zero) continue;
                        if (SetRate(job, 0)) cleared++;
                        Native.CloseHandle(job);
                    }
                    catch { }
                    finally { p.Dispose(); }
                }
            }
            return cleared;
        }

        /// <summary>Removes every limit and lets go of the jobs (app exit).</summary>
        public void Release()
        {
            lock (lk)
            {
                foreach (var e in jobs.Values)
                {
                    if (e.Applied > 0) SetRate(e.Job, 0);
                    Native.CloseHandle(e.Job);
                }
                jobs.Clear();
                refused.Clear();
                cappedNow = new string[0];
                armedNow = new string[0];
            }
        }
    }
}
