using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace LO5G
{
    /// <summary>
    /// One-time Windows optimizations. The tray app itself never runs elevated: when the user clicks
    /// Apply, it relaunches itself once with "--elevated" (one UAC prompt), which does the work here
    /// and exits. Every changed value is backed up first so Restore puts back exactly what was there.
    /// </summary>
    static class Tweaks
    {
        public static readonly string[] Ids = { "nagle", "throttle", "power", "do", "qos" };

        /// <summary>Redirects everything to a sandbox key under HKCU (used to test without touching Windows).</summary>
        public static bool Test;

        const string Own = @"SOFTWARE\LatencyOptimizer5G";
        const string Bak = Own + @"\Backup";
        const string IfRoot = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces";
        const string Mm = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile";
        const string Do = @"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization";
        const string Qos = @"SYSTEM\CurrentControlSet\Services\Tcpip\QoS";
        const string TestRoot = @"Software\LO5G_TestRoot";

        // Power plan: Wi-Fi adapter power saving, and USB selective suspend.
        static readonly string[][] PowerSettings =
        {
            new[] { "19cbb8fa-5279-450e-9fac-8a3d5fedd0c1", "12bbebe6-58d6-4636-95bb-3217ef867c1a" },
            new[] { "2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226" }
        };

        static RegistryKey Base(bool write)
        {
            if (Test) return write ? Registry.CurrentUser.CreateSubKey(TestRoot) : Registry.CurrentUser.OpenSubKey(TestRoot);
            return RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
        }

        static object Read(string path, string name)
        {
            try
            {
                using (var b = Base(false))
                {
                    if (b == null) return null;
                    using (var k = b.OpenSubKey(path)) return k == null ? null : k.GetValue(name);
                }
            }
            catch { return null; }
        }

        static int ReadInt(string path, string name, int def)
        {
            object o = Read(path, name);
            return o is int ? (int)o : def;
        }

        // ---- state (read-only, no administrator needed) --------------------------------------

        /// <summary>1 = applied, 0 = not applied, -1 = not available on this PC.</summary>
        public static int State(string id)
        {
            try
            {
                switch (id)
                {
                    case "nagle":
                    {
                        string ifId = Core.Net.Id;
                        if (string.IsNullOrEmpty(ifId)) return 0;
                        string p = IfRoot + "\\" + ifId;
                        return ReadInt(p, "TcpAckFrequency", 0) == 1 && ReadInt(p, "TCPNoDelay", 0) == 1 ? 1 : 0;
                    }
                    case "throttle":
                        return ReadInt(Mm, "NetworkThrottlingIndex", 10) == -1 ? 1 : 0;
                    case "power":
                    {
                        if (Test) return -1;
                        bool any = false, all = true;
                        foreach (var p in PowerSettings)
                        {
                            int[] cur = PowerQuery(p[0], p[1]);
                            if (cur == null) continue;
                            any = true;
                            if (cur[0] != 0 || cur[1] != 0) all = false;
                        }
                        return !any ? -1 : all ? 1 : 0;
                    }
                    case "do":
                        return ReadInt(Do, "DODownloadMode", -1) == 0 ? 1 : 0;
                    case "qos":
                    {
                        string marker = Read(Own, "QosGames") as string;
                        if (string.IsNullOrEmpty(marker)) return 0;
                        var have = new HashSet<string>(marker.Split('|'), StringComparer.OrdinalIgnoreCase);
                        var want = new HashSet<string>(Settings.Games.Select(Sanitize).Where(s => s.Length > 0), StringComparer.OrdinalIgnoreCase);
                        return have.SetEquals(want) ? 1 : 0;
                    }
                }
            }
            catch (Exception ex) { Program.Log(ex); }
            return 0;
        }

        /// <summary>Reduces a game name to a safe "name.exe" token (it ends up inside a PowerShell command).</summary>
        public static string Sanitize(string exe)
        {
            var sb = new StringBuilder();
            foreach (char c in (exe ?? "").Trim())
                if (char.IsLetterOrDigit(c) || c == ' ' || c == '.' || c == '_' || c == '-' || c == '(' || c == ')' || c == '+') sb.Append(c);
            string s = sb.ToString().Trim();
            if (s.Length == 0) return "";
            if (!s.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) s += ".exe";
            return s;
        }

        // ---- elevated entry point ------------------------------------------------------------

        public static bool IsAdmin()
        {
            try { return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator); }
            catch { return false; }
        }

        /// <summary>
        /// "--elevated apply id,id [--games a.exe|b.exe]" or "--elevated restore".
        /// Returns 0 on success, otherwise a bit mask of the tweaks that failed.
        /// </summary>
        public static int RunElevated(string[] a)
        {
            string action = a.Length > 1 ? a[1] : "", ids = "", games = "";
            for (int i = 2; i < a.Length; i++)
            {
                if (a[i] == "--games" && i + 1 < a.Length) games = a[++i];
                else if (a[i] == "--testroot") Test = true;
                else if (!a[i].StartsWith("--")) ids = a[i];
            }
            if (!Test && !IsAdmin()) return 100;
            try
            {
                if (action == "apply") return Apply(ids.Split(','), games.Split('|'));
                if (action == "restore") return Restore();
            }
            catch (Exception ex) { Program.Log(ex); return 99; }
            return 98;
        }

        static int Apply(string[] ids, string[] games)
        {
            int fail = 0;
            using (var b = Base(true))
            {
                for (int i = 0; i < Ids.Length; i++)
                {
                    if (Array.IndexOf(ids, Ids[i]) < 0) continue;
                    try
                    {
                        switch (Ids[i])
                        {
                            case "nagle": ApplyNagle(b); break;
                            case "throttle":
                                SetBacked(b, Mm, "NetworkThrottlingIndex", unchecked((int)0xFFFFFFFF));
                                SetBacked(b, Mm, "SystemResponsiveness", 10);
                                break;
                            case "power": if (!Test) ApplyPower(b); break;
                            case "do":
                                SetBacked(b, Do, "DODownloadMode", 0);                          // no peer-to-peer uploads
                                SetBacked(b, Do, "DOPercentageMaxBackgroundBandwidth", 25);     // background updates: 25% of the line
                                break;
                            case "qos": ApplyQos(b, games); break;
                        }
                    }
                    catch (Exception ex) { Program.Log(ex); fail |= 1 << i; }
                }
            }
            return fail;
        }

        static void ApplyNagle(RegistryKey b)
        {
            using (var root = b.OpenSubKey(IfRoot))
            {
                if (root == null) throw new InvalidOperationException("Tcpip interfaces key not found");
                foreach (string name in root.GetSubKeyNames())
                {
                    bool live;
                    using (var k = root.OpenSubKey(name)) live = k != null && HasIp(k);
                    if (!live) continue;
                    SetBacked(b, IfRoot + "\\" + name, "TcpAckFrequency", 1);
                    SetBacked(b, IfRoot + "\\" + name, "TCPNoDelay", 1);
                }
            }
        }

        static bool HasIp(RegistryKey k)
        {
            string d = k.GetValue("DhcpIPAddress") as string;
            if (!string.IsNullOrEmpty(d) && d != "0.0.0.0") return true;
            var s = k.GetValue("IPAddress") as string[];
            if (s != null)
                foreach (string x in s)
                    if (!string.IsNullOrEmpty(x) && x != "0.0.0.0") return true;
            return false;
        }

        static void ApplyPower(RegistryKey b)
        {
            foreach (var p in PowerSettings)
            {
                int[] cur = PowerQuery(p[0], p[1]);
                if (cur == null) continue;   // this PC does not have the setting
                using (var bk = b.CreateSubKey(Bak))
                {
                    string ac = "powercfg||" + p[0] + "||" + p[1] + "||ac", dc = "powercfg||" + p[0] + "||" + p[1] + "||dc";
                    if (bk.GetValue(ac) == null) bk.SetValue(ac, "dword:" + (uint)cur[0], RegistryValueKind.String);
                    if (bk.GetValue(dc) == null) bk.SetValue(dc, "dword:" + (uint)cur[1], RegistryValueKind.String);
                }
                string o;
                Exec("powercfg.exe", "/setacvalueindex SCHEME_CURRENT " + p[0] + " " + p[1] + " 0", out o, 20000);
                Exec("powercfg.exe", "/setdcvalueindex SCHEME_CURRENT " + p[0] + " " + p[1] + " 0", out o, 20000);
            }
            string x;
            Exec("powercfg.exe", "/setactive SCHEME_CURRENT", out x, 20000);
        }

        static void ApplyQos(RegistryKey b, string[] games)
        {
            // Windows only honours DSCP policies off-domain when this flag is set.
            SetBacked(b, Qos, "Do not use NLA", "1");

            var names = games.Select(Sanitize).Where(g => g.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (!Test)
            {
                var sb = new StringBuilder();
                sb.Append("Get-NetQosPolicy -Name 'LO5G_*' -ErrorAction SilentlyContinue | Remove-NetQosPolicy -Confirm:$false -ErrorAction SilentlyContinue; ");
                int n = 0;
                foreach (string g in names)
                    sb.Append("New-NetQosPolicy -Name 'LO5G_" + (n++) + "' -AppPathNameMatchCondition '" + g + "' -DSCPAction 46 -NetworkProfile All -ErrorAction Stop | Out-Null; ");
                string o;
                int code = Exec("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"" + sb + "\"", out o, 180000);
                if (code != 0) throw new Exception("QoS policy script failed (" + code + "): " + o);
            }
            using (var k = b.CreateSubKey(Own)) k.SetValue("QosGames", string.Join("|", names), RegistryValueKind.String);
        }

        static int Restore()
        {
            int fail = 0;
            using (var b = Base(true))
            {
                bool power = false;
                try
                {
                    using (var bk = b.OpenSubKey(Bak, true))
                    {
                        if (bk != null)
                        {
                            foreach (string id in bk.GetValueNames())
                            {
                                try
                                {
                                    if (id.StartsWith("powercfg||")) power = true;
                                    RestoreOne(b, id, bk.GetValue(id) as string);
                                    bk.DeleteValue(id, false);
                                }
                                catch (Exception ex) { Program.Log(ex); fail |= 1; }
                            }
                        }
                    }
                }
                catch (Exception ex) { Program.Log(ex); fail |= 1; }

                string o;
                if (power && !Test) Exec("powercfg.exe", "/setactive SCHEME_CURRENT", out o, 20000);

                bool hadQos = !string.IsNullOrEmpty(Read(Own, "QosGames") as string);
                if (hadQos && !Test)
                {
                    int code = Exec("powershell.exe",
                        "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"Get-NetQosPolicy -Name 'LO5G_*' -ErrorAction SilentlyContinue | Remove-NetQosPolicy -Confirm:$false\"",
                        out o, 120000);
                    if (code != 0) fail |= 2;
                }
                try { using (var k = b.OpenSubKey(Own, true)) { if (k != null) k.DeleteValue("QosGames", false); } } catch { }
            }
            return fail;
        }

        static void RestoreOne(RegistryKey b, string id, string enc)
        {
            string[] parts = id.Split(new[] { "||" }, StringSplitOptions.None);
            if (enc == null) return;

            if (parts[0] == "powercfg" && parts.Length == 4)
            {
                if (Test || !enc.StartsWith("dword:")) return;
                string verb = parts[3] == "ac" ? "/setacvalueindex" : "/setdcvalueindex", o;
                Exec("powercfg.exe", verb + " SCHEME_CURRENT " + parts[1] + " " + parts[2] + " " + uint.Parse(enc.Substring(6)), out o, 20000);
                return;
            }
            if (parts.Length != 2) return;

            using (var k = b.OpenSubKey(parts[0], true))
            {
                if (k == null) return;
                if (enc == "none") k.DeleteValue(parts[1], false);
                else if (enc.StartsWith("dword:")) k.SetValue(parts[1], unchecked((int)uint.Parse(enc.Substring(6))), RegistryValueKind.DWord);
                else if (enc.StartsWith("sz:")) k.SetValue(parts[1], enc.Substring(3), RegistryValueKind.String);
            }
        }

        // ---- helpers -------------------------------------------------------------------------

        /// <summary>Writes a value, remembering the original the first time we touch it.</summary>
        static void SetBacked(RegistryKey b, string path, string name, object value)
        {
            using (var k = b.CreateSubKey(path))
            {
                using (var bk = b.CreateSubKey(Bak))
                {
                    string id = path + "||" + name;
                    if (bk.GetValue(id) == null)
                    {
                        object old = k.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                        string enc = old == null ? "none" : old is int ? "dword:" + unchecked((uint)(int)old) : "sz:" + old;
                        bk.SetValue(id, enc, RegistryValueKind.String);
                    }
                }
                if (value is int) k.SetValue(name, (int)value, RegistryValueKind.DWord);
                else k.SetValue(name, value.ToString(), RegistryValueKind.String);
            }
        }

        /// <summary>Current AC and DC index of a power setting, or null when this PC does not have it.</summary>
        static int[] PowerQuery(string sub, string setting)
        {
            string o;
            int code = Exec("powercfg.exe", "/query SCHEME_CURRENT " + sub + " " + setting, out o, 15000);
            if (code != 0 || string.IsNullOrEmpty(o)) return null;
            var m = Regex.Matches(o, "0x([0-9a-fA-F]{8})");
            if (m.Count < 2) return null;
            return new[]
            {
                unchecked((int)Convert.ToUInt32(m[m.Count - 2].Groups[1].Value, 16)),
                unchecked((int)Convert.ToUInt32(m[m.Count - 1].Groups[1].Value, 16))
            };
        }

        static int Exec(string file, string args, out string output, int timeoutMs)
        {
            output = "";
            try
            {
                var psi = new ProcessStartInfo(file, args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                using (var p = Process.Start(psi))
                {
                    var err = new StringBuilder();
                    p.ErrorDataReceived += (s, e) => { if (e.Data != null) err.AppendLine(e.Data); };
                    p.BeginErrorReadLine();
                    var readTask = p.StandardOutput.ReadToEndAsync();
                    if (!p.WaitForExit(timeoutMs))
                    {
                        try { p.Kill(); } catch { }
                        return -2;
                    }
                    p.WaitForExit();
                    output = readTask.Result + err;
                    return p.ExitCode;
                }
            }
            catch (Exception ex)
            {
                output = ex.Message;
                return -1;
            }
        }
    }
}
