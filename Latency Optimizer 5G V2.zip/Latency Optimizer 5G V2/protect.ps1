# Obfuscates the built exe (renames symbols + encrypts strings) and replaces the one in the dist folder.
# Run build.ps1 first. The Obfuscar tool is installed locally under obj\tools.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dist = Join-Path $root 'Latency Optimizer 5G V2.0'
$exe  = Join-Path $dist 'LatencyOptimizer5G.exe'
$tool = Join-Path $root 'obj\tools\obfuscar.console.exe'
$work = Join-Path $root 'obj\protect'
$in   = Join-Path $work 'in'
$out  = Join-Path $work 'out'
$cfg  = Join-Path $work 'obfuscar.generated.xml'

if (-not (Test-Path $exe))  { throw "Build first: $exe not found." }
if (-not (Test-Path $tool)) { throw "Obfuscar not installed at $tool." }

Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $in, $out | Out-Null
Copy-Item $exe $in

$before = (Get-Item $exe).Length

# The paths are written straight into the config so no command-line variables are needed.
@"
<?xml version="1.0" encoding="utf-8"?>
<Obfuscator>
  <Var name="InPath" value="$in" />
  <Var name="OutPath" value="$out" />
  <Var name="KeepPublicApi" value="false" />
  <Var name="HidePrivateApi" value="true" />
  <Var name="RenameProperties" value="true" />
  <Var name="RenameEvents" value="true" />
  <Var name="RenameFields" value="true" />
  <Var name="HideStrings" value="true" />
  <Var name="Optimize" value="true" />
  <Var name="SuppressIldasm" value="true" />
  <Var name="ReuseNames" value="true" />
  <AssemblySearchPath path="C:\Windows\Microsoft.NET\Framework64\v4.0.30319" />
  <Module file="`$(InPath)\LatencyOptimizer5G.exe">
    <!-- P/Invoke signatures: keep the method names so the Windows API calls still resolve. -->
    <SkipType name="LO5G.Native" skipMethods="true" skipFields="true" />
  </Module>
</Obfuscator>
"@ | Set-Content -Path $cfg -Encoding UTF8

& $tool $cfg
if ($LASTEXITCODE -ne 0) { throw "Obfuscar failed (exit $LASTEXITCODE)." }

$result = Join-Path $out 'LatencyOptimizer5G.exe'
if (-not (Test-Path $result)) { throw 'Obfuscar produced no output exe.' }

Copy-Item $result $exe -Force
$after = (Get-Item $exe).Length
"Protected: $exe"
("  size {0:N0} -> {1:N0} bytes" -f $before, $after)
"  mapping: " + (Join-Path $out 'Mapping.txt')
