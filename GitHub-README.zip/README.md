<div align="center">

# ⚡ Latency Optimizer 5G

**Ping stabilizer for 5G, Wi-Fi and cable connections — kills lag spikes, lives in your system tray.**

![version](https://img.shields.io/badge/version-2.0-00dcaa)
![platform](https://img.shields.io/badge/Windows-10%20%7C%2011-0a84ff)
![size](https://img.shields.io/badge/size-single%20.exe-8a63ff)
![install](https://img.shields.io/badge/install-none%20needed-2ed584)

[العربية](#بالعربية) · [English](#english)

<img src="screenshots/dashboard.png" width="760" alt="Dashboard">

</div>

---

## English

### What is this?

**Latency Optimizer 5G** stabilizes your ping and reduces lag while gaming on **5G**, Wi-Fi and cable connections. These links — especially 5G — drop into power saving during the gaps when no data is sent, so the first game packet arrives late and causes a ping spike. The app sends a steady stream of tiny packets that keep the link awake, so game packets always arrive fast.

It also monitors your line live (ping, jitter, packet loss), diagnoses exactly where a problem is (your router, the tower/provider, or a program filling the line), can cap the upload of apps like Discord while you play, and tunes Windows for low latency. It runs quietly in the system tray without slowing your PC down.

> **Note:** the big "Ping" number measures your line to the internet as a whole (PC → router → tower → internet), not a specific game's ping. To measure a game server, enter its address in **Settings → Ping target**.

### Features

- **🎯 Ping stabilizer (Boost)** — a steady, feather-light pulse keeps the radio link awake so it never sleeps between game packets. The packets expire inside your provider's network and never reach any server.
- **🤖 Auto mode** — turns Boost on by itself the moment a game from your list opens, and off when you close it. Uses no data while you are not playing.
- **📊 Live monitoring** — real-time ping, jitter, packet loss and a stability score, with a 60-second graph of both your internet and your router.
- **🔍 Smart diagnosis** — tells you *where* the problem is: your Wi-Fi/cable, the tower/provider, or a program on your PC filling the line (and names it).
- **🚦 Upload limiter** — caps the upload of apps like Discord, OneDrive or torrents while you play, so they can't flood your line. No administrator needed.
- **📶 Wi-Fi optimizer** — blocks the background scans that cause a lag spike every minute.
- **⚙️ Windows tweaks** — one-click, fully reversible: Nagle off, network throttling off, network power saving off, tame Windows Update, game traffic priority (DSCP).
- **🎚️ Auto-Tune** — measures your line with every pulse level and picks the best one automatically.
- **🌐 Arabic & English**, dark UI, lives in the system tray.

### Screenshots

| Optimize | Limiter |
|---|---|
| ![Optimize](screenshots/optimize.png) | ![Limiter](screenshots/limiter.png) |
| **Games** | **Auto-Tune** |
| ![Games](screenshots/games.png) | ![Auto-Tune](screenshots/autotune.png) |

### How to use

1. Download the latest release and extract it.
2. Run **`LatencyOptimizer5G.exe`** — a single file, nothing to install.
   *If Windows SmartScreen appears, click **More info → Run anyway** (the file is unsigned).*
3. It lives next to the clock. The tray icon shows your live ping (green = good, yellow = fair, red = bad).
4. Set **Boost** to **AUTO** — it will stabilize your ping automatically whenever you open a game.

> The **X** button only hides the window; the app keeps working. To quit: right-click the tray icon → **Exit**.

### Pulse modes & data usage

| Mode | Pulse | Data / hour |
|---|---|---|
| Eco | 10 /s | ≈ 2 MB |
| Balanced | 30 /s | ≈ 5 MB |
| Ultra | 60 /s | ≈ 10 MB |
| Extreme | 125 /s | ≈ 20 MB |

### Requirements

Windows 10 or 11. Nothing else to install.

---

## بالعربية

### ما هو البرنامج؟

**Latency Optimizer 5G** يثبّت البنق ويقلّل التقطيع (اللاق) أثناء اللعب على خطوط الـ **5G** والواي فاي والكيبل. فكرته إن هذي الخطوط — خصوصاً الـ 5G — تدخل وضع توفير الطاقة بين اللحظات اللي ما تُرسل فيها بيانات، فأول حزمة من اللعبة توصل متأخرة وتسبب قفزة بالبنق. البرنامج يرسل نبضات صغيرة جداً وثابتة تبقي الخط صاحي دائماً، فتوصل حزم اللعبة بسرعة ثابتة.

وما يكتفي بهذا — يراقب خطك لحظة بلحظة (بنق، تذبذب، فقد حزم)، ويشخّص وين المشكلة بالضبط (الراوتر عندك، أو البرج/مزود الخدمة، أو برنامج يستهلك الخط)، ويقدر يحدّ سرعة رفع برامج مثل Discord أثناء اللعب، ويضبط ويندوز لأقل تأخير. يشتغل بجانب الساعة بهدوء بدون ما يعطّل جهازك.

> **ملاحظة:** رقم "البنق" الكبير يقيس خطك إلى الإنترنت ككل (جهازك ← الراوتر ← البرج ← الإنترنت)، وليس بنق لعبة معيّنة. لو تبي تقيس سيرفر لعبة، اكتب عنوانه في **الإعدادات ← هدف البنق**.

### المميزات

- **🎯 مثبّت البنق** — نبض خفيف وثابت يبقي خط الـ 5G / الواي فاي صاحي فما ينام بين حزم اللعبة. النبضات تنتهي داخل شبكة المزود وما توصل لأي سيرفر.
- **🤖 الوضع التلقائي** — يشتغل لوحده أول ما تفتح لعبة من قائمتك، ويتوقف لما تقفلها. ما يستهلك بيانات وأنت ما تلعب.
- **📊 مراقبة مباشرة** — بنق وتذبذب وفقد حزم وتقييم ثبات، مع رسم بياني لآخر 60 ثانية لخطك وللراوتر.
- **🔍 تشخيص ذكي** — يقول لك وين المشكلة: الواي فاي/الكيبل عندك، أو البرج/المزود، أو برنامج يملأ الخط (ويذكر اسمه).
- **🚦 محدد السرعة** — يحدّ رفع برامج مثل Discord والتورنت أثناء اللعب عشان ما تملأ خطك. بدون صلاحية مسؤول.
- **📶 محسّن الواي فاي** — يمنع فحص الشبكات بالخلفية اللي يسوي قفزة بالبنق كل دقيقة.
- **⚙️ تحسينات ويندوز** — بضغطة واحدة وقابلة للتراجع بالكامل: تعطيل Nagle، تعطيل خنق الشبكة، إيقاف توفير الطاقة، تهدئة التحديثات، أولوية حزم الألعاب.
- **🎚️ الضبط التلقائي** — يقيس خطك مع كل مستوى نبض ويختار الأفضل تلقائياً.
- **🌐 عربي وإنجليزي**، واجهة داكنة، ويعيش بجانب الساعة.

### طريقة الاستخدام

1. نزّل آخر إصدار واستخرج الملف المضغوط.
2. شغّل **`LatencyOptimizer5G.exe`** — ملف واحد بدون تثبيت.
   *إذا ظهرت رسالة Windows SmartScreen اضغط **More info ← Run anyway** (الملف غير موقّع).*
3. يشتغل بجانب الساعة. الأيقونة تعرض البنق الحالي (أخضر ممتاز، أصفر متوسط، أحمر سيئ).
4. اختر **التثبيت → تلقائي** ويثبّت بنقك لوحده أول ما تفتح أي لعبة.

> زر **X** يخفي النافذة فقط والبرنامج يكمل شغله. للإغلاق النهائي: كليك يمين على الأيقونة ← **إغلاق**.

### أوضاع النبض والاستهلاك

| الوضع | النبض | الاستهلاك/ساعة |
|---|---|---|
| اقتصادي | 10/ث | ≈ 2 MB |
| متوازن | 30/ث | ≈ 5 MB |
| قوي | 60/ث | ≈ 10 MB |
| أقصى | 125/ث | ≈ 20 MB |

### المتطلبات

ويندوز 10 أو 11. لا يحتاج تثبيت أي شي.

---

<div align="center">

**Powered by Othman Malallah** · Instagram: [@ippokw](https://instagram.com/ippokw)

</div>
